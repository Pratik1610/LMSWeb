<?php
 session_start();
 include "authentication.php";
 @$email=$_SESSION['uemail'];
 $cur=date("Y-m-d");
 if(!isset($email))
 {
	 echo "<script> alert('Please login First!') </script>";
	 echo "<script> window.location.href='index.php' </script>";
 }
 else
 {
	 if($_REQUEST["mid"]==1)
	 {
		 $exam="CBAP";
	 }
	 elseif($_REQUEST["mid"]==2)
	 {
		 $exam="CCBA";
	 }
	 elseif($_REQUEST["mid"]==3)
	 {
		 $exam="ECBA";
	 }
 }
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>
	<title>Online Training on Professional Courses and Certifications by Experts</title>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" /> 

	<meta name="viewport" content="width=device-width, initial-scale=1"/>
	<meta name="title" content="Online Training on Professional Courses and Certifications by Experts"/>
	<meta name="description" content="Online Trainings from Experts to help Advance your Career"/>
	<meta name="author" content=""/>

	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	
	<meta property="fb:app_id" content="212429995547826" />
	<meta property="og:site_name" content="LMS" />
	<meta property="og:type" content="website" />
	<meta property="og:url" content="localhost/lms" />
	<meta property="og:image" content="" />
	<meta property="og:title" content="Online Training on Professional Courses and Certifications by Experts" />
	<meta property="og:description" content="Online Trainings from Experts to help Advance your Career" />
	<meta name="google-site-verification" content="2-7nt5nzoyujWWK_cE0JdA1pftuko_9Hiq5sMNx1JSU" />
	
	
	<link rel="shortcut icon" href="images/spectra-logo.jpg" type="image/x-icon"/>
	<link type="text/css" href="css/bootstrap-4.3.1.min.css" rel="stylesheet"/>
		
	</head>
<body  >

	<div id="promotional" class="text-center ">
<!-- Loading Modal -->




<!DOCTYPE html>
<html lang="en">
<div class="col-lg-12" style="height:100px; background-color:#007BFF;">
<h1 style="color:white; font-size:24px;">Summary</h1>
<p style="color:white;">Exam: <?php echo $exam;?>, Date: <?php echo date("d-m-Y");?></p>
</div>
   <div class="width-100" >
         <br>
         <div class="container"><!-- container start-->
		 <div class="row">
		 <div class="col-lg-6">
		 <div class="row">
		      <?php
			  $mid=$_REQUEST["mid"];
			  $sql=mysqli_query($db,"select * from mock_sub where user_email='$email' and test_date='$cur' and mock_id='$mid' order by id asc");
			  $c=1;
			  while($row=mysqli_fetch_object($sql))
			  {
				  ?>
				  <div class="col-lg-2">
				  <?php
				  if($row->status=="right")
				  {
			  ?>
			  <a href="#" style="width:20px; background-color:green; color:white; padding:5px;">Question<?php echo $c;?></a>
			  <?php
				  }
				  elseif($row->status=="wrong")
				  {
				?>
				<a href="#" style="width:20px; background-color:red; color:white; padding:5px;">Question<?php echo $c;?></a>
				<?php
				  }
				  elseif($row->review_later=="true")
				  {
					  ?>
					  
				<a href="edit-question.php?msid=<?php echo $row->id; ?>" target="_blank" style="width:20px; background-color:yellow; color:black; padding:5px;">Question<?php echo $c;?></a>
					  <?php
					  
				  }
				  ?>
				  </div>
				  <br>
				  <br>
				  <?php
			  $c++;
			  }
			  ?></div>
			  </div>
			  
			  <div class="col-lg-3">
			     <p style="background-color:green; color:white;">Right Answer</p>
			     <p style="background-color:red; color:white;">Wrong Answer</p>
			     <p style="background-color:yellow;">Review Later</p>
			  </div>
			  
			  </div>
			  
			  <div class="row">
			      <form action="result.php" method="post">
				  <input type="hidden" name="mid" value="<?php echo $_REQUEST["mid"];?>">
			      <input type="checkbox" value="finish" id="finish" required>&nbsp; I understand this will end this exam.<br>
				  <input type="submit" value="Finish" class="btn btn-primary">
				  </form>
			  </div>
			  </div>
	  </div>
   </div>
   <!-- Bootstrap core JavaScript -->
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/jquery-ui-1.12.1.min.js"></script>
<script type="text/javascript" src="js/popper.min.js"></script>
<script type="text/javascript" src="js/bootstrap-v4.3.1.min.js"></script>
<script type="text/javascript" src="js/jquery.form.js"></script>
<script type="text/javascript" src="js/jquery.timeago.js"></script>
<script type="text/javascript" src="js/jstz.min.js"></script>
<script type="text/javascript" src="js/script.js?v=80.0"></script>
<script type="text/javascript" src="js/jquery.autosize.min.js"></script>
<script type="text/javascript" src="js/jquery.noty.packaged.min.js"></script>
<script type="text/javascript" src="js/star-rating.min.js"></script>
<script type="text/javascript" src="js/jquery.timeago.js"></script>
<script type="text/javascript" src="js/chat.js?v=80.0"></script>
<script type="text/javascript" src="js/select2.js?v=80.0"></script>
<script type="text/javascript" src="js/login_old.js?v=80.0"></script>

<script>
//ga('send', 'event', 'Custom Variables', 'Set UserId', {'nonInteraction': 1});
//ga('send', 'pageview');

$(document).ready(function() {
	$('#phn_no').on('keydown',  function (event) {	
		if ((event.which < 48 || event.which > 57) && (event.which != 46 && event.which != 0 && event.which != 8 && event.which != 9)) {
			event.preventDefault();
		} 
	});
});
</script>
<!-- Google Code for Remarketing Tag -->
<script type="text/javascript">
/* <![CDATA[ */
var google_conversion_id = 981938738;
var google_custom_params = window.google_tag_params;
var google_remarketing_only = true;
/* ]]> */
</script>

<script>
function showHint(str) {
    if (str.length == 0) {
        document.getElementById("scontent").innerHTML = "";
        return;
    } else {
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("scontent").innerHTML = this.responseText;
            }
        }
        xmlhttp.open("GET", "gethint.php?q="+str, true);
        xmlhttp.send();
    }
}
function shownHint(str) {
    if (str.length == 0) {
        document.getElementById("sncontent").innerHTML = "";
        return;
    } else {
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("sncontent").innerHTML = this.responseText;
            }
        }
        xmlhttp.open("GET", "gethint.php?q="+str, true);
        xmlhttp.send();
    }
}
</script>
<div style="display:none">
<script type="text/javascript" src="//www.googleadservices.com/pagead/conversion.js"></script>
</div>
<noscript>
<div style="display:inline;">
<img height="1" width="1" style="border-style:none;" alt="" src="//googleads.g.doubleclick.net/pagead/viewthroughconversion/981938738/?value=0&amp;guid=ON&amp;script=0"/>
</div>
</noscript>
<!-- BING TAG START-->
<!--<script>(function(w,d,t,r,u){var f,n,i;w[u]=w[u]||[],f=function(){var o={ti:"5062533"};o.q=w[u],w[u]=new UET(o),w[u].push("pageLoad")},n=d.createElement(t),n.src=r,n.async=1,n.onload=n.onreadystatechange=function(){var s=this.readyState;s&&s!=="loaded"&&s!=="complete"||(f(),n.onload=n.onreadystatechange=null)},i=d.getElementsByTagName(t)[0],i.parentNode.insertBefore(n,i)})(window,document,"script","//bat.bing.com/bat.js","uetq");</script><noscript><img alt="ApnaCourse Bing" src="//bat.bing.com/action/0?ti=5062533&Ver=2" height="0" width="0" style="display:none; visibility: hidden;" /></noscript>-->
<script>
!function(q,e,v,n,t,s){if(q.qp) return; n=q.qp=function(){n.qp?n.qp.apply(n,arguments):n.queue.push(arguments);}; n.queue=[];t=document.createElement(e);t.async=!0;t.src=v; s=document.getElementsByTagName(e)[0]; s.parentNode.insertBefore(t,s);}(window, 'script', 'https://a.quora.com/qevents.js');
qp('init', '5ba9c826abc545119f0adb3bd5f5bae3');
qp('track', 'ViewContent');
</script>
<noscript><img height="1" width="1" style="display:none" src="https://q.quora.com/_/ad/5ba9c826abc545119f0adb3bd5f5bae3/pixel?tag=ViewContent&noscript=1"/></noscript>
<!-- BING TAG END -->
<!-- Zarget code -->
<!--script src="//cdn.zarget.com/78460/100609.js"></script-->

</body>
</html>