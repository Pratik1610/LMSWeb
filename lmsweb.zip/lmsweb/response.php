<?php
session_start();

// This is just an example. In application this will come from Javascript (via an AJAX or something)
$timezone_offset_minutes =  $_GET['dt'];  // $_GET['timezone_offset_minutes']

// Convert minutes to seconds
$timezone_name = timezone_name_from_abbr("", $timezone_offset_minutes*60, false);

// Asia/Kolkata
$timezone=$timezone_name;
date_default_timezone_set("$timezone");

$from_time1=date("Y-m-d H:i:s");
$to_time1=$_SESSION["end_time"];

$timefirst=strtotime($from_time1);
$timesecond=strtotime($to_time1);

$differenceinseconds=$timesecond-$timefirst;

if(gmdate("H:i:s",$differenceinseconds)=="00:00:00")
{
	echo "<script>  window.location.href='result.php?mid=".$_GET["mid"]."' </script>";
}
echo gmdate("H:i:s",$differenceinseconds);
?>