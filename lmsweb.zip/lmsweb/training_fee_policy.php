<?php
 session_start();
 include "authentication.php";
 // Asia/Kolkata
 @$timezone=$_SESSION["timezone"];

 @date_default_timezone_set("$timezone");
 
 $cur=date("Y-m-d");
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>
	<title>LMS | Online Training on Professional Courses and Certifications by Experts | Training Fee Policy</title>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" /> 

	<meta name="viewport" content="width=device-width, initial-scale=1"/>
	<meta name="title" content="Online Training on Professional Courses and Certifications by Experts"/>
	<meta name="description" content="Online Trainings from Experts to help Advance your Career"/>
	<meta name="author" content=""/>

	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	
	<meta property="fb:app_id" content="212429995547826" />
	<meta property="og:site_name" content="LMS" />
	<meta property="og:type" content="website" />
	<meta property="og:url" content="localhost/lms" />
	<meta property="og:image" content="" />
	<meta property="og:title" content="Online Training on Professional Courses and Certifications by Experts" />
	<meta property="og:description" content="Online Trainings from Experts to help Advance your Career" />
	<meta name="google-site-verification" content="2-7nt5nzoyujWWK_cE0JdA1pftuko_9Hiq5sMNx1JSU" />
	
	
	<link rel="shortcut icon" href="images/user-placeholder.gif" type="image/x-icon"/>
	<link type="text/css" href="css/bootstrap-4.3.1.min.css" rel="stylesheet"/>
	<link type="text/css" href="css/star-rating.min.css" rel="stylesheet"/>
	<link type="text/css" href="css/select2.css" rel="stylesheet"/>
	<link type="text/css" href="css/jquery-ui-1.12.1.min.css" rel="stylesheet"/>
	<link type="text/css" href="css/style_new.css?v=80.0" rel="stylesheet"/>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<link href="https://cdn.jsdelivr.net/gh/gitbrent/bootstrap4-toggle@3.4.0/css/bootstrap4-toggle.min.css" rel="stylesheet">
	<link rel="stylesheet" href="css/frontpage.css?v=80.0" />
	<link href="https://unpkg.com/material-components-web@latest/dist/material-components-web.min.css" rel="stylesheet">
	<script src="https://unpkg.com/material-components-web@latest/dist/material-components-web.min.js"></script>
	<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
		
	<style>
		.btn-outline {
			background-color: transparent;
			color: inherit;
			transition: all .5s;
			border:0px;
		}
		.multi_modal_right_signup {
			float: left;
			border-left: 0px solid #e5e5e5;
			margin-left: 20%;
			margin-right: 20%;
		}
		/*uncomment banner once banner is removed*/
		
	</style>
	</head>
<body  >
<div class="modal fade" id="login" role="dialog" aria-labelledby="loginModal" aria-hidden="true">
	<input type="hidden" id="modal_param" value="no" >	
	<div class="modal-dialog">
		<div class="modal-content" id="modal_login">
			<div class="modal-header text-center">
				<h4 class="modal-title w-100 font-weight-bold">Login to Our Site </h4>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			
			<form id="signin_modal" action="login_user.php" method="post">
				<div class="modal-body mx-3">
				<label style="font-size:14px; margin-left:5px;">Mendatory Fields <span style="color:#FF0000;">(*)</span></label>
					<div class="row">
						<label class="mdc-text-field mdc-text-field--filled mdc-text-field--label-floating">
						  <span class="mdc-text-field__ripple"></span>
						  <input class="mdc-text-field__input" type="email" aria-labelledby="email" id="username_m" name="username_m" required>
						  <span class="mdc-floating-label mdc-floating-label--float-above" id="email">
							Enter Your Email
						  </span>
						  <span class="mdc-line-ripple" style="color:#FF0000;">(*)</span>
						</label>
					</div>
					<div class="row">
						 <label class="mdc-text-field mdc-text-field--filled mdc-text-field--label-floating">
						  <span class="mdc-text-field__ripple"></span>
						  <input class="mdc-text-field__input" type="password" aria-labelledby="password" id="password_m" name="password_m" required>
						  <span class="mdc-floating-label mdc-floating-label--float-above" id="password">
							Enter Password
						  </span>
						  <span class="mdc-line-ripple" style="color:#FF0000;">(*)</span>
						</label>
						<div class="input-group margin-bottom-10">
						<small class="fright"><a href="javascript:multi_modal('forget');">Forgot Password?</a></small>
					</div>
					</div>
					
					
					<div class="d-flex justify-content-center">
						<button class="btn btn-primary">Login</button>
					</div>
					<div class="input-group margin-top-10 invalid font14 margin-bottom-10" id="messages"></div>
				</div> 
				<div class="clearfix"></div>
				<div class="modal-footer">
					<span class="linking">New to Our Site? <a href="javascript:multi_modal('signup');">Sign Up</a></span>
				</div>
			</form>
		</div>
		<div class="modal-content hide" id="modal_forget">
			<div class="processing modal-content hide" id="forg_proc">
				<div class="modal-body">
					<div class="text-center">
						<b>Sending Activation Link</b>
					</div>
				</div>
			</div>
			<div class="modal-header text-center">
				<h4 class="modal-title w-100 font-weight-bold">Forgot your password ?</h4>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			
			<form name="forget_password" method="POST" action="forgot_password.php">
				<div class="modal-body">
					<div class="fnone invalid font14 margin-left-35 margin-right-35 margin-bottom-10" id="invalid_id"></div>
					<div class="row">
						 <label class="mdc-text-field mdc-text-field--filled mdc-text-field--label-floating">
						  <span class="mdc-text-field__ripple"></span>
						  <input class="mdc-text-field__input" type="email" aria-labelledby="email" id="username_f" name="username" required>
						  <span class="mdc-floating-label mdc-floating-label--float-above" id="username_f">
							Enter Your Email
						  </span>
						  <span class="mdc-line-ripple" style="color:#FF0000;">(*)</span>
						</label>
					</div>
					<div class="text-center">
						On Clicking <strong class="label label-success">Forgot Password</strong>, we will send you a password reset email.	
					</div>
				</div>
				<div class="modal-footer">
					<input type="submit" class="btn btn-success" value="Forgot Password" name="forgotpass">
					<button type="button" class="btn btn-info" data-dismiss="modal">Cancel</button>
				</div>
			</form>
		</div>
		
				<div class="modal-content hide" id="modal_signup">
			<div class="modal-header text-center">
				<h4 class="modal-title w-100 font-weight-bold">Sign Up and Start Learning</h4>
				
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<label style="font-size:14px; margin-left:5px;">Mendatory Fields <span style="color:#FF0000;">(*)</span></label>
			<form method="post" action="reg_user.php">
			<input type="hidden" name="ProspectID" id="ProspectID" value="" />
			<input type="hidden" name="country_id" value="">				
			<div class="modal-body mx-3">
			<div class="first_name_error text-center font-red"></div>
			<div class="row">
					 <label class="mdc-text-field mdc-text-field--filled mdc-text-field--label-floating">
						  <span class="mdc-text-field__ripple"></span>
						  <input class="mdc-text-field__input" type="text" aria-labelledby="first_name" pattern="[a-zA-Z ]*$" id="first_name" title="Name should only contain letters. e.g. john" name="name" required>
						  <span class="mdc-floating-label mdc-floating-label--float-above" id="first_name">
							Enter Your Name
						  </span>
						  <span class="mdc-line-ripple" style="color:#FF0000;">(*)</span>
						</label>
				</div>
				<div class="phone_error text-center font-red"></div>
				<div class="row">		
					<label class="col-sm-4">
					<span style="font-size:10px;">Country Code</span>
						
													<select class="form-control font14 margin-auto" name="country" id="country" required>
													
													<option value="IN" >India (IN)</option>
													<option value="AF" >Afghanistan (AF)</option>
													<option value="AL" >Albania (AL)</option>
													<option value="DZ" >Algeria (DZ)</option>
													<option value="AS" >American Samoa (AS)</option>
													<option value="AD" >Andorra (AD)</option>
													<option value="AO" >Angola (AO)</option>
													<option value="AI" >Anguilla (AI)</option>
													<option value="AQ" >Antarctica (AQ)</option>
													<option value="AG" >Antigua and Barbuda (AG)</option>
													<option value="AR" >Argentina (AR)</option>
													<option value="AM" >Armenia (AM)</option>
													<option value="AW" >Aruba (AW)</option>
													<option value="AU" >Australia (AU)</option>
													<option value="AT" >Austria (AT)</option>
													<option value="AZ" >Azerbaijan (AZ)</option>
													<option value="BS" >Bahamas (BS)</option>
													<option value="BH" >Bahrain (BH)</option>
													<option value="BD" >Bangladesh (BD)</option>
													<option value="BD" >Barbados (BB)</option>
													<option value="BY" >Belarus (BY)</option>
													<option value="BE" >Belgium (BE)</option>
													<option value="BZ" >Belize (BZ)</option>
													<option value="BJ" >Benin (BJ)</option>
													<option value="BM" >Bermuda (BM)</option>
													<option value="BT" >Bhutan (BT)</option>
													<option value="BO" >Bolivia (BO)</option>
													<option value="BA" >Bosnia and Herzegovina (BA)</option>
													<option value="BW" >Botswana (BW)</option>
													<option value="BR" >Brazil (BR)</option>
													<option value="IO" >British lndian Ocean Territory (IO)</option>
													<option value="BN" >Brunei Darussalam (BN)</option>
													<option value="BG" >Bulgaria (BG)</option>
													<option value="BF" >Burkina Faso (BF)</option>
													<option value="BI" >Burundi (BI)</option>
													<option value="KH" >Cambodia (KH)</option>
													<option value="CM" >Cameroon (CM)</option>
													<option value="CA" >Canada (CA)</option>
													<option value="CV" >Cape Verde (CV)</option>
													<option value="KY" >Cayman Islands (KY)</option>
													<option value="CF" >Central African Republic (CF)</option>
													<option value="TD" >Chad (TD)</option>
													<option value="CL" >Chile (CL)</option>
													<option value="CN" >China (CN)</option>
													<option value="CX" >Christmas Island (CX)</option>
													<option value="CC" >Cocos (Keeling) Islands (CC)</option>
													<option value="CO" >Colombia (CO)</option>
													<option value="KM" >Comoros (KM)</option>
													<option value="CG" >Congo (CG)</option>
													<option value="CK" >Cook Islands (CK)</option>
													<option value="CR" >Costa Rica (CR)</option>
													<option value="HR" >Croatia (Hrvatska) (HR)</option>
													<option value="CU" >Cuba (CU)</option>
													<option value="CY" >Cyprus (CY)</option>
													<option value="CZ" >Czech Republic (CZ)</option>
													<option value="DK" >Denmark (DK)</option>
													<option value="DJ" >Djibouti (DJ)</option>
													<option value="DM" >Dominica (DM)</option>
													<option value="DO" >Dominican Republic (DO)</option>
													<option value="TL" >East Timor (TL)</option>
													<option value="EC" >Ecuador (EC)</option>
													<option value="EG" >Egypt (EG)</option>
													<option value="SV" >El Salvador (SV)</option>
													<option value="GQ" >Equatorial Guinea (GQ)</option>
													<option value="ER" >Eritrea (ER)</option>
													<option value="EE" >Estonia (EE)</option>
													<option value="ET" >Ethiopia (ET)</option>
													<option value="FK" >Falkland Islands (Malvinas) (FK)</option>
													<option value="FO" >Faroe Islands (FO)</option>
													<option value="FJ" >Fiji (FJ)</option>
													<option value="FI" >Finland (FI)</option>
													<option value="FR" >France (FR)</option>
													<option value="FX" >France, Metropolitan (FX)</option>
													<option value="GF" >French Guiana (GF)</option>
													<option value="PF" >French Polynesia (PF)</option>
													<option value="GA" >Gabon (GA)</option>
													<option value="GM" >Gambia (GM)</option>
													<option value="GE" >Georgia (GE)</option>
													<option value="DE" >Germany (DE)</option>
													<option value="GH" >Ghana (GH)</option>
													<option value="GI" >Gibraltar (GI)</option>
													<option value="GR" >Greece (GR)</option>
													<option value="GL" >Greenland (GL)</option>
													<option value="GD" >Grenada (GD)</option>
													<option value="GP" >Guadeloupe (GP)</option>
													<option value="GU" >Guam (GU)</option>
													<option value="GT" >Guatemala (GT)</option>
													<option value="GN" >Guinea (GN)</option>
													<option value="GW" >Guinea-Bissau (GW)</option>
													<option value="GY" >Guyana (GY)</option>
													<option value="HT" >Haiti (HT)</option>
													<option value="HN" >Honduras (HN)</option>
													<option value="HK" >Hong Kong (HK)</option>
													<option value="HU" >Hungary (HU)</option>
													<option value="IS" >Iceland (IS)</option>
													<option value="ID" >Indonesia (ID)</option>
													<option value="IR" >Iran (Islamic Republic of) (IR)</option>
													<option value="IQ" >Iraq (IQ)</option>
													<option value="IE" >Ireland (IE)</option>
													<option value="IL" >Israel (IL)</option>
													<option value="IT" >Italy (IT)</option>
													<option value="CI" >Ivory Coast (CI)</option>
													<option value="JM" >Jamaica (JM)</option>
													<option value="JP" >Japan (JP)</option>
													<option value="JO" >Jordan (JO)</option>
													<option value="KZ" >Kazakhstan (KZ)</option>
													<option value="KE" >Kenya (KE)</option>
													<option value="KI" >Kiribati (KI)</option>
													<option value="KP" >Korea, Democratic People's Republic of (KP)</option>
													<option value="KR" >Korea, Republic of (KR)</option>
													<option value="XK" >Kosovo (XK)</option>
													<option value="KW" >Kuwait (KW)</option>
													<option value="KG" >Kyrgyzstan (KG)</option>
													<option value="LA" >Lao People's Democratic Republic (LA)</option>
													<option value="LV" >Latvia (LV)</option>
													<option value="LB" >Lebanon (LB)</option>
													<option value="LS" >Lesotho (LS)</option>
													<option value="LR" >Liberia (LR)</option>
													<option value="LY" >Libyan Arab Jamahiriya (LY)</option>
													<option value="LI" >Liechtenstein (LI)</option>
													<option value="LT" >Lithuania (LT)</option>
													<option value="LU" >Luxembourg (LU)</option>
													<option value="MO" >Macau (MO)</option>
													<option value="MK" >Macedonia (MK)</option>
													<option value="MG" >Madagascar (MG)</option>
													<option value="MW" >Malawi (MW)</option>
													<option value="MY" >Malaysia (MY)</option>
													<option value="MV" >Maldives (MV)</option>
													<option value="ML" >Mali (ML)</option>
													<option value="MT" >Malta (MT)</option>
													<option value="MH" >Marshall Islands (MH)</option>
													<option value="MQ" >Martinique (MQ)</option>
													<option value="MR" >Mauritania (MR)</option>
													<option value="MU" >Mauritius (MU)</option>
													<option value="TY" >Mayotte (TY)</option>
													<option value="MX" >Mexico (MX)</option>
													<option value="FM" >Micronesia, Federated States of (FM)</option>
													<option value="MD" >Moldova, Republic of (MD)</option>
													<option value="MC" >Monaco (MC)</option>
													<option value="MN" >Mongolia (MN)</option>
													<option value="ME" >Montenegro (ME)</option>
													<option value="MS" >Montserrat (MS)</option>
													<option value="MA" >Morocco (MA)</option>
													<option value="MZ" >Mozambique (MZ)</option>
													<option value="MM" >Myanmar (MM)</option>
													<option value="NA" >Namibia (NA)</option>
													<option value="NR" >Nauru (NR)</option>
													<option value="NP" >Nepal (NP)</option>
													<option value="NL" >Netherlands (NL)</option>
													<option value="AN" >Netherlands Antilles (AN)</option>
													<option value="NC" >New Caledonia (NC)</option>
													<option value="NZ" >New Zealand (NZ)</option>
													<option value="NI" >Nicaragua (NI)</option>
													<option value="NE" >Niger (NE)</option>
													<option value="NG" >Nigeria (NG)</option>
													<option value="NU" >Niue (NU)</option>
													<option value="NF" >Norfork Island (NF)</option>
													<option value="MP" >Northern Mariana Islands (MP)</option>
													<option value="NO" >Norway (NO)</option>
													<option value="OM" >Oman (OM)</option>
													<option value="PK" >Pakistan (PK)</option>
													<option value="PW" >Palau (PW)</option>
													<option value="PA" >Panama (PA)</option>
													<option value="PG" >Papua New Guinea (PG)</option>
													<option value="PY" >Paraguay (PY)</option>
													<option value="PE" >Peru (PE)</option>
													<option value="PH" >Philippines (PH)</option>
													<option value="PN" >Pitcairn (PN)</option>
													<option value="PL" >Poland (PL)</option>
													<option value="PT" >Portugal (PT)</option>
													<option value="PR" >Puerto Rico (PR)</option>
													<option value="QA" >Qatar (QA)</option>
													<option value="RE" >Reunion (RE)</option>
													<option value="RO" >Romania (RO)</option>
													<option value="RU" >Russian Federation (RU)</option>
													<option value="RW" >Rwanda (RW)</option>
													<option value="KN" >Saint Kitts and Nevis (KN)</option>
													<option value="LC" >Saint Lucia (LC)</option>
													<option value="VC" >Saint Vincent and the Grenadines (VC)</option>
													<option value="WS" >Samoa (WS)</option>
													<option value="SM" >San Marino (SM)</option>
													<option value="ST" >Sao Tome and Principe (ST)</option>
													<option value="SA" >Saudi Arabia (SA)</option>
													<option value="SN" >Senegal (SN)</option>
													<option value="RS" >Serbia (RS)</option>
													<option value="SC" >Seychelles (SC)</option>
													<option value="SL" >Sierra Leone (SL)</option>
													<option value="SG" >Singapore (SG)</option>
													<option value="SK" >Slovakia (SK)</option>
													<option value="SI" >Slovenia (SI)</option>
													<option value="SB" >Solomon Islands (SB)</option>
													<option value="SO" >Somalia (SO)</option>
													<option value="ZA" >South Africa (ZA)</option>
													<option value="GS" >South Georgia South Sandwich Islands (GS)</option>
													<option value="ES" >Spain (ES)</option>
													<option value="LK" >Sri Lanka (LK)</option>
													<option value="SH" >St. Helena (SH)</option>
													<option value="PM" >St. Pierre and Miquelon (PM)</option>
													<option value="SD" >Sudan (SD)</option>
													<option value="SR" >Suriname (SR)</option>
													<option value="SJ" >Svalbarn and Jan Mayen Islands (SJ)</option>
													<option value="SZ" >Swaziland (SZ)</option>
													<option value="SE" >Sweden (SE)</option>
													<option value="CH" >Switzerland (CH)</option>
													<option value="SY" >Syrian Arab Republic (SY)</option>
													<option value="TW" >Taiwan (TW)</option>
													<option value="TJ" >Tajikistan (TJ)</option>
													<option value="TZ" >Tanzania, United Republic of (TZ)</option>
													<option value="TH" >Thailand (TH)</option>
													<option value="TG" >Togo (TG)</option>
													<option value="TK" >Tokelau (TK)</option>
													<option value="TO" >Tonga (TO)</option>
													<option value="TT" >Trinidad and Tobago (TT)</option>
													<option value="TN" >Tunisia (TN)</option>
													<option value="TR" >Turkey (TR)</option>
													<option value="TM" >Turkmenistan (TM)</option>
													<option value="TC" >Turks and Caicos Islands (TC)</option>
													<option value="TV" >Tuvalu (TV)</option>
													<option value="UG" >Uganda (UG)</option>
													<option value="UA" >Ukraine (UA)</option>
													<option value="AE" >United Arab Emirates (AE)</option>
													<option value="GB" >United Kingdom (GB)</option>
													<option value="US" >United States (US)</option>
													<option value="UM" >United States minor outlying islands (UM)</option>
													<option value="UY" >Uruguay (UY)</option>
													<option value="UZ" >Uzbekistan (UZ)</option>
													<option value="VU" >Vanuatu (VU)</option>
													<option value="VA" >Vatican City State (VA)</option>
													<option value="VE" >Venezuela (VE)</option>
													<option value="VN" >Vietnam (VN)</option>
													<option value="VI" >Virgin Islands (U.S.) (VI)</option>
													<option value="VG" >Virigan Islands (British) (VG)</option>
													<option value="WF" >Wallis and Futuna Islands (WF)</option>
													<option value="EH" >Western Sahara (EH)</option>
													<option value="YE" >Yemen (YE)</option>
													<option value="YU" >Yugoslavia (YU)</option>
													<option value="ZM" >Zambia (ZM)</option>
													<option value="ZW" >Zimbabwe (ZW)</option>
											</select>
					 </label>
					 <label class="col-sm-6">
						<label class="mdc-text-field mdc-text-field--filled mdc-text-field--label-floating">
						  <span class="mdc-text-field__ripple"></span>
						  <input class="mdc-text-field__input" type="text" aria-labelledby="phn_no" pattern="[0-9]+" title="Only  number!" name="phone" required>
						  <span class="mdc-floating-label mdc-floating-label--float-above" id="phn_no">
							Mobile Number
						  </span>
						  <span class="mdc-line-ripple" style="color:#FF0000;">(*)</span>
						</label>
					 </label>
				</div>
				<div class="email_error text-center font-red"></div>
				<div class="row">		
					<label class="col-sm-10">
						
						<label class="mdc-text-field mdc-text-field--filled mdc-text-field--label-floating"  id="state">
						  <span class="mdc-text-field__ripple"></span>
						  <input class="mdc-text-field__input" type="text" aria-labelledby="lbl_state" name="state" pattern="[a-zA-Z ]*$">
						  <span class="mdc-floating-label mdc-floating-label--float-above" id="lbl_state">
							Enter Your State
						  </span>
						  <span class="mdc-line-ripple" style="color:#FF0000 !important;">(*)</span>
						</label>
						<select class="form-control" id="selstate" name="state">
						<option value="">---Select State---</option>
						<?php
						$stsql=mysqli_query($db,"select * from ind_states");
						while($strow=mysqli_fetch_object($stsql))
						{
						?>
						<option value="<?php echo $strow->state;?>"><?php echo $strow->state;?></option>
						<?php
						}
						?>
						</select>
					 </label>
					 <span class="col-sm-1" style="color:#FF0000;">(*)</span>
				</div>
				<div class="row">			
					 <label class="col-sm-10">
						<label class="mdc-text-field mdc-text-field--filled mdc-text-field--label-floating">
						  <span class="mdc-text-field__ripple"></span>
						  <input class="mdc-text-field__input" type="text" aria-labelledby="city" pattern="[a-zA-Z ]*$" name="city" required>
						  <span class="mdc-floating-label mdc-floating-label--float-above" id="city">
							Enter Your City
						  </span>
						  <span class="mdc-line-ripple" style="color:#FF0000;">(*)</span>
						</label>
					 </label>
				</div>
				<div class="row">
					 <label class="col-sm-10">
						<label class="mdc-text-field mdc-text-field--filled mdc-text-field--label-floating">
						  <span class="mdc-text-field__ripple"></span>
						  <input class="mdc-text-field__input" type="email" aria-labelledby="sign_email" name="email" required>
						  <span class="mdc-floating-label mdc-floating-label--float-above" id="sign_email">
							Enter Your Email
						  </span>
						  <span class="mdc-line-ripple" style="color:#FF0000;">(*)</span>
						</label>
					 </label>
				</div>
				
				<div class="pass_error text-center font-red"></div>
				<div class="row">
					 <label class="col-sm-10">
						<label class="mdc-text-field mdc-text-field--filled mdc-text-field--label-floating">
						  <span class="mdc-text-field__ripple"></span>
						  <input class="mdc-text-field__input" type="password" aria-labelledby="sign_pass" name="pass" required>
						  <span class="mdc-floating-label mdc-floating-label--float-above" id="sign_pass">
							Enter Your Password
						  </span>
						  <span class="mdc-line-ripple" style="color:#FF0000;">(*)</span>
						</label>
					 </label>
				</div>
				
				<div class="row text-center">
					<div id="signup_error" class="hide font14 fnone invalid margin-bottom-10"></div>
				</div>
				<div class="row text-center margin-bottom-20 padding-left-20">
					<span><input type="checkbox" id="chksignup"></span>&nbsp; By signing up, you agree to the <a id="terms_n_conditions" href="training_fee_policy.php">Training Fee Policy </a> &amp 
				<a href="gdpr_policy.php"> Gdpr Policy</a>
				</div>
				<div class="d-flex justify-content-center">
					<button class="btn btn-primary" id="signupbtn">Sign up</button>
				</div>
			</div>
			</form>
			<div class="modal-footer d-flex justify-content">
				<span class="linking">Already a member? <a href="javascript:multi_modal('login');">Login</a></span>
			</div>
		</div>
		
	</div>	
	</div>
</div>
	<div id="promotional" class="text-center ">
		<button id="close_promotion" type="button" class="close"><i class="icon-remove"></i></button>
<!--start - header-->
<div id="header-container"  class="shadow width-100" style="position:relative; height:auto !important;">
<div class="container">
	<nav class="navbar navbar-expand-lg navbar-light">
								
								<div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar">
       <i class="fa fa-bars" aria-hidden="true"></i>                     
      </button>
    </div>
			
							<a href="index.php" style="font-family:cursive; padding:20px; color:white; border:1px solid black; border-radius:50px;">Logo</a>&nbsp; &nbsp; &nbsp;
									            <div id="navbar" class="collapse navbar-collapse row pl-2">
			            <ul class="nav navbar-nav">
								<li id="search_panel" class="search_panel">
					<div class="input-group form-sm form-1 pl-0">
						
						<div class="input-group-append">
						<input class="form-control my-0 py-1 color-grey ui-autocomplete-input" type="text" placeholder="Search" aria-label="Search" id="all_course_search" class="search_course" onkeyup="shownHint(this.value)"><span class="input-group-text lighten-3" id="input-search-icon"><i class="fa fa-search" aria-hidden="true"></i></span>
						 </div>
						 
						 <div style="width:100%;background-color:white; height:auto; color:black; font-size:14px;" id="sncontent">
						 </div>
						
					</div>
				</li> 
				&nbsp;
				&nbsp;
				<li>
				  <?php
				    if(isset($_SESSION["user"]))
					{
						echo "<p style='color:green;'>Welcome ".ucwords($_SESSION["user"])." !</p>";
					}
						
				  ?>
				</li>
					            </ul>
            <ul class="nav navbar-nav ml-auto">
			<?php
			if(isset($_SESSION["user"]))
						 {
							 ?>
								<li class="nav-item dropdown sidebar">
					<a href="" class="nav-link dropdown-toggle" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">My Cart</a>
					<div class="dropdown-menu dropdown-primary font15" aria-labelledby="navbarDropdownMenuLink">
					   <?php
					     
							 $selsql=mysqli_query($db,"select * from course_sub where user_email='".$_SESSION["uemail"]."' and (end_date>='$cur' or end_date='')");
							 if(mysqli_num_rows($selsql)>0)
							 {
							 while($rowsel=mysqli_fetch_object($selsql))
							 {
								 if($rowsel->status=='approve')
								 {
					   ?>
						<a href="course_summary.php?cid=<?php echo $rowsel->course_id;?>" class="dropdown-item"><?php echo $rowsel->course_name."<span style='color:green; font-size:11px;'> Approved</span>";?></a>
						<?php
								 }
								 else
								 {
									 ?>
									 <a href="#" class="dropdown-item"><?php echo $rowsel->course_name."<span style='color:red; font-size:11px;'> Under Review</span>";?></a>
									 <?php
								 }
						     }
							 }
							 else
							 {
								 echo "<p style='padding:5px;'>No Items in your cart!</p>";
							 }
						?>
					</div>
				</li>
				<?php
						 }
						 ?>
								<li class="nav-item sidebar"><a class="nav-link" href="contact.php">Contact Us</a></li>
				
						<?php 
							   if(isset($_SESSION["user"]))
							   {
								   echo "<li class='nav-link'><a href='logout.php'>Logout</a></li>";
							   }
							   else
							   {
							   ?>			
								<li><a href="javascript:multi_modal('login');" class="nav-link">Login / Sign Up</a></li>
								<?php
							   }
							   ?>
				            </ul>
			
			          </div><!--/.nav-collapse -->
				    </nav>
	
	
	
	<div data-keyboard="false" tabindex="-1" class="modal fade" id="back-processing-modal" role="dialog" aria-hidden="true" aria-labelledby="procModalLabel">
    <div class="modal-dialog">
        <div class="processing modal-content" id="procModalLabel">
            <div class="modal-body">
                <div class="text-center">
                	<b>Sending Activation Link</b><br><br>
                </div>
            </div>
        </div>
    </div>
</div>
</div>

<div class="has-search search_panel hidden-md hidden-lg" id="search_panelmob" style="display:none;">
    <span class="fa fa-search form-control-feedback"></span>
    <input type="text" class="form-control" placeholder="Search" name="searchword" id="course_search" class="search_course">
  </div>
</div>

<!-- end header -->

<!-- Loading Modal -->




<!DOCTYPE html>
<style>
.deco_link{
    color: black !important;

}
.deco_link:hover,.deco_link:focus {
    color: blue!important;

}
.deco_link::after {
    content: '';
    display: block;
    width: 0;
    height: 2px;
    background: #black;
}


.deco_link:hover::after {
    width: 70%;
	margin-left:10px;
}
.button_hover:hover{
	color:#fff!important;
   font-size: 15px!important;
}
.blue-bg{
    background-image: linear-gradient(#1D3BB3, #1C76D7);
    border-radius:10px;
    padding:20px;
    color:#fff;
    height: 230px;
}
.blue-banner{
    background-image: linear-gradient(#1D3BB3, #1C76D7);
    color:#fff;
}
.card-bg{
    background-color: #fff;
    color:#fff;
    border-radius:10px;
    padding:20px;
    color:#1D3BB3;
    height: 230px;
}

.offering-icon{
    filter: invert(100%); 
  -webkit-filter:invert(100%);
}
.ourcenter-img{
    position: relative;
  color: white;
}
.img-text{
    position: absolute;
    bottom: 16px;
    left: 38px;
}
.btn-color{
    background-image: linear-gradient(to right, #EF9D23, #F16F1C);
    border-radius:6px;
    font-size:15px;
    font-weight:bold;
}
.award_text{
    color:#fff !important;
}
.awards-wrap {
  margin-top:150px; /* push the wrap down a bit. You might not need this */
  }

.awardico {
  margin-top:-30%; /* and push the image up a bit */
  width: 80%;
  height:85%;
}

@media only screen and (max-width: 600px) {
  .header_img img {
     display:none;
  }
  #homepage_background{
    background-image:url("images/header_mobile.png");;
     background-repeat: no-repeat;
  background-size: 100%;
  }
  .ourcenter-img img{
    width:100% !important;
  }
  .img-text{
    left:1%;
  }
  .img-text p{
    font-size:1rem !important;
    padding:10%
  }
  .acc-img{
    margin-top:10% !important;
  }
  .key-card{
    padding:10% !important;
  }
  .awardico {
    margin-top: 0%;
    width: 78%;
    height: 57%;
   }
   .media-bottom{
    display:none;
   }
   .awards-section{
        background-image:url("");
   }
}
</style>
<html lang="en">

<div class="jumbotron" style="background-color:white;">
<div class="row">
	<div class="col-lg-12">
		<h1>Training Fee Policy</h1>
		<hr>
		<p class="text-justify">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus vitae purus non odio finibus consectetur id vitae urna. Fusce at erat porta, maximus eros eu, mattis odio. Pellentesque vehicula blandit ante ut laoreet. Etiam eu tortor vel urna dapibus blandit eu vel odio. Donec faucibus mauris ac erat accumsan fringilla. Sed mollis id nulla elementum hendrerit. Nam sagittis nulla feugiat ex tempor pretium. Praesent a augue quis tellus euismod viverra non ac elit. Duis quis urna ultrices, venenatis eros et, convallis tellus. Fusce euismod lorem non diam dignissim, sit amet feugiat justo aliquam. Aenean vel sem vitae nunc fermentum feugiat. Pellentesque ut nulla ut leo pharetra iaculis ut sed lectus. Mauris bibendum vel est sed suscipit. Phasellus fermentum, mauris ut congue mattis, nisl lorem accumsan urna, in pellentesque elit ex interdum elit. Quisque accumsan elit id volutpat malesuada.</p>
	</div>
</div>
</div>

   <!-- Bootstrap core JavaScript --><!-- Footer Start -->
<div id="floating_footer" class="container">
	
	<div id="footer_sticky_bar">
				<a href="training_fee_policy.php" class="hideformob f_f_link">
			<span class="glyphicon glyphicon-wrench"></span>&nbsp;Training Fee Policy
		</a>
				<ul class="live_chat_div">
			<li class="call_no_stiky only_web">Call us: +44-1234567890</li>
			<li class="call_no_stiky only_mob" style="display:none;"><a href="tel:91-40-40035734"><span class="glyphicon glyphicon-earphone"></span>&nbsp;&nbsp;Call</a></li>
					</ul>
			</div>
</div>
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/jquery-ui-1.12.1.min.js"></script>
<script type="text/javascript" src="js/popper.min.js"></script>
<script type="text/javascript" src="js/bootstrap-v4.3.1.min.js"></script>
<script type="text/javascript" src="js/jquery.form.js"></script>
<script type="text/javascript" src="js/jquery.timeago.js"></script>
<script type="text/javascript" src="js/jstz.min.js"></script>
<script type="text/javascript" src="js/script.js?v=80.0"></script>
<script type="text/javascript" src="js/jquery.autosize.min.js"></script>
<script type="text/javascript" src="js/jquery.noty.packaged.min.js"></script>
<script type="text/javascript" src="js/star-rating.min.js"></script>
<script type="text/javascript" src="js/jquery.timeago.js"></script>
<script type="text/javascript" src="js/chat.js?v=80.0"></script>
<script type="text/javascript" src="js/select2.js?v=80.0"></script>
<script type="text/javascript" src="js/login_old.js?v=80.0"></script>

<script>
$("#signupbtn").attr("disabled",true);
$("#chksignup").click(function(){
	if($(this).prop("checked")==true)
	{
		$("#signupbtn").attr("disabled",false);
	}
	else
	{
		$("#signupbtn").attr("disabled",true);
	}
})
</script>

<script>
function showHint(str) {
    if (str.length == 0) {
        document.getElementById("scontent").innerHTML = "";
        return;
    } else {
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("scontent").innerHTML = this.responseText;
            }
        }
        xmlhttp.open("GET", "gethint.php?q="+str, true);
        xmlhttp.send();
    }
}
function shownHint(str) {
    if (str.length == 0) {
        document.getElementById("sncontent").innerHTML = "";
        return;
    } else {
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("sncontent").innerHTML = this.responseText;
            }
        }
        xmlhttp.open("GET", "gethint.php?q="+str, true);
        xmlhttp.send();
    }
}
</script>
<script>
$(document).ready(function(){
	if($("#country").val()=='IN')
	{
		$("#selstate").css("display","block")
		$("#state").css("display","none")
		$("#state").prop("disabled",true)
		$("#state").prop("required",false)
		$("#selstate").prop("disabled",false)
		$("#selstate").prop("required",true)
	}
	else
	{
		$("#selstate").css("display","none")
		$("#selstate").prop("disabled",true)
		$("#selstate").prop("required",false)
		$("#state").prop("disabled",false)
		$("#state").prop("required",true)
		$("#state").css("display","block")
	}
	
	$("#country").change(function(){
		if($(this).val()=='IN')
	{
		$("#selstate").css("display","block")
		$("#state").css("display","none")
		$("#state").prop("disabled",true)
		$("#state").prop("required",false)
		$("#selstate").prop("disabled",false)
		$("#selstate").prop("required",true)
	}
	else
	{
		$("#selstate").css("display","none")
		$("#selstate").prop("disabled",true)
		$("#selstate").prop("required",false)
		$("#state").prop("disabled",false)
		$("#state").prop("required",true)
		$("#state").css("display","block")
	}
	})
})
</script>
<script type="text/javascript">
			var timezone_offset_minutes = new Date().getTimezoneOffset();
timezone_offset_minutes = timezone_offset_minutes == 0 ? 0 : -timezone_offset_minutes;
			var dt = 'dt=' + timezone_offset_minutes;
			$.ajax({
			type : 'GET',
			url : 'get_timezone.php',
			data : dt,
			success:function(data){
			}
			
		});
		
</script>
<div style="display:none">
<script type="text/javascript" src="js/search_empty.js"></script>
</div>

</body>
</html>