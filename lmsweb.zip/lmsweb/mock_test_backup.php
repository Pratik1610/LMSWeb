<?php
 session_start();
 include "authentication.php";
 date_default_timezone_set("Asia/Kolkata");
 @$email=$_SESSION['uemail'];
 if( empty( $_SESSION['quiz'] ) )$_SESSION['quiz']=date('Y-m-d H:i:s');
 $cur=date("Y-m-d");
 if(!isset($email))
 {
	 echo "<script> alert('Please login First!') </script>";
	 echo "<script> window.location.href='index.php' </script>";
 }
 else
 {
	 @$mid=$_REQUEST["mid"];
				
				 // check whether user submitted their test already
				 @$chksql=mysqli_query($db,"select * from mock_session where uemail='$email' and test_date='$cur' and mock_id='".$mid."'");
				 @$chkrow=mysqli_fetch_object($chksql);
				 if(mysqli_num_rows($chksql)>0)
				 {
				 if($chkrow->status=='closed')
				 {
					 echo "<script> alert('You have already submitted your mock test for today!') </script>";
					 echo "<script> window.location.href='index.php' </script>";
				 }
				 }
 }
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>
	<title>Online Training on Professional Courses and Certifications by Experts</title>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" /> 

	<meta name="viewport" content="width=device-width, initial-scale=1"/>
	<meta name="title" content="Online Training on Professional Courses and Certifications by Experts"/>
	<meta name="description" content="Online Trainings from Experts to help Advance your Career"/>
	<meta name="author" content=""/>

	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	
	<meta property="fb:app_id" content="212429995547826" />
	<meta property="og:site_name" content="LMS" />
	<meta property="og:type" content="website" />
	<meta property="og:url" content="localhost/lms" />
	<meta property="og:image" content="" />
	<meta property="og:title" content="Online Training on Professional Courses and Certifications by Experts" />
	<meta property="og:description" content="Online Trainings from Experts to help Advance your Career" />
	<meta name="google-site-verification" content="2-7nt5nzoyujWWK_cE0JdA1pftuko_9Hiq5sMNx1JSU" />
	
	
	<link rel="shortcut icon" href="images/spectra-logo.jpg" type="image/x-icon"/>
	<link type="text/css" href="css/bootstrap-4.3.1.min.css" rel="stylesheet"/>
	<style>
	ul {
  list-style: none; /* Remove default bullets */
}

ul li{
	background-color:rgba(251,251,251,0.8);
	padding:10px;
	margin-top:10px;
	text-align:left;
	height:auto !important;
	font-size:18px;
}

ul li input{
	float:left;
}
ul li::before {
  content: "\2022";  /* Add content: \2022 is the CSS Code/unicode for a bullet */
  color: transparent; /* Change the color */
  font-weight: bold; /* If you want it to be bold */
  display: inline-block; /* Needed to add space between the bullet and the text */
  width: 1em; /* Also needed for space (tweak if needed) */
  margin-left: -1em; /* Also needed for space (tweak if needed) */
}
	</style>
	</head>
<body style="background-color:rgba(251,251,251,0.8);">

	<div id="promotional" class="text-center ">
<!-- Loading Modal -->




<!DOCTYPE html>
<html lang="en">
<div class="col-lg-12" style="height:auto; background-color:#007BFF;">
<a href="mock_view.php?mid=<?php echo $_REQUEST["mid"];?>" style="color:white;" class="btn btn-danger">Restart</a>
<div id="response" style="color:white;"></div>
</div>
   <div class="width-100" >
         <div class="container"><!--container start-->
		   <?php
		     if(isset($_REQUEST['mid']))
			 {
				  $mid=$_REQUEST["mid"];
				  $selmin=mysqli_query($db,"select min(id) as minid from mock_papers limit 120");
				 $rowmin=mysqli_fetch_object($selmin);
				 
				 $selmax=mysqli_query($db,"select max(id) as maxid from mock_papers limit 120");
				 $rowmax=mysqli_fetch_object($selmax);
				 
				 $rand=rand($rowmin->minid,$rowmax->maxid);
				 
				 
				 if(empty($_REQUEST["submit"])&&empty($_REQUEST["next"])&&empty($_REQUEST["review"]))
				 {
					 
				 $selq=mysqli_query($db,"select * from mock_papers where id='$rand' limit 1");
				 }
				 
				 if(isset($_REQUEST["review"]))
				 {
					 
					 $pid=$_REQUEST["pid"];
					  $selq=mysqli_query($db,"select * from mock_papers where id='$pid' limit 1");
				 }
				 
				 if(isset($_REQUEST["submit"]))
				 {
					 @$ans=$_REQUEST["ans"];
					 $pid=$_REQUEST["pid"];
					 if($ans===$_REQUEST["correct_ans"])
					 {
						 $cans="right";
					 }
					 else
					 {
						 $cans="wrong";
					 }
					 $scenario=addslashes($_REQUEST["scenario"]);
					 // $scenario=str_replace("'","''",$scenario);
					 
					 $que=addslashes($_REQUEST["que"]);
					 // $que=str_replace("'","''",$que);
					 
					 @$ans=addslashes($ans);
					 // $ans=str_replace("'","''",$ans);
					 $selq=mysqli_query($db,"select * from mock_papers where id='$pid' limit 1");
					 if(empty($ans))
					 {
						 					 $insql=mysqli_query($db,"insert into mock_sub(`id`,`user_email`,`mock_id`, `paper_id`,`scenario`,`que`,`ans`, `review_later`,`test_date`,`status`) values('','".$_SESSION["uemail"]."','$mid','".$_REQUEST["pid"]."','$scenario','$que','','true','".$_REQUEST["test_date"]."','')");
					 }
					 else
					 {
					 $insql=mysqli_query($db,"insert into mock_sub(`id`,`user_email`,`mock_id`, `paper_id`,`scenario`,`que`,`ans`, `review_later`,`test_date`,`status`) values('','".$_SESSION["uemail"]."','$mid','".$_REQUEST["pid"]."','$scenario','$que','$ans','false','".$_REQUEST["test_date"]."','$cans')");
					 }
				 }
				 
				 if(isset($_REQUEST["review"]))
				 {
					 $scenario=addslashes($_REQUEST["scenario"]);
					 // $scenario=str_replace("'","''",$scenario);
					 
					 $que=addslashes($_REQUEST["que"]);
					 // $que=str_replace("'","''",$que);
					 $insql=mysqli_query($db,"insert into mock_sub(`id`,`user_email`,`mock_id`, `paper_id`,`scenario`,`que`,`ans`, `review_later`,`test_date`,`status`) values('','".$_SESSION["uemail"]."','$mid','".$_REQUEST["pid"]."','$scenario','$que','','true','".$_REQUEST["test_date"]."','')");
				
				 }
				 
				  $arrpid=array();
				  if(isset($_REQUEST["pid"])&&isset($mid)&&isset($_REQUEST["next"]))
				 {
					 $sqlsub=mysqli_query($db,"select * from mock_sub where user_email='$email' and mock_id='$mid' and test_date='$cur'");
					 if(mysqli_num_rows($sqlsub)==120&&$mid==1)
					 {
						 echo "<script> window.location.href='summary_mock.php?mid=$mid' </script>";
					 }
					 elseif(mysqli_num_rows($sqlsub)==130&&$mid==2)
					 {
						 echo "<script> window.location.href='summary_mock.php?mid=$mid' </script>";
					 }
					 elseif(mysqli_num_rows($sqlsub)==50&&$mid==3)
					 {
						 echo "<script> window.location.href='summary_mock.php?mid=$mid' </script>";
					 }
					 else
					 {
						 // check if count of scenario based questions will be 5
						 $scnsql=mysqli_query($db,"select * from mock_sub where user_email='$email' and mock_id='$mid' and test_date='$cur' and scenario!=' '");
						 if(mysqli_num_rows($scnsql)==5)
						 {
							 $selq=mysqli_query($db,"select * from mock_papers where scenario=' ' order by rand() limit 1");
						 }
						 else
						 {
						 $selq=mysqli_query($db,"select * from mock_papers order by rand() limit 1");
						 }
						 
						 
					 }
				 }
				 $rowq=mysqli_fetch_object($selq);
		   ?>
			<div class="row">
			<div class="col-md-12" style="background-color:white; border:1px solid grey;">
			       <form action="mock_test.php" method="post">
				   <input type="hidden" name="mid" value="<?php echo $_REQUEST["mid"];?>">
				   <input type="hidden" name="id" value="<?php echo $rowq->id;?>">
				   <input type="hidden" name="pid" value="<?php echo $rowq->id;?>">
				   <input type="hidden" name="que" value="<?php echo $rowq->Que;?>">
				   <input type="hidden" name="scenario" value="<?php echo $rowq->scenario;?>">
				   <input type="hidden" name="test_date" value="<?php echo date("Y-m-d");?>">
				   <input type="hidden" name="correct_ans" value="<?php echo $rowq->correct_ans;?>">
				   <input type="hidden" name="ans_desc" value="<?php echo $rowq->ans_description;?>">
				   <label style="text-align:justify; font-size:18px;"><?php if(!empty($rowq->scenario)){?><span style="font-weight:bold; font-size:24px;">Scenario:</span><?php }?> <?php echo htmlspecialchars($rowq->scenario);?></label><br>
				   <label style="text-align:justify; float:left; font-size:18px;"> <span style="font-weight:bold; font-size:24px;">Question:</span> <?php echo htmlspecialchars($rowq->Que);?></label><br><br><br><br>
				   <ul>
				   <?php
				   if(!empty($rowq->ans1))
				   {
				   ?>
				   <li><input type="radio" name="ans" value="<?php echo $rowq->ans1;?>"><?php echo $rowq->ans1;?></li>
				   <?php
				   }
				   ?>
				   <?php
				   if(!empty($rowq->ans2))
				   {
				   ?>
				   <li><input type="radio" name="ans" value="<?php echo $rowq->ans2;?>"><?php echo $rowq->ans2;?></li>
				   <?php
				   }
				   ?>
				   <?php
				   if(!empty($rowq->ans3))
				   {
				   ?>
				   <li><input type="radio" name="ans" value="<?php echo $rowq->ans3;?>"><?php echo $rowq->ans3;?></li>
				   <?php
				   }
				   ?>
				   <?php
				   if(!empty($rowq->ans4))
				   {
				   ?>
				   <li><input type="radio" name="ans" value="<?php echo $rowq->ans4;?>"><?php echo $rowq->ans4;?></li>
				   <?php
				   }
				   ?>
				   <?php
				   if(!empty($rowq->ans5))
				   {
				   ?>
				   <li><input type="radio" name="ans" value="<?php echo $rowq->ans5;?>"><?php echo $rowq->ans5;?></li>
				   <?php
				   }
				   ?>
				   </ul>
				   <br>
				   <?php
				   if(!isset($_REQUEST["submit"])&&!isset($_REQUEST["review"]))
				   {
				   ?>
				    <input type="submit" id="submit" name="submit" value="Submit" class="btn"  style="border:1px solid black;">
					<?php
				   }
				   else
				   {
				   ?>
				   <input type="submit" id="submit" name="submit" value="Submit" class="btn"  style="border:1px solid black;" disabled>
				   <?php
				   }
				   ?>
				    <?php
				   if(!isset($_REQUEST["review"])&&!isset($_REQUEST["submit"]))
				   {
				   ?>
				    <input type="submit" id="review" name="review" value="Review Later" class="btn" style="border:1px solid black;">
				   <?php
				   }
				   else
				   {
				   ?>
				    <input type="submit" id="review" name="review" value="Review Later" class="btn" style="border:1px solid black;" disabled>
				   <?php
				   }
				   ?>
				   <?php
				   if(isset($_REQUEST["submit"]))
				   {
				   ?>
				    <input type="submit" id="next" name="next" value="Next" class="btn" style="border:1px solid black;">
					<?php
				   }
				   elseif(isset($_REQUEST["review"]))
				   {
				?>
					<input type="submit" name="next" value="Next" class="btn" style="border:1px solid black;">
				<?php
				   }
				   else
				   {
				   ?>
				   <input type="submit" id="next" name="next" value="Next" class="btn" style="border:1px solid black;" disabled>
				   <?php
				   }
				   ?>
				   <button id="review" class="btn" style="border:1px solid black;"><a href="summary_mock.php?mid=<?php echo $_REQUEST["mid"];?>" target="_blank" style="color:black;">Summary</a></button>
				   </form>
				   <br>
					<?php
					 if(isset($_REQUEST["submit"]))
					 {
						 @$ans=htmlspecialchars($_REQUEST["ans"]);
						 $cans=htmlspecialchars($_REQUEST["correct_ans"]);
						 $desc=htmlspecialchars($_REQUEST["ans_desc"]);
							  echo "<p> $desc, <span style='color:green;'>correct answer:</span> $cans</p>";

					 }
					?>
			</div>
			<?php
			 }
			 ?>
			</div>
			</div></div>
	  </div>
   </div>
   <!-- Bootstrap core JavaScript -->
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/jquery-ui-1.12.1.min.js"></script>
<script type="text/javascript" src="js/popper.min.js"></script>
<script type="text/javascript" src="js/bootstrap-v4.3.1.min.js"></script>
<script type="text/javascript" src="js/jquery.form.js"></script>
<script type="text/javascript" src="js/jquery.timeago.js"></script>
<script type="text/javascript" src="js/jstz.min.js"></script>
<script type="text/javascript" src="js/script.js?v=80.0"></script>
<script type="text/javascript" src="js/jquery.autosize.min.js"></script>
<script type="text/javascript" src="js/jquery.noty.packaged.min.js"></script>
<script type="text/javascript" src="js/star-rating.min.js"></script>
<script type="text/javascript" src="js/jquery.timeago.js"></script>
<script type="text/javascript" src="js/chat.js?v=80.0"></script>
<script type="text/javascript" src="js/select2.js?v=80.0"></script>
<script type="text/javascript" src="js/login_old.js?v=80.0"></script>

<script>
function showHint(str) {
    if (str.length == 0) {
        document.getElementById("scontent").innerHTML = "";
        return;
    } else {
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("scontent").innerHTML = this.responseText;
            }
        }
        xmlhttp.open("GET", "gethint.php?q="+str, true);
        xmlhttp.send();
    }
}
function shownHint(str) {
    if (str.length == 0) {
        document.getElementById("sncontent").innerHTML = "";
        return;
    } else {
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("sncontent").innerHTML = this.responseText;
            }
        }
        xmlhttp.open("GET", "gethint.php?q="+str, true);
        xmlhttp.send();
    }
}
</script>
<script type="text/javascript">
		setInterval(function(){
			var xmlhttp=new XMLHttpRequest();
			xmlhttp.open("GET","response.php",false)
			xmlhttp.send(null);
			document.getElementById("response").innerHTML=xmlhttp.responseText;
			
			
		if(xmlhttp.responseText=="00:00:00")
		{
			window.location.href="result.php?mid=<?php echo $mid; ?>";
		}
			
		},1000)
		
</script>
</body>
</html>