<?php
 session_start();
 include "authentication.php";
 // Asia/Kolkata
 @$timezone=$_SESSION["timezone"];

 @date_default_timezone_set("$timezone");
 
 $cur=date("Y-m-d");
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>
	<title>LMS | Webinar</title>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" /> 

	<meta name="viewport" content="width=device-width, initial-scale=1"/>
	<meta name="title" content="Online Training on Professional Courses and Certifications by Experts"/>
	<meta name="description" content="Online Trainings from Experts to help Advance your Career"/>
	<meta name="author" content=""/>

	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	
	<meta property="fb:app_id" content="212429995547826" />
	<meta property="og:site_name" content="LMS" />
	<meta property="og:type" content="website" />
	<meta property="og:url" content="localhost/lms" />
	<meta property="og:image" content="" />
	<meta property="og:title" content="Online Training on Professional Courses and Certifications by Experts" />
	<meta property="og:description" content="Online Trainings from Experts to help Advance your Career" />
	<meta name="google-site-verification" content="2-7nt5nzoyujWWK_cE0JdA1pftuko_9Hiq5sMNx1JSU" />
	
	
	<link rel="shortcut icon" href="images/user-placeholder.gif" type="image/x-icon"/>
	<link type="text/css" href="css/bootstrap-4.3.1.min.css" rel="stylesheet"/>
	<link type="text/css" href="css/star-rating.min.css" rel="stylesheet"/>
	<link type="text/css" href="css/select2.css" rel="stylesheet"/>
	<link type="text/css" href="css/jquery-ui-1.12.1.min.css" rel="stylesheet"/>
	<link type="text/css" href="css/style_new.css?v=80.0" rel="stylesheet"/>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<link href="https://cdn.jsdelivr.net/gh/gitbrent/bootstrap4-toggle@3.4.0/css/bootstrap4-toggle.min.css" rel="stylesheet">

	<link rel="stylesheet" href="css/frontpage.css?v=80.0" />
	<link href="https://unpkg.com/material-components-web@latest/dist/material-components-web.min.css" rel="stylesheet">
  <script src="https://unpkg.com/material-components-web@latest/dist/material-components-web.min.js"></script>
		
	<style>
	 h2{
			  font-size:28px;
		  }
	@media only screen and (max-width: 480px) {
		  body
		  {
			  margin-left:2.5em !important;
		  }
		  .col-lg-6
		  {
			  width:90% !important;
		  }
		  .lbox img{
			  height:300px !important;
			  width:100% !important;
		  }
		  .lbox{
			  padding-left:0.8em !important;
		  }
		  h2{
			  font-size:20px;
		  }
		  p{
			  font-size:14px;
		  }
		}
		
		@media only screen and (min-width: 481px) and (max-width: 600px) {
			body
		  {
			  margin-left:2.5em !important;
		  }
			.col-lg-6
		  {
			  width:90% !important;
		  }
			.lbox img{
			  width:100% !important;
		  }
		  .lbox{
			  padding-left:0.8em !important;
		  }
		  h2{
			  font-size:18px;
		  }
		  p{
			  font-size:12px;
		  }
		}
		@media only screen and (min-width: 601px) and (max-width: 768px) {
			body
		  {
			  margin-left:2.5em !important;
		  }
			.col-lg-6
		  {
			  width:90% !important;
		  }
			.lbox img{
			  width:100% !important;
		  }
		  .lbox{
			  padding-left:1em !important;
		  }
		  h2{
			  font-size:20px;
		  }
		  p{
			  font-size:14px;
		  }
		  /* For mobile phones: */
			  [class*="col-"] {
				width: 100%;
			}
		}
		@media only screen and (min-width: 769px) and (max-width: 1068px) {
			body
		  {
			  margin-left: 2.5em !important;
		  }
			.lbox img{
			  width:100% !important;
		  }
		  .lbox{
			  padding-left:1em !important;
		  }
		  h2{
			  font-size:24px;
		  }
		  p{
			  font-size:14px;
		  }
		}
	</style>
	</head>
<body  style="background-color:light-grey;">

<div class="container-fluid">
  <div class="row">
	<div class="col-lg-3">
	</div>
	<div class="col-lg-6" style="background-image:url(images/webinar-banner.png); background-size:cover; background-position:bottom; background-repeat:no-repeat; height:180px; width:50%; margin-top:10px; border-radius:5%;">
	</div>
  </div>
</div>

<div class="container-fluid">
  <div class="row">
	<div class="col-lg-3">
	</div>
	<div class="col-lg-6" style="background:white; border:1px solid grey; height:250px; width:50%; margin-top:10px; border-radius:5%;">
	<div style="background:#964B00; width:100%; height:10px; border-radius:5% !important; margin:5px; "></div>
	  <h2>LMS Webinars - Daily Webinar Series Start time : 8:00pm IST or 7:30am PDT or 4:30pm CEST or 10:30am EDT or 3:30pm BST</h2>
	  <p>This is LMS initiative.</p>
	  <p style="color:red;">* Required</p>
	</div>
  </div>
</div>

<form method="post" action="subscription_webinar.php">
<div class="container-fluid">
  <div class="row">
	<div class="col-lg-3">
	</div>
	<div class="col-lg-6" style="background:white; border:1px solid grey; height:150px; width:50%; margin-top:10px; border-radius:5%;">
		<div class="form-group">
		   <label class="mdc-text-field mdc-text-field--filled mdc-text-field--fullwidth">
				  <span class="mdc-text-field__ripple"></span>
				  <input class="mdc-text-field__input" type="email" aria-labelledby="email" placeholder="Email" name="email" required>
				  <span class="mdc-line-ripple" style="color:#FF0000;">(*)</span>
				</label>
		</div>
	 
	</div>
  </div>
</div>

<div class="container-fluid">
  <div class="row">
	<div class="col-lg-3">
	</div>
	<div class="col-lg-6" style="background:white; border:1px solid grey; height:auto; width:50%; margin-top:10px; border-radius:5%;">
		<div class="form-group">
		   <label>Choose to join webinars <span style="color:red;">*</span></label>
		   <input type="radio" name="type" value="Daily" required>&nbsp;Daily [Cost : 1,111 INR / 15 USD / 12 GBP]<br><br>
		   <input type="radio" name="type"  value="Weekly" required>&nbsp;Weekly [Cost : 5,555 INR / 74 USD / 59 GBP]<br><br>
		   <input type="radio" name="type"  value="Monthly" required>&nbsp;Monthly [ Cost : 22,222 INR / 295 USD / 236 GBP]<br><br>
		</div>
	 
	</div>
  </div>
</div>

<div class="container-fluid">
  <div class="row">
	<div class="col-lg-3">
	</div>
	<div class="col-lg-6" style="background:white; border:1px solid grey; height:150px; width:50%; margin-top:10px; border-radius:5%;">
		<div class="form-group">
		    <label class="mdc-text-field mdc-text-field--filled mdc-text-field--fullwidth">
				  <span class="mdc-text-field__ripple"></span>
				  <input class="mdc-text-field__input" type="text" aria-labelledby="contdetail" placeholder="Name and Contact - Cell# or WhatsApp#" name="contdetail" required>
				  <span class="mdc-line-ripple" style="color:#FF0000;">(*)</span>
				</label>
		</div>
	 
	</div>
  </div>
</div>

<div class="container-fluid">
  <div class="row">
	<div class="col-lg-3">
	</div>
	<div class="col-lg-6 lbox" style="background:white; border:1px solid grey; height:auto; width:50%; margin-top:10px; padding-top:2em; padding-left:2em; padding-bottom:2em; border-radius:5%;">
		 <!--<img src="images/webinar-banner2.png" alt="lower banner" class="img-responsive">-->
		 <div style="border:1px solid black; border-radius:50px; background-color:rgba(0,0,0,0.7); color:white; text-align:center; height:100px; padding-top:20px;"><h3>Banner</h3></div>
	</div>
  </div>
</div>

<div class="container-fluid">
<div class="row">
<div class="col-lg-3">
	</div>
	<div class="col-lg-6">
<input type="submit" name="submit" class="btn" value="Submit" style="background-color:#964B00; margin:1.6em; boder:1px solid black; color:white;">
     </div>	 
</div>
</div>
</form>
<script type="text/javascript">
			var timezone_offset_minutes = new Date().getTimezoneOffset();
timezone_offset_minutes = timezone_offset_minutes == 0 ? 0 : -timezone_offset_minutes;
			var dt = 'dt=' + timezone_offset_minutes;
			$.ajax({
			type : 'GET',
			url : 'get_timezone.php',
			data : dt,
			success:function(data){
			}
			
		});
		
</script>
</body>
</html>