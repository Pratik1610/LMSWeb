<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>
	<title>Online Training on Professional Courses and Certifications by Experts</title>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" /> 

	<meta name="viewport" content="width=device-width, initial-scale=1"/>
	<meta name="title" content="Online Training on Professional Courses and Certifications by Experts"/>
	<meta name="description" content="Online Trainings from Experts to help Advance your Career"/>
	<meta name="author" content=""/>

	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	
	<meta property="fb:app_id" content="212429995547826" />
	<meta property="og:site_name" content="LMS" />
	<meta property="og:type" content="website" />
	<meta property="og:url" content="localhost/lms" />
	<meta property="og:image" content="" />
	<meta property="og:title" content="Online Training on Professional Courses and Certifications by Experts" />
	<meta property="og:description" content="Online Trainings from Experts to help Advance your Career" />
	<meta name="google-site-verification" content="2-7nt5nzoyujWWK_cE0JdA1pftuko_9Hiq5sMNx1JSU" />
	
	
	<link rel="shortcut icon" href="#" type="image/x-icon"/>
	<link type="text/css" href="css/bootstrap-4.3.1.min.css" rel="stylesheet"/>
	<link type="text/css" href="css/star-rating.min.css" rel="stylesheet"/>
	<link type="text/css" href="css/select2.css" rel="stylesheet"/>
	<link type="text/css" href="css/jquery-ui-1.12.1.min.css" rel="stylesheet"/>
	<link type="text/css" href="css/style_new.css?v=80.0" rel="stylesheet"/>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<link href="https://cdn.jsdelivr.net/gh/gitbrent/bootstrap4-toggle@3.4.0/css/bootstrap4-toggle.min.css" rel="stylesheet">
	<link rel="stylesheet" href="css/frontpage.css?v=80.0" />
		
	<style>
		.btn-outline {
			background-color: transparent;
			color: inherit;
			transition: all .5s;
			border:0px;
		}
		.multi_modal_right_signup {
			float: left;
			border-left: 0px solid #e5e5e5;
			margin-left: 20%;
			margin-right: 20%;
		}
		/*uncomment banner once banner is removed*/
		
	</style>
	</head>
<body  >
<div class="modal fade" id="request_callback" tabindex="-1" role="dialog" aria-labelledby="requestCallbackModal" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<h3 id="requestCallbackModal">Request a Callback</h3>
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
			</div>
			<form class="form-horizontal" id="request_callback_form" action="#" method="POST" onsubmit="return false;">
				<input type="hidden" name="url" value="localhost/lms/" >
				<div class="modal-body">
					<div class="alert alert-danger text-center hide" role="alert">
						<span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
						<span class="sr-only">Error:</span>
						<span id="callback_error_msg"></span>
					</div>
					<div class="form-group">
						<div class="row">
							<div class="col-sm-offset-3 col-sm-6">
							<span class="fright font-red">(* required fields)</span>
							</div>
						</div>
					</div>
					<div class="form-group">
					<div class="row">
						<label for="callback_inputName" class="col-sm-5 control-label">Name <span class="font-red">*</span></label>
						<div class="col-sm-7">
							<input type="text" class="form-control" name="name" id="callback_inputName" placeholder="Name" title="Please enter your name" required>
						</div>
						</div>
					</div>
					<div class="form-group">
						<div class="row">
							<label for="callback_inputEmail" class="col-sm-5 control-label">Email <span class="font-red">*</span></label>
							<div class="col-sm-7">
								<input type="email" class="form-control" name="email" id="callback_inputEmail" placeholder="Email Address" title="Please enter your email address" required>
							</div>
						</div>
					</div>
					<div class="form-group">
						<div class="row">
							<label for="callback_inputMobile" class="col-sm-5 control-label">Contact Number <span class="font-red">*</span></label>
							<div class="col-sm-7">
								<input type="text" class="form-control" name="contact" id="callback_inputMobile" placeholder="Contact Number" title="Please enter a valid contact number" required>
							</div>
						</div>
					</div>
					<div class="form-group">
						<div class="row">
							<label for="textareaReason" class="col-sm-5 control-label">Query <span class="font-red">*</span></label>
							<div class="col-sm-7">
								<textarea class="resize-none form-control" name="query" id="textareaReason" placeholder="Your Query" title="Please enter your query" required></textarea>
							</div>
						</div>
					</div>
				</div>
				<div class="clearfix"></div>
				<div class="modal-footer">
					<button type="submit" class="btn btn-success" id="req_call_back">Submit</button>
				</div>
			</form>
		</div>
	</div>
</div>
<div class="modal fade" id="login" role="dialog" aria-labelledby="loginModal" aria-hidden="true">
	<input type="hidden" id="modal_param" value="no" >	
	<div class="modal-dialog modal-lg">
		<div class="modal-content hide" id="modal_login">
			<div class="modal-header text-center">
				<h4 class="modal-title w-100 font-weight-bold">Login to Our Site</h4>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			
			<form id="signin_modal" action="login_user.php" method="post">
				<div class="modal-body mx-3">
					<div class="row">
						<div class="col-sm-1 margin-auto font35">
							<i class="fa fa-envelope-open prefix grey-text"></i>
						</div>			
						<label class="col-sm-11">
							<p class="label-txt">ENTER YOUR EMAIL</p>
							<input type="text" class="input" id="username_m" name="username_m">
							<div class="line-box">
								<div class="line"></div>
							</div>
						 </label>
					</div>
					<div class="row">
						<div class="col-sm-1 margin-auto font35">
							<i class="fa fa-lock prefix grey-text"></i>
						</div>			
						<label class="col-sm-11">
							<p class="label-txt">ENTER YOUR PASSWORD</p>
							<input type="password" class="input" id="password_m" name="password_m">
							<div class="line-box">
								<div class="line"></div>
							</div>
						 </label>
					</div>
					<div class="input-group margin-bottom-10">
						<small class="fright"><a href="javascript:multi_modal('forget');">Forgot Password?</a></small>
					</div>
					<div class="d-flex justify-content-center">
						<button class="btn btn-primary">Login</button>
					</div>
					<div class="input-group margin-top-10 invalid font14 margin-bottom-10" id="messages"></div>
				</div> 
				<div class="clearfix"></div>
				<div class="modal-footer">
					<span class="linking">New to Our Site? <a href="javascript:multi_modal('signup');">Sign Up</a></span>
				</div>
			</form>
		</div>
		<div class="modal-content hide" id="modal_forget">
			<div class="processing modal-content hide" id="forg_proc">
				<div class="modal-body">
					<div class="text-center">
						<b>Sending Activation Link</b>
					</div>
				</div>
			</div>
			<div class="modal-header text-center">
				<h4 class="modal-title w-100 font-weight-bold">Forgot your password ?</h4>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			
			<form name="forget_password" id="forget_password" method="GET" action="#" onsubmit="return false;">
				<div class="modal-body">
					<div class="fnone invalid font14 margin-left-35 margin-right-35 margin-bottom-10" id="invalid_id"></div>
					<div class="row">
						<div class="col-sm-1 margin-auto font35">
							<i class="fa fa-envelope-open prefix grey-text"></i>
						</div>			
						<label class="col-sm-11">
							<p class="label-txt">ENTER YOUR EMAIL</p>
							<input type="text" class="input" id="username" name="username">
							<div class="line-box">
								<div class="line"></div>
							</div>
						 </label>
					</div>
					<div class="text-center">
						On Clicking <strong class="label label-success">Forgot Password</strong>, we will send you a password reset email .	
					</div>
				</div>
				<div class="modal-footer">
					<button type="submit" class="btn btn-success">Forgot Password</button>
					<button type="button" class="btn btn-info" data-dismiss="modal">Cancel</button>
				</div>
			</form>
		</div>
		
		<div class="modal-content hide" id="modal_signup">
			<div class="modal-header text-center">
				<h4 class="modal-title w-100 font-weight-bold">Sign Up and Start Learning</h4>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<form method="post" action="reg_user.php">
			<input type="hidden" name="ProspectID" id="ProspectID" value="" />
			<input type="hidden" name="country_id" value="">				
			<div class="modal-body mx-3">
			<div class="first_name_error text-center font-red"></div>
			<div class="row">
					<div class="col-sm-1 margin-auto font35">
						<i class="fa fa-user prefix grey-text"></i>	
					</div>			
					<label class="col-sm-11">
						
						<input type="text" class="input" name="name" placeholder="ENTER YOUR NAME" id="first_name">
						<div class="line-box">
							<div class="line"></div>
						</div>
					 </label>
				</div>
				<div class="phone_error text-center font-red"></div>
				<div class="row">
									<select id="country_dropdown" class="form-control col-sm-1 font14 margin-auto" name="country">
													<option value="93#AF#3" >Afghanistan (AF)</option>
													<option value="355#AL#4" >Albania (AL)</option>
													<option value="213#DZ#5" >Algeria (DZ)</option>
													<option value="1684#AS#6" >American Samoa (AS)</option>
													<option value="376#AD#7" >Andorra (AD)</option>
													<option value="244#AO#8" >Angola (AO)</option>
													<option value="1264#AI#9" >Anguilla (AI)</option>
													<option value="672#AQ#10" >Antarctica (AQ)</option>
													<option value="1268#AG#11" >Antigua and Barbuda (AG)</option>
													<option value="54#AR#12" >Argentina (AR)</option>
													<option value="374#AM#13" >Armenia (AM)</option>
													<option value="297#AW#14" >Aruba (AW)</option>
													<option value="61#AU#15" >Australia (AU)</option>
													<option value="43#AT#16" >Austria (AT)</option>
													<option value="994#AZ#17" >Azerbaijan (AZ)</option>
													<option value="1242#BS#18" >Bahamas (BS)</option>
													<option value="973#BH#19" >Bahrain (BH)</option>
													<option value="880#BD#20" >Bangladesh (BD)</option>
													<option value="1246#BB#21" >Barbados (BB)</option>
													<option value="375#BY#22" >Belarus (BY)</option>
													<option value="32#BE#23" >Belgium (BE)</option>
													<option value="501#BZ#24" >Belize (BZ)</option>
													<option value="229#BJ#25" >Benin (BJ)</option>
													<option value="1441#BM#26" >Bermuda (BM)</option>
													<option value="975#BT#27" >Bhutan (BT)</option>
													<option value="591#BO#28" >Bolivia (BO)</option>
													<option value="387#BA#29" >Bosnia and Herzegovina (BA)</option>
													<option value="267#BW#30" >Botswana (BW)</option>
													<option value="55#BR#32" >Brazil (BR)</option>
													<option value="246#IO#33" >British lndian Ocean Territory (IO)</option>
													<option value="673#BN#34" >Brunei Darussalam (BN)</option>
													<option value="359#BG#35" >Bulgaria (BG)</option>
													<option value="226#BF#36" >Burkina Faso (BF)</option>
													<option value="257#BI#37" >Burundi (BI)</option>
													<option value="855#KH#38" >Cambodia (KH)</option>
													<option value="237#CM#39" >Cameroon (CM)</option>
													<option value="1#CA#2" >Canada (CA)</option>
													<option value="238#CV#40" >Cape Verde (CV)</option>
													<option value="1345#KY#41" >Cayman Islands (KY)</option>
													<option value="236#CF#42" >Central African Republic (CF)</option>
													<option value="235#TD#43" >Chad (TD)</option>
													<option value="56#CL#44" >Chile (CL)</option>
													<option value="86#CN#45" >China (CN)</option>
													<option value="61#CX#46" >Christmas Island (CX)</option>
													<option value="61#CC#47" >Cocos (Keeling) Islands (CC)</option>
													<option value="57#CO#48" >Colombia (CO)</option>
													<option value="269#KM#49" >Comoros (KM)</option>
													<option value="242#CG#50" >Congo (CG)</option>
													<option value="682#CK#51" >Cook Islands (CK)</option>
													<option value="506#CR#52" >Costa Rica (CR)</option>
													<option value="385#HR#53" >Croatia (Hrvatska) (HR)</option>
													<option value="53#CU#54" >Cuba (CU)</option>
													<option value="357#CY#55" >Cyprus (CY)</option>
													<option value="420#CZ#56" >Czech Republic (CZ)</option>
													<option value="45#DK#57" >Denmark (DK)</option>
													<option value="253#DJ#58" >Djibouti (DJ)</option>
													<option value="1767#DM#59" >Dominica (DM)</option>
													<option value="1809#DO#60" >Dominican Republic (DO)</option>
													<option value="670#TL#61" >East Timor (TL)</option>
													<option value="593#EC#62" >Ecuador (EC)</option>
													<option value="20#EG#63" >Egypt (EG)</option>
													<option value="503#SV#64" >El Salvador (SV)</option>
													<option value="240#GQ#65" >Equatorial Guinea (GQ)</option>
													<option value="291#ER#66" >Eritrea (ER)</option>
													<option value="372#EE#67" >Estonia (EE)</option>
													<option value="251#ET#68" >Ethiopia (ET)</option>
													<option value="500#FK#69" >Falkland Islands (Malvinas) (FK)</option>
													<option value="298#FO#70" >Faroe Islands (FO)</option>
													<option value="679#FJ#71" >Fiji (FJ)</option>
													<option value="358#FI#72" >Finland (FI)</option>
													<option value="33#FR#73" >France (FR)</option>
													<option value="44#FX#74" >France, Metropolitan (FX)</option>
													<option value="594#GF#75" >French Guiana (GF)</option>
													<option value="689#PF#76" >French Polynesia (PF)</option>
													<option value="241#GA#78" >Gabon (GA)</option>
													<option value="220#GM#79" >Gambia (GM)</option>
													<option value="995#GE#80" >Georgia (GE)</option>
													<option value="49#DE#81" >Germany (DE)</option>
													<option value="233#GH#82" >Ghana (GH)</option>
													<option value="350#GI#83" >Gibraltar (GI)</option>
													<option value="30#GR#84" >Greece (GR)</option>
													<option value="299#GL#85" >Greenland (GL)</option>
													<option value="1473#GD#86" >Grenada (GD)</option>
													<option value="590#GP#87" >Guadeloupe (GP)</option>
													<option value="1671#GU#88" >Guam (GU)</option>
													<option value="502#GT#89" >Guatemala (GT)</option>
													<option value="224#GN#90" >Guinea (GN)</option>
													<option value="245#GW#91" >Guinea-Bissau (GW)</option>
													<option value="592#GY#92" >Guyana (GY)</option>
													<option value="509#HT#93" >Haiti (HT)</option>
													<option value="504#HN#95" >Honduras (HN)</option>
													<option value="852#HK#96" >Hong Kong (HK)</option>
													<option value="36#HU#97" >Hungary (HU)</option>
													<option value="354#IS#98" >Iceland (IS)</option>
													<option value="91#IN#99" >India (IN)</option>
													<option value="62#ID#100" >Indonesia (ID)</option>
													<option value="98#IR#101" >Iran (Islamic Republic of) (IR)</option>
													<option value="964#IQ#102" >Iraq (IQ)</option>
													<option value="353#IE#103" >Ireland (IE)</option>
													<option value="972#IL#104" >Israel (IL)</option>
													<option value="39#IT#105" >Italy (IT)</option>
													<option value="225#CI#106" >Ivory Coast (CI)</option>
													<option value="1876#JM#107" >Jamaica (JM)</option>
													<option value="81#JP#108" >Japan (JP)</option>
													<option value="962#JO#109" >Jordan (JO)</option>
													<option value="7#KZ#110" >Kazakhstan (KZ)</option>
													<option value="254#KE#111" >Kenya (KE)</option>
													<option value="686#KI#112" >Kiribati (KI)</option>
													<option value="850#KP#113" >Korea, Democratic People's Republic of (KP)</option>
													<option value="82#KR#114" >Korea, Republic of (KR)</option>
													<option value="383#XK#240" >Kosovo (XK)</option>
													<option value="965#KW#115" >Kuwait (KW)</option>
													<option value="996#KG#116" >Kyrgyzstan (KG)</option>
													<option value="856#LA#117" >Lao People's Democratic Republic (LA)</option>
													<option value="371#LV#118" >Latvia (LV)</option>
													<option value="961#LB#119" >Lebanon (LB)</option>
													<option value="266#LS#120" >Lesotho (LS)</option>
													<option value="231#LR#121" >Liberia (LR)</option>
													<option value="218#LY#122" >Libyan Arab Jamahiriya (LY)</option>
													<option value="423#LI#123" >Liechtenstein (LI)</option>
													<option value="370#LT#124" >Lithuania (LT)</option>
													<option value="352#LU#125" >Luxembourg (LU)</option>
													<option value="853#MO#126" >Macau (MO)</option>
													<option value="389#MK#127" >Macedonia (MK)</option>
													<option value="261#MG#128" >Madagascar (MG)</option>
													<option value="265#MW#129" >Malawi (MW)</option>
													<option value="60#MY#130" >Malaysia (MY)</option>
													<option value="960#MV#131" >Maldives (MV)</option>
													<option value="223#ML#132" >Mali (ML)</option>
													<option value="356#MT#133" >Malta (MT)</option>
													<option value="692#MH#134" >Marshall Islands (MH)</option>
													<option value="596#MQ#135" >Martinique (MQ)</option>
													<option value="222#MR#136" >Mauritania (MR)</option>
													<option value="230#MU#137" >Mauritius (MU)</option>
													<option value="262#TY#138" >Mayotte (TY)</option>
													<option value="52#MX#139" >Mexico (MX)</option>
													<option value="691#FM#140" >Micronesia, Federated States of (FM)</option>
													<option value="373#MD#141" >Moldova, Republic of (MD)</option>
													<option value="377#MC#142" >Monaco (MC)</option>
													<option value="976#MN#143" >Mongolia (MN)</option>
													<option value="382#ME#243" >Montenegro (ME)</option>
													<option value="1664#MS#144" >Montserrat (MS)</option>
													<option value="212#MA#145" >Morocco (MA)</option>
													<option value="258#MZ#146" >Mozambique (MZ)</option>
													<option value="95#MM#147" >Myanmar (MM)</option>
													<option value="264#NA#148" >Namibia (NA)</option>
													<option value="674#NR#149" >Nauru (NR)</option>
													<option value="977#NP#150" >Nepal (NP)</option>
													<option value="31#NL#151" >Netherlands (NL)</option>
													<option value="599#AN#152" >Netherlands Antilles (AN)</option>
													<option value="687#NC#153" >New Caledonia (NC)</option>
													<option value="64#NZ#154" >New Zealand (NZ)</option>
													<option value="505#NI#155" >Nicaragua (NI)</option>
													<option value="227#NE#156" >Niger (NE)</option>
													<option value="234#NG#157" >Nigeria (NG)</option>
													<option value="683#NU#158" >Niue (NU)</option>
													<option value="672#NF#159" >Norfork Island (NF)</option>
													<option value="1670#MP#160" >Northern Mariana Islands (MP)</option>
													<option value="47#NO#161" >Norway (NO)</option>
													<option value="968#OM#162" >Oman (OM)</option>
													<option value="92#PK#163" >Pakistan (PK)</option>
													<option value="680#PW#164" >Palau (PW)</option>
													<option value="507#PA#165" >Panama (PA)</option>
													<option value="675#PG#166" >Papua New Guinea (PG)</option>
													<option value="595#PY#167" >Paraguay (PY)</option>
													<option value="51#PE#168" >Peru (PE)</option>
													<option value="63#PH#169" >Philippines (PH)</option>
													<option value="870#PN#170" >Pitcairn (PN)</option>
													<option value="48#PL#171" >Poland (PL)</option>
													<option value="351#PT#172" >Portugal (PT)</option>
													<option value="1#PR#173" >Puerto Rico (PR)</option>
													<option value="974#QA#174" >Qatar (QA)</option>
													<option value="262#RE#175" >Reunion (RE)</option>
													<option value="40#RO#176" >Romania (RO)</option>
													<option value="7#RU#177" >Russian Federation (RU)</option>
													<option value="250#RW#178" >Rwanda (RW)</option>
													<option value="1869#KN#179" >Saint Kitts and Nevis (KN)</option>
													<option value="1758#LC#180" >Saint Lucia (LC)</option>
													<option value="1784#VC#181" >Saint Vincent and the Grenadines (VC)</option>
													<option value="685#WS#182" >Samoa (WS)</option>
													<option value="378#SM#183" >San Marino (SM)</option>
													<option value="239#ST#184" >Sao Tome and Principe (ST)</option>
													<option value="966#SA#185" >Saudi Arabia (SA)</option>
													<option value="221#SN#186" >Senegal (SN)</option>
													<option value="381#RS#386" >Serbia (RS)</option>
													<option value="248#SC#187" >Seychelles (SC)</option>
													<option value="232#SL#188" >Sierra Leone (SL)</option>
													<option value="65#SG#189" >Singapore (SG)</option>
													<option value="421#SK#190" >Slovakia (SK)</option>
													<option value="386#SI#191" >Slovenia (SI)</option>
													<option value="677#SB#192" >Solomon Islands (SB)</option>
													<option value="252#SO#193" >Somalia (SO)</option>
													<option value="27#ZA#194" >South Africa (ZA)</option>
													<option value="500#GS#195" >South Georgia South Sandwich Islands (GS)</option>
													<option value="34#ES#196" >Spain (ES)</option>
													<option value="94#LK#197" >Sri Lanka (LK)</option>
													<option value="290#SH#198" >St. Helena (SH)</option>
													<option value="508#PM#199" >St. Pierre and Miquelon (PM)</option>
													<option value="249#SD#200" >Sudan (SD)</option>
													<option value="597#SR#201" >Suriname (SR)</option>
													<option value="47#SJ#202" >Svalbarn and Jan Mayen Islands (SJ)</option>
													<option value="268#SZ#203" >Swaziland (SZ)</option>
													<option value="46#SE#204" >Sweden (SE)</option>
													<option value="41#CH#205" >Switzerland (CH)</option>
													<option value="963#SY#206" >Syrian Arab Republic (SY)</option>
													<option value="886#TW#207" >Taiwan (TW)</option>
													<option value="992#TJ#208" >Tajikistan (TJ)</option>
													<option value="255#TZ#209" >Tanzania, United Republic of (TZ)</option>
													<option value="66#TH#210" >Thailand (TH)</option>
													<option value="228#TG#211" >Togo (TG)</option>
													<option value="690#TK#212" >Tokelau (TK)</option>
													<option value="676#TO#213" >Tonga (TO)</option>
													<option value="1868#TT#214" >Trinidad and Tobago (TT)</option>
													<option value="216#TN#215" >Tunisia (TN)</option>
													<option value="90#TR#216" >Turkey (TR)</option>
													<option value="993#TM#217" >Turkmenistan (TM)</option>
													<option value="1649#TC#218" >Turks and Caicos Islands (TC)</option>
													<option value="688#TV#219" >Tuvalu (TV)</option>
													<option value="256#UG#220" >Uganda (UG)</option>
													<option value="380#UA#221" >Ukraine (UA)</option>
													<option value="971#AE#222" >United Arab Emirates (AE)</option>
													<option value="44#GB#223" >United Kingdom (GB)</option>
													<option value="1#US#1" >United States (US)</option>
													<option value="246#UM#224" >United States minor outlying islands (UM)</option>
													<option value="598#UY#225" >Uruguay (UY)</option>
													<option value="998#UZ#226" >Uzbekistan (UZ)</option>
													<option value="678#VU#227" >Vanuatu (VU)</option>
													<option value="39#VA#228" >Vatican City State (VA)</option>
													<option value="58#VE#229" >Venezuela (VE)</option>
													<option value="84#VN#230" >Vietnam (VN)</option>
													<option value="1340#VI#232" >Virgin Islands (U.S.) (VI)</option>
													<option value="1284#VG#231" >Virigan Islands (British) (VG)</option>
													<option value="681#WF#233" >Wallis and Futuna Islands (WF)</option>
													<option value="212#EH#234" >Western Sahara (EH)</option>
													<option value="967#YE#235" >Yemen (YE)</option>
													<option value="38#YU#236" >Yugoslavia (YU)</option>
													<option value="260#ZM#238" >Zambia (ZM)</option>
													<option value="263#ZW#239" >Zimbabwe (ZW)</option>
											</select>
					<span id="show_country_phone" class="input-group-addon col-sm-1 margin-auto">+</span>					
					<label class="col-sm-10">
						<input type="text" class="input" name="phone" id="phn_no" placeholder="ENTER YOUR PHONE NUMBER" >
						<div class="line-box">
							<div class="line"></div>
						</div>
					 </label>
				</div>
				<div class="email_error text-center font-red"></div>
				<div class="row">
					<div class="col-sm-1 margin-auto font35">
						<i class="fa fa-envelope-open prefix grey-text"></i>
					</div>			
					<label class="col-sm-11">
						<input type="text" class="input" name="email" placeholder="ENTER YOUR EMAIL" id="email">
						<div class="line-box">
							<div class="line"></div>
						</div>
					 </label>
				</div>
				
				<div class="pass_error text-center font-red"></div>
				<div class="row">
					<div class="col-sm-1 margin-auto font35">
						<i class="fa fa-lock prefix grey-text"></i>
					</div>			
					<label class="col-sm-11">
						<input type="password" class="input" name="pass" placeholder="ENTER YOUR PASSWORD" id="pass">
						<div class="line-box">
							<div class="line"></div>
						</div>
					 </label>
				</div>
				
				<div class="row text-center">
					<div id="signup_error" class="hide font14 fnone invalid margin-bottom-10"></div>
				</div>
				<div class="row text-center margin-bottom-20 padding-left-20">
					By signing up, you agree to the <a id="terms_n_conditions" href="#">Terms and Conditions</a>.
				</div>
				<div class="d-flex justify-content-center">
					<button class="btn btn-primary">Sign up</button>
				</div>
			</div>
			</form>
			<div class="modal-footer d-flex justify-content">
				<span class="linking">Already a member? <a href="javascript:multi_modal('login');">Login</a></span>
			</div>
		</div>
	</div>	
	</div>
</div>
<div id="fb-root"></div>
<script type="text/javascript" src="https://platform.linkedin.com/in.js">
	/*78wluujnezxrm5*/
api_key: 78wluujnezxrm5
	/*onLoad : linkedin_adjust*/
</script>
<script>
	function linkedin_adjust(){
		$('.modal#login .IN-widget [id^="li_ui_li_gen_"][id*="-title-text"]').attr('style', 'font-size: 21.5px !important');
	}
	function liAuth(){
		IN.UI.Authorize().place();      
        IN.Event.on(IN, "auth", function () { onLinkedInAuth(); });
	}
	function onLinkedInAuth() {
	  IN.API.Profile("me").fields(["id", "formatted-name","firstName", "lastName", "emailAddress","picture-url","three-current-positions"])
		.result( function(me) {
			me.values[0].extra_param = $('.modal#login input#modal_param').val();			
			$.ajax({
				type: 'POST',
				url: url+'accounts/linkedin_login/',
				data: me.values[0],
				dataType: 'json',
				success: function(data){
					if(data.status == 'success'){
						if( data.gaq == 1 ){
							var extra_url = '';
							extra_url = window.location.href.replace(url,'');
							if(extra_url == 'home') extra_url = '';
							if( data.message == '' ){
								if( extra_url != '' ) extra_url = '/'+extra_url;
								window.location.href = url+'user_registered'+extra_url;
							} else {
								window.location.href = url+"user_registered" + "?"+extra_url+data.message;
							}
						} else {
							ga('send', 'event', 'submit', 'login', 'user'); /* For Universal Analytics */
							if( data.message == '' ){
								location.reload();
							} else {
								var loc = window.location.href;
								if(loc.indexOf("?") > -1 ){
									window.location.href = window.location.href + "&"+data.message;
								} else {
									window.location.href = window.location.href + "?"+data.message;
								}
							}
						}
					} if(data.status == 'signup'){
					    $('#login').modal('hide');
						$('#linkedin-signup-modal').modal('show');
						return false;
					} else {
						location.reload(true);
					}
				}
			});
			var id = me.values[0].id;
		});
	}
	function statusChangeCallback(response) {
		if (response.status === 'connected') {
			testAPI();
		}
	}

	function checkLoginState() {
		/*FB.getLoginStatus(function(response) {
			statusChangeCallback(response);
		});*/
		FB.login(function(response) {
			statusChangeCallback(response);
		},{
			scope: 'email,public_profile'
		});
	}

	window.fbAsyncInit = function() {
		FB.init({
			appId      : FB_API,
			cookie     : true,							
			xfbml      : true,
			version    : 'v2.9'
		});

		/*FB.getLoginStatus(function(response) {
			if (response && response.status === 'connected') {
				FB.logout(function(response) {
					document.location.reload();
				});
			}
		});*/
	};

	(function(d, s, id) {
		var js, fjs = d.getElementsByTagName(s)[0];
		if (d.getElementById(id)) return;
		js = d.createElement(s); js.id = id;
		js.src = "//connect.facebook.net/en_US/sdk.js";
		fjs.parentNode.insertBefore(js, fjs);
	}(document, 'script', 'facebook-jssdk'));

	function testAPI() {
		//$('#back-processing-modal .modal-body .text-center b').html('Redirecting to homepage');
		//$('#back-processing-modal').modal('show');
		//FB.api('/me', function(response) {
		FB.api('/me?fields=email,name', function(response) { 
			if( response.email ){
				response.extra_param = $('.modal#login input#modal_param').val();				
				$.ajax({
					type: 'POST',
					url: url+'accounts/fb_login/',
					data: response,
					dataType: 'json',
					success: function(data){
						if(data.status == 'success'){
							if( data.gaq == 1 ){
								var extra_url = '';
								extra_url = window.location.href.replace(url,'');
								if(extra_url == 'home') extra_url = '';
								if( data.message == '' ){
									if( extra_url != '' ) extra_url = '/'+extra_url;
									window.location.href = url+'user_registered'+extra_url;
								} else {
									window.location.href = url+"user_registered" + "?"+extra_url+data.message;
								}
							} else {
								ga('send', 'event', 'submit', 'login', 'user'); /* For Universal Analytics */
								if( data.message == '' ){
									location.reload();
								} else {
									var loc = window.location.href;
									if(loc.indexOf("?") > -1 ){
										window.location.href = window.location.href + "&"+data.message;
									} else {
										window.location.href = window.location.href + "?"+data.message;
									}
								}
							}
						} if(data.status == 'signup'){
							$('#login').modal('hide');
							$('#fb-signup-modal').modal('show');
							return false;
					   } else {
							location.reload(true);
						}
					}
				});
			} else {
				$('#back-processing-modal').modal('hide');
				noty({layout: 'topCenter',type:'error',text:'Some issues in facebook login. Email address not found.',timeout: default_timeout});
			}
		});
	}
</script>
<!-- Loading Modal -->
<div class="modal fade" tabindex="1" id="linkedin-signup-modal"  role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
		     <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
				<h3 class="text-center">Sign Up and Start Learning</h3>
            </div>
            <div class="modal-body text-center">
                <h4>This Email Id does not exists, Please <a href="javascript:multi_modal('signup');"> Sign Up</a></h4>
            </div>    
        </div>
    </div>
</div>

<div class="modal fade" tabindex="1" id="fb-signup-modal"  role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
		     <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
				<h3 class="text-center">Sign Up and Start Learning</h3>
            </div>
            <div class="modal-body text-center">
                <h4>This Email Id does not exists, Please <a href="javascript:multi_modal('signup');">  Sign Up</a></h4>
            </div>    
        </div>
    </div>
</div>
	<div id="promotional" class="text-center ">
		<button id="close_promotion" type="button" class="close"><i class="icon-remove"></i></button>
<!--start - header-->
<div id="header-container"  class="shadow width-100" style="position:relative;">
<div class="container">
	<nav class="navbar navbar-expand-lg navbar-light">
								
			
							<a href="index.php">Logo</a>&nbsp; &nbsp; &nbsp;
									            <div id="navbar" class="collapse navbar-collapse row pl-2">
			            <ul class="nav navbar-nav">
								<li id="search_panel" class="search_panel">
					<div class="input-group form-sm form-1 pl-0">
						
						<div class="input-group-append">
						<input class="form-control my-0 py-1 color-grey ui-autocomplete-input" type="text" placeholder="Search" aria-label="Search" id="all_course_search" class="search_course" onkeyup="shownHint(this.value)"><span class="input-group-text lighten-3" id="input-search-icon"><i class="fa fa-search" aria-hidden="true"></i></span>
						 </div>
						 
						 <div style="width:100%;background-color:white; height:auto; color:black; font-size:14px;" id="sncontent">
						 </div>
						
					</div>
				</li> 
				&nbsp;
				&nbsp;
				<li>
				  <?php
				    if(isset($_SESSION["user"]))
					{
						echo "<p style='color:green;'>Welcome ".$_SESSION["user"]." !</p>";
					}
						
				  ?>
				</li>
					            </ul>
            <ul class="nav navbar-nav ml-auto">
			<?php
			if(isset($_SESSION["user"]))
						 {
							 ?>
								<li class="nav-item dropdown sidebar">
					<a href="" class="nav-link dropdown-toggle" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">My Cart</a>
					<div class="dropdown-menu dropdown-primary font15" aria-labelledby="navbarDropdownMenuLink">
					   <?php
					     
							 $selsql=mysqli_query($db,"select * from course_sub where user_email='".$_SESSION["uemail"]."'");
							 if(mysqli_num_rows($selsql)>0)
							 {
							 while($rowsel=mysqli_fetch_object($selsql))
							 {
								 if($rowsel->status=='approve')
								 {
					   ?>
						<a href="course_view.php?cid=<?php echo $rowsel->course_id;?>" class="dropdown-item"><?php echo $rowsel->course_name."<span style='color:green; font-size:11px;'> Approved</span>";?></a>
						<?php
								 }
								 else
								 {
									 ?>
									 <a href="#" class="dropdown-item"><?php echo $rowsel->course_name."<span style='color:red; font-size:11px;'> Under Review</span>";?></a>
									 <?php
								 }
						     }
							 }
							 else
							 {
								 echo "<p style='padding:5px;'>No Items in your cart!</p>";
							 }
						?>
					</div>
				</li>
				<?php
						 }
						 ?>
								<li class="nav-item sidebar"><a class="nav-link" href="#">Become a Faculty</a></li>
				<li class="nav-item sidebar"><a class="nav-link" href="#" target="_blank">LMS Platform</a></li>
				
						<?php 
							   if(isset($_SESSION["user"]))
							   {
								   echo "<li class='nav-link'><a href='logout.php'>Logout</a></li>";
							   }
							   else
							   {
							   ?>			
								<li><a href="javascript:multi_modal('login');" class="nav-link">Login / Sign Up</a></li>
								<?php
							   }
							   ?>
								<li class="show_promotion hidden-xs hide">Offers<br/><span class="glyphicon glyphicon-arrow-down"></span></li>
				            </ul>
			
			          </div><!--/.nav-collapse -->
				    </nav>
	
	
	
	<div data-keyboard="false" tabindex="-1" class="modal fade" id="back-processing-modal" role="dialog" aria-hidden="true" aria-labelledby="procModalLabel">
    <div class="modal-dialog">
        <div class="processing modal-content" id="procModalLabel">
            <div class="modal-body">
                <div class="text-center">
                	<b>Sending Activation Link</b><br><br>
                </div>
            </div>
        </div>
    </div>
</div>
</div>

<div class="has-search search_panel hidden-md hidden-lg" id="search_panelmob" style="display:none;">
    <span class="fa fa-search form-control-feedback"></span>
    <input type="text" class="form-control" placeholder="Search" name="searchword" id="course_search" class="search_course">
  </div>
</div>

<!-- end header -->

<!-- Loading Modal -->




<!DOCTYPE html>
<style>
.deco_link{
    color: black !important;

}
.deco_link:hover,.deco_link:focus {
    color: blue!important;

}
.deco_link::after {
    content: '';
    display: block;
    width: 0;
    height: 2px;
    background: #black;
}


.deco_link:hover::after {
    width: 70%;
	margin-left:10px;
}
.button_hover:hover{
	color:#fff!important;
   font-size: 15px!important;
}
.blue-bg{
    background-image: linear-gradient(#1D3BB3, #1C76D7);
    border-radius:10px;
    padding:20px;
    color:#fff;
    height: 230px;
}
.blue-banner{
    background-image: linear-gradient(#1D3BB3, #1C76D7);
    color:#fff;
}
.card-bg{
    background-color: #fff;
    color:#fff;
    border-radius:10px;
    padding:20px;
    color:#1D3BB3;
    height: 230px;
}

.offering-icon{
    filter: invert(100%); 
  -webkit-filter:invert(100%);
}
.ourcenter-img{
    position: relative;
  color: white;
}
.img-text{
    position: absolute;
    bottom: 16px;
    left: 38px;
}
.btn-color{
    background-image: linear-gradient(to right, #EF9D23, #F16F1C);
    border-radius:6px;
    font-size:15px;
    font-weight:bold;
}
.award_text{
    color:#fff !important;
}
.awards-wrap {
  margin-top:150px; /* push the wrap down a bit. You might not need this */
  }

.awardico {
  margin-top:-30%; /* and push the image up a bit */
  width: 80%;
  height:85%;
}

@media only screen and (max-width: 600px) {
  .header_img img {
     display:none;
  }
  #homepage_background{
    background-image:url("images/header_mobile.png");;
     background-repeat: no-repeat;
  background-size: 100%;
  }
  .ourcenter-img img{
    width:100% !important;
  }
  .img-text{
    left:1%;
  }
  .img-text p{
    font-size:1rem !important;
    padding:10%
  }
  .acc-img{
    margin-top:10% !important;
  }
  .key-card{
    padding:10% !important;
  }
  .awardico {
    margin-top: 0%;
    width: 78%;
    height: 57%;
   }
   .media-bottom{
    display:none;
   }
   .awards-section{
        background-image:url("");
   }
}
</style>
<html lang="en">
   <!-- Bootstrap core CSS -->
   <link href="css/coming-soon.min.css" rel="stylesheet">
   <div class="width-100" >
         <div class="container" style="position:relative;">
            <div id="why_choose_us">               
               <div class="row">
               <div class="col-sm-12">
                     <span class="glyphicon glyphicon-list-alt"></span>
                     <div class="message">
                        <img src="images/coming-soon-img.png">
                     </div>
                  </div>
               </div>
            </div>
         </div>
	  </div>
   </div>
   <!-- Bootstrap core JavaScript --><!-- Footer Start -->
<div id="floating_footer" class="container">
	
	<div id="footer_sticky_bar">
				<a href="#" class="hideformob f_f_link">
			<span class="glyphicon glyphicon-wrench"></span>&nbsp;How it works
		</a>
				<ul class="live_chat_div">
			<li class="call_no_stiky only_web">Call us: +91 1234 567890</li>
			<li class="call_no_stiky only_mob" style="display:none;"><a href="tel:+917353605333"><span class="glyphicon glyphicon-earphone"></span>&nbsp;&nbsp;Call</a></li>
			
					</ul>
		<!--Chat area starts here-->
		<div id="chat_functionality_area">
			<div id="cs_reply_section">
								<div class="chat-box" id="chat-box">
					<div id="chat_area" class="chat-area">
						<div id="n_i_end_chat" class="hide"><button id="bt_back_6_2" class="btn btn-xs btn-danger">End Chat</button></div>
						<div class="chat-addon" id="chat_leave">
							<span class="icon-comment"></span><span class="text-center"> Chat Assistant </span><span class="float-right"><i class="fa fa-caret-down"></i></span>
						</div>
						<div id="n_i_chat">
							<div id="n_i_chat_1">
								<div class="intro_h">Looking For ?</div>
								<div class="pop_cr">
									<div class="pop_cr_btn">
										<!-- <a href="javascript:void(0);" data-html="GST" data-short="goods-and-service-tax-gst" class="btn btn-sm btn-default btn_opt">GST</a> -->
										<a href="javascript:void(0);" data-html="CCBA<sup>&reg;</sup>" data-short="ccba" class="btn btn-sm btn-default btn_opt">CCBA<sup>&reg;</sup></a>
									</div>
									<div class="pop_cr_btn">
										<a href="javascript:void(0);" data-short="cfp" class="btn btn-sm btn-default btn_opt">CFP<sup>CM</sup></a>
									</div>
									<div class="pop_cr_btn">
										<a href="javascript:void(0);" data-html="FRM" data-short="frm0" class="btn btn-sm btn-default btn_opt">FRM<sup>&reg;</sup></a>
									</div>
									<div class="pop_cr_btn">
										<a href="javascript:void(0);" data-html="CBAP<sup>&reg;</sup>" data-short="cbap" class="btn btn-sm btn-default btn_opt">CBAP<sup>&reg;</sup></a>
									</div>
									<div class="pop_cr_btn">
										<!-- <a href="javascript:void(0);" data-html="PMI-RMP<sup>&reg;</sup>" data-short="pmi-rmp" class="btn btn-sm btn-default btn_opt">PMI-RMP<sup>&reg;</sup></a> -->
										<a href="javascript:void(0);" data-html="PMP<sup>&reg;</sup>" data-short="pmp" class="btn btn-sm btn-default btn_opt">PMP<sup>&reg;</sup></a>
									</div>
									<div class="pop_cr_btn">
										<a href="javascript:void(0);" data-html="PMI-PBA<sup>&reg;</sup>" data-short="pmi-pba-certification-training" class="btn btn-sm btn-default btn_opt">PMI-PBA<sup>&reg;</sup></a>
									</div>									
									<div class="pop_cr_btn">
										<a href="javascript:void(0);" data-html="CISA" data-short="cisa" class="btn btn-sm btn-default btn_opt">CISA<sup>&reg;</sup></a>
									</div>
									<div class="pop_cr_btn">
										<a href="javascript:void(0);" data-short="others" class="btn btn-sm btn-default btn_opt">Others</a>
									</div>
								</div>
							</div>
							<div id="n_i_chat_2a">
								<div class="intro_h">Which one ?</div>
								<div class="pop_cr">
									<div class="pop_cr_btn">
										<a href="#" data-html="CFP<sup>CM</sup> Regular Pathway" data-short="cfp-rp" class="btn btn-sm btn-default btn_opt">CFP<sup>CM</sup> Regular Pathway</a>
									</div>
									<div class="pop_cr_btn">
										<a href="#" data-html="CFP<sup>CM</sup> Challenge Status" data-short="cfp-cs" class="btn btn-sm btn-default btn_opt">CFP<sup>CM</sup> Challenge Status</a>
									</div>
									<div class="pop_cr_btn">
										<a id="bt_back_2a_1" class="btn btn-sm btn-default">Go to Menu</a>
									</div>
								</div>
							</div>
							<div id="n_i_chat_2b">
								<div class="intro_h">Which one ?</div>
								<div class="pop_cr">
									<div class="pop_cr_btn">
										<a href="#" data-html="FRM<sup>&reg;</sup> - Part 1" data-short="frm" class="btn btn-sm btn-default btn_opt">FRM<sup>&reg;</sup> - Part 1</a>
									</div>
									<div class="pop_cr_btn">
										<a href="#" data-html="FRM<sup>&reg;</sup> - Part 2" data-short="frm-2" class="btn btn-sm btn-default btn_opt">FRM<sup>&reg;</sup> - Part 2</a>
									</div>
									<div class="pop_cr_btn">
										<a id="bt_back_2b_1" class="btn btn-sm btn-default">Go to Menu</a>
									</div>
								</div>
							</div>
							<div id="n_i_chat_2c">
								<form onsubmit="return false;">
									<div class="form-group ui-front">
										<input id="s_course" type="text" class="form-control" value="" placeholder="Search Course">
										<span class="bart"></span>										
									</div>
									<div class="form-group hide">
									<div class="text-center"><strong>Sorry !!!<br><br>Currently we don't provide training for <span id="s_term"></span></strong></div>
									</div>
									<div class="pop_cr">
										<div class="pop_cr_btn">
											<a id="bt_back_2c_1" class="btn btn-sm btn-default">Go to Menu</a>
										</div>
									</div>
								</form>
							</div>
							<div id="n_i_chat_2">
								<div class="intro_h"><span id="course_name"></span></div>
								<div class="pop_cr">
									<div class="pop_cr_btn">
										<a id="n_i_clink" href="" class="btn btn-sm btn-default">Go to Course Page</a>
									</div>
									<div class="pop_cr_btn">
										<a id="n_i_mail" class="btn btn-sm btn-default">Mail me the details</a>
									</div>
									<div class="pop_cr_btn">
										<a id="n_i_call" class="btn btn-sm btn-default">Call me Back</a>
									</div>
									<div class="pop_cr_btn">
										<a id="n_i_live_chat" class="btn btn-sm btn-default">Live Chat with us</a>
									</div>
									<div class="pop_cr_btn">
										<a id="bt_back_2_1" class="btn btn-sm btn-default">Go to Menu</a>
									</div>
								</div>
							</div>
							<div id="n_i_chat_3">
								<form method="POST" action="#" onsubmit="return false;">
									<input type="hidden" name="course" value="">
									<div class="form-group">
																				<input type="text" class="form-control input-sm" name="name" placeholder="Name*" required>
																			</div>
									<div class="form-group">
																				<input type="email" class="form-control input-sm" name="email" placeholder="Email*" value="" required>
																			</div>
									<div class="form-group">
																				<div class="row">
											<div class="col-sm-4">
												<input type="text" class="form-control input-sm col-sm-3" name="code" placeholder="ISD">
											</div>
											<div class="col-sm-8">
												<input type="text" class="form-control input-sm col-sm-9" name="mobile" placeholder="Mob">
											</div>
										</div>
																			</div>
									<div class="form-group">
										<textarea class="resize-none form-control input-sm" name="remarks" rows="3" placeholder="Remarks"></textarea>
									</div>
									<div class="pop_cr">
										<div class="pop_cr_btn">
										<button id="bt_back_3_2" type="button" class="btn btn-default btn-sm">Back</button>
										<button type="submit" class="btn btn-primary btn-sm" id="mail_me">Send Mail</button>
										</div>
									</div>
								</form>
							</div>
							<div id="n_i_chat_3a">
								<div class="n_i_success">
									<div class="text-center">Your response has been recorded.</div>
								</div>
								<div class="pop_cr">
									<div class="pop_cr_btn">
										<a id="bt_back_3a_1" class="btn btn-sm btn-default">Go to Menu</a>
									</div>
								</div>
							</div>
							<div id="n_i_chat_4">
								<form method="POST" action="#">
									<input type="hidden" name="course" value="">
									<div class="form-group">
																				<input type="text" class="form-control input-sm" name="name" placeholder="Name*" required>
																			</div>
									<div class="form-group">
																				<input type="email" class="form-control input-sm" name="email" placeholder="Email*" required>
																			</div>
									<div class="form-group">
																				<div class="row">
											<div class="col-sm-4">
												<input type="text" class="form-control input-sm col-sm-3" name="code" placeholder="ISD" required>
											</div>
											<div class="col-sm-8">
												<input type="text" class="form-control input-sm col-sm-9" name="mobile" placeholder="Mob*" required>
											</div>
										</div>
																			</div>									
									<div class="form-group">
										<textarea class="resize-none form-control input-sm" name="remarks" rows="2" placeholder="Remarks"></textarea>
									</div>
									<div class="pop_cr">
										<div class="pop_cr_btn">
											<button id="bt_back_4_2" type="button" class="btn btn-default btn-sm">Back</button>
											<button type="submit" class="btn btn-primary btn-sm" id="call_me">Call Me</button>
										</div>
									</div>
								</form>
							</div>
							<div id="n_i_chat_4a">
								<div class="n_i_success">
									<div class="text-center">
										<span id="on">We'll call you shortly</span>
										<span id="off" class="hide">Our team is currently Offline<br><br>We'll get in touch with you in the next few hours</span>
									</div>
								</div>
								<div class="pop_cr">
									<div class="pop_cr_btn">
										<a id="bt_back_4a_1" class="btn btn-sm btn-default">Go to Menu</a>
									</div>
								</div>
							</div>
							<div id="n_i_chat_5">
								<div class="intro_h">Enter details to start chat</div>
								<form method="POST" action="#" onsubmit="return false;">
									<input type="hidden" name="course" value="">									
									<div class="form-group">
																				<input type="text" class="form-control input-sm" name="name" placeholder="Name*" required>
																			</div>
									<div class="form-group">
																				<input type="email" class="form-control input-sm" name="email" placeholder="Email*" required>
																			</div>
									<div class="form-group">
																				<div class="row">
											<div class="col-sm-4">
												<input type="text" class="form-control input-sm col-sm-3" name="code" placeholder="ISD">
											</div>
											<div class="col-sm-8">
												<input type="text" class="form-control input-sm col-sm-9" name="mobile" placeholder="Mob">
											</div>
										</div>
																			</div>
									<div class="form-group">									
									<div class="pop_cr">
										<div class="pop_cr_btn">
										<button id="bt_back_5_2" type="button" class="btn btn-default btn-sm">Back</button>
										<button type="submit" class="btn btn-primary btn-sm">Start Chat</button>
										</div>
									</div>
									</div>
								</form>
							</div>
							<div id="n_i_chat_6" class="n_i_chat_6">
								<span id="support_live_msg" class="hide">
									<i>We're currently offline. Please leave us a message and we will get back to you.</i>
								</span>
								<div class="prev-chats" id="prev-chats" data-shown="0" data-total="0">
																	</div>
								<textarea class="resize-none chat-textarea" id="send_chat_msg" placeholder="Type here..."></textarea>
								<i class="chat-i">*Press Shift+Enter to generate new line.</i>								
							</div>
						</div>
					</div>
				</div>
							</div>
					</div>
		<!--Chat area ends here-->
			</div>
</div>
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/jquery-ui-1.12.1.min.js"></script>
<script type="text/javascript" src="js/popper.min.js"></script>
<script type="text/javascript" src="js/bootstrap-v4.3.1.min.js"></script>
<script type="text/javascript" src="js/jquery.form.js"></script>
<script type="text/javascript" src="js/jquery.timeago.js"></script>
<script type="text/javascript" src="js/jstz.min.js"></script>
<script type="text/javascript" src="js/script.js?v=80.0"></script>
<script type="text/javascript" src="js/jquery.autosize.min.js"></script>
<script type="text/javascript" src="js/jquery.noty.packaged.min.js"></script>
<script type="text/javascript" src="js/star-rating.min.js"></script>
<script type="text/javascript" src="js/jquery.timeago.js"></script>
<script type="text/javascript" src="js/chat.js?v=80.0"></script>
<script type="text/javascript" src="js/select2.js?v=80.0"></script>
<script type="text/javascript" src="js/login_old.js?v=80.0"></script>

<script>
//ga('send', 'event', 'Custom Variables', 'Set UserId', {'nonInteraction': 1});
//ga('send', 'pageview');

$(document).ready(function() {
	$('#phn_no').on('keydown',  function (event) {	
		if ((event.which < 48 || event.which > 57) && (event.which != 46 && event.which != 0 && event.which != 8 && event.which != 9)) {
			event.preventDefault();
		} 
	});
});
</script>
<!-- Google Code for Remarketing Tag -->
<script type="text/javascript">
/* <![CDATA[ */
var google_conversion_id = 981938738;
var google_custom_params = window.google_tag_params;
var google_remarketing_only = true;
/* ]]> */
</script>

<script>
function showHint(str) {
    if (str.length == 0) {
        document.getElementById("scontent").innerHTML = "";
        return;
    } else {
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("scontent").innerHTML = this.responseText;
            }
        }
        xmlhttp.open("GET", "gethint.php?q="+str, true);
        xmlhttp.send();
    }
}
function shownHint(str) {
    if (str.length == 0) {
        document.getElementById("sncontent").innerHTML = "";
        return;
    } else {
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("sncontent").innerHTML = this.responseText;
            }
        }
        xmlhttp.open("GET", "gethint.php?q="+str, true);
        xmlhttp.send();
    }
}
</script>
<div style="display:none">
<script type="text/javascript" src="//www.googleadservices.com/pagead/conversion.js"></script>
</div>
<noscript>
<div style="display:inline;">
<img height="1" width="1" style="border-style:none;" alt="" src="//googleads.g.doubleclick.net/pagead/viewthroughconversion/981938738/?value=0&amp;guid=ON&amp;script=0"/>
</div>
</noscript>
<!-- BING TAG START-->
<!--<script>(function(w,d,t,r,u){var f,n,i;w[u]=w[u]||[],f=function(){var o={ti:"5062533"};o.q=w[u],w[u]=new UET(o),w[u].push("pageLoad")},n=d.createElement(t),n.src=r,n.async=1,n.onload=n.onreadystatechange=function(){var s=this.readyState;s&&s!=="loaded"&&s!=="complete"||(f(),n.onload=n.onreadystatechange=null)},i=d.getElementsByTagName(t)[0],i.parentNode.insertBefore(n,i)})(window,document,"script","//bat.bing.com/bat.js","uetq");</script><noscript><img alt="ApnaCourse Bing" src="//bat.bing.com/action/0?ti=5062533&Ver=2" height="0" width="0" style="display:none; visibility: hidden;" /></noscript>-->
<script>
!function(q,e,v,n,t,s){if(q.qp) return; n=q.qp=function(){n.qp?n.qp.apply(n,arguments):n.queue.push(arguments);}; n.queue=[];t=document.createElement(e);t.async=!0;t.src=v; s=document.getElementsByTagName(e)[0]; s.parentNode.insertBefore(t,s);}(window, 'script', 'https://a.quora.com/qevents.js');
qp('init', '5ba9c826abc545119f0adb3bd5f5bae3');
qp('track', 'ViewContent');
</script>
<noscript><img height="1" width="1" style="display:none" src="https://q.quora.com/_/ad/5ba9c826abc545119f0adb3bd5f5bae3/pixel?tag=ViewContent&noscript=1"/></noscript>
<!-- BING TAG END -->
<!-- Zarget code -->
<!--script src="//cdn.zarget.com/78460/100609.js"></script-->

</body>
</html>