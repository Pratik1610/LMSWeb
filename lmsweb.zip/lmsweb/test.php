<?php 
session_start();
include "authentication.php";

				 // if(empty($_REQUEST["ans"])&&empty($_REQUEST["next"])&&empty($_REQUEST["review"]))
				 // {
					 
				 $selq=mysqli_query($db,"select * from mock_papers");
				 // }
				 while($rowq=mysqli_fetch_object($selq))
				 {
					 if(empty(htmlspecialchars($rowq->scenario))){
						 echo $rowq->id."<br>";
						 echo $rowq->scenario;
					 }
				 }

?>