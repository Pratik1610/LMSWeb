<?php
session_start();
include "authentication.php";
$email=$_POST["username_m"];
$pass=$_POST["password_m"];


$query=mysqli_query($db,"select * from reg_user where email='$email' and password='$pass'");

if(mysqli_num_rows($query)>0)
{
  $row=mysqli_fetch_object($query);
  $_SESSION["user"]=$row->name;
  $_SESSION["uemail"]=$row->email;
  header("location:index.php");
}
else
{
echo "<script> alert('Incorrect Username or Password!') </script>";
echo "<script>window.location.href='index.php'</script>"; 
}

?>