<?php
session_start();
include "authentication.php";
$str=$_GET["q"];
$query=mysqli_query($db,"select * from courses where course like '$str%'");
if(mysqli_num_rows($query)>0)
{
	while($row=mysqli_fetch_object($query))
	{
	echo "<a href='course_summary.php?cid=".$row->id."' style='color:black; font-size:14px; font-family: Verdana, sans-serif;'>".$row->course."</a><br>";
	}
}
?>