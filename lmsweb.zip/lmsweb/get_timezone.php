<?php
session_start();
$timezone_offset_minutes =  $_GET['dt'];  // $_GET['timezone_offset_minutes']

// Convert minutes to seconds
$timezone_name = timezone_name_from_abbr("", $timezone_offset_minutes*60, false);

$_SESSION["timezone"]=$timezone_name;
?>