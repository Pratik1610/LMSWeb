<?php
 session_start();
 include "authentication.php";
 @$email=$_SESSION['uemail'];
 @$timezone=$_SESSION["timezone"];

 @date_default_timezone_set("$timezone");
 $cur=date("Y-m-d");
 if(!isset($email))
 {
	 echo "<script> alert('Please login First!') </script>";
	 echo "<script> window.location.href='index.php' </script>";
 }
 else
 {
	 @$mid=$_REQUEST["mid"];
	 
	 if($mid==1)
	 {
		 $qcount=120;
	 }
	 elseif($mid==2)
	 {
		 $qcount=130;
	 }
	 elseif($mid==3)
	 {
		 $qcount=50;
	 }
				
				 if(isset($_REQUEST["review"]))
				 {
					 @$disradio="disabled";
				 }
 }
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>
	<title>LMS | Online Training on Professional Courses and Certifications by Experts | Mock Test</title>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" /> 

	<meta name="viewport" content="width=device-width, initial-scale=1"/>
	<meta name="title" content="Online Training on Professional Courses and Certifications by Experts"/>
	<meta name="description" content="Online Trainings from Experts to help Advance your Career"/>
	<meta name="author" content=""/>

	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	
	<meta property="fb:app_id" content="212429995547826" />
	<meta property="og:site_name" content="LMS" />
	<meta property="og:type" content="website" />
	<meta property="og:url" content="localhost/lms" />
	<meta property="og:image" content="" />
	<meta property="og:title" content="Online Training on Professional Courses and Certifications by Experts" />
	<meta property="og:description" content="Online Trainings from Experts to help Advance your Career" />
	<meta name="google-site-verification" content="2-7nt5nzoyujWWK_cE0JdA1pftuko_9Hiq5sMNx1JSU" />
	
	
	<link rel="shortcut icon" href="images/user-placeholder.gif" type="image/x-icon"/>
	<link type="text/css" href="css/bootstrap-4.3.1.min.css" rel="stylesheet"/>
	<style>
	ul {
  list-style: none; /* Remove default bullets */
}

ul li{
	background-color:rgba(251,251,251,0.8);
	padding:10px;
	margin-bottom:10px !important;
	text-align:left;
	height:auto !important;
	font-size:18px;
}

ul li::before {
  content: "\2022";  /* Add content: \2022 is the CSS Code/unicode for a bullet */
  color: transparent; /* Change the color */
  font-weight: bold; /* If you want it to be bold */
  display: inline-block; /* Needed to add space between the bullet and the text */
  width: 1em; /* Also needed for space (tweak if needed) */
  margin-left: -1em; /* Also needed for space (tweak if needed) */
}

.theorypass_response {
    background: #f9f5dc!important;
    border: 1px solid #ecdaaa!important;
    padding: 10px!important;
    margin-bottom: 15px!important;
	width: 96%;
    margin: 0 auto;
	font-size:18px;
	margin-top:20px !important;
}
* {box-sizing: border-box;}
ul {list-style-type: none;}
body {font-family: Verdana, sans-serif;}

.month {
  padding: 70px 25px;
  width: 100%;
  background: #1abc9c;
  text-align: center;
}

.month ul {
  margin: 0;
  padding: 0;
}

.month ul li {
  color: white;
  font-size: 20px;
  text-transform: uppercase;
  letter-spacing: 3px;
}

.month .prev {
  float: left;
  padding-top: 10px;
}

.month .next {
  float: right;
  padding-top: 10px;
}

.weekdays {
  margin: 0;
  padding: 10px 0;
  background-color: #ddd;
}

.weekdays li {
  display: inline-block;
  width: 13.6%;
  color: #666;
  text-align: center;
}

.days {
  padding: 10px 0;
  background: #eee;
  margin: 0;
}

.days li {
  list-style-type: none;
  display: inline-block;
  width: 13.6%;
  text-align: center;
  margin-bottom: 5px;
  font-size:12px;
  color: #777;
}

.days li .active {
  padding: 5px;
  background: #1abc9c;
  color: white !important
}

.qmargin{
	display:block;
	margin-bottom:10px !important;
    text-align:justify; 
	font-size:18px;
}

.theorypass_reviewLegend{padding:5px!important;margin-bottom:8px!important}.theorypass_reviewLegend li,.theorypass_reviewLegend ol{margin:0!important;border:0!important;list-style-type:none!important}.theorypass_reviewLegend ol{padding:0!important}.theorypass_reviewLegend li{float:left!important;padding-right:5px!important;background-image:none!important}
.theorypass_reviewColor{height:10px!important;width:10px!important;display:inline-block!important;margin-right:2px!important}

/* Add media queries for smaller screens */
@media screen and (max-width:720px) {
  .weekdays li, .days li {width: 13.1%;}
}

@media screen and (max-width: 420px) {
  .weekdays li, .days li {width: 12.5%;}
  .days li .active {padding: 2px;}
}

@media screen and (max-width: 290px) {
  .weekdays li, .days li {width: 12.2%;}
}
	</style>
	</head>
<body style="background-color:rgba(251,251,251,0.8);">

	<div id="promotional" class="text-center ">
<!-- Loading Modal -->




<!DOCTYPE html>
<html lang="en">
<div class="col-lg-12" style="height:auto; background-color:#007BFF;">
<a href="mock_view.php?mid=<?php echo $_REQUEST["mid"];?>" style="color:white;" class="btn btn-danger">Restart</a>
<div id="response" style="color:white;"></div>
</div>
   <div class="width-100" >
         <div class="container"><!--container start-->
		   <?php
		     if(isset($_REQUEST['mid']))
			 {
				  $mid=$_REQUEST["mid"];
				  $selmin=mysqli_query($db,"select min(id) as minid from mock_papers");
				 $rowmin=mysqli_fetch_object($selmin);
				 
				 $selmax=mysqli_query($db,"select max(id) as maxid from mock_papers");
				 $rowmax=mysqli_fetch_object($selmax);
				 
				 $rand=rand($rowmin->minid,$rowmax->maxid);
				 
				 
				 // if(empty($_REQUEST["ans"])&&empty($_REQUEST["next"])&&empty($_REQUEST["review"]))
				 // {
					 
				 $selq=mysqli_query($db,"select * from mock_papers where id='$rand' limit 1");
				 // }
				 
				 if(isset($_REQUEST["review"]))
				 {
					 
					 $pid=$_REQUEST["pid"];
					  $selq=mysqli_query($db,"select * from mock_papers where id='$pid' limit 1");
				 }
				 
				 if(isset($_REQUEST["ans"]))
				 {
					 @$ans=$_REQUEST["ans"];
					 $pid=$_REQUEST["pid"];
					 if($ans===$_REQUEST["correct_ans"])
					 {
						 $cans="right";
					 }
					 else
					 {
						 $cans="wrong";
					 }
					 $scenario=addslashes($_REQUEST["scenario"]);
					 // $scenario=str_replace("'","''",$scenario);
					 
					 $que=addslashes($_REQUEST["que"]);
					 // $que=str_replace("'","''",$que);
					 
					 @$ans=addslashes($ans);
					 // $ans=str_replace("'","''",$ans);
					 $selq=mysqli_query($db,"select * from mock_papers where id='$pid' limit 1");
					 if(empty($ans))
					 {
						 					 $insql=mysqli_query($db,"insert into mock_sub(`id`,`user_email`,`mock_id`, `paper_id`,`scenario`,`que`,`ans`, `review_later`,`test_date`,`status`) values('','".$_SESSION["uemail"]."','$mid','".$_REQUEST["pid"]."','$scenario','$que','','true','".$_REQUEST["test_date"]."','')");
					 }
					 else
					 {
					 $insql=mysqli_query($db,"insert into mock_sub(`id`,`user_email`,`mock_id`, `paper_id`,`scenario`,`que`,`ans`, `review_later`,`test_date`,`status`) values('','".$_SESSION["uemail"]."','$mid','".$_REQUEST["pid"]."','$scenario','$que','$ans','false','".$_REQUEST["test_date"]."','$cans')");
					 }
				 }
				 
				 if(isset($_REQUEST["review"]))
				 {
					 $scenario=addslashes($_REQUEST["scenario"]);
					 // $scenario=str_replace("'","''",$scenario);
					 
					 $que=addslashes($_REQUEST["que"]);
					 // $que=str_replace("'","''",$que);
					 $insql=mysqli_query($db,"insert into mock_sub(`id`,`user_email`,`mock_id`, `paper_id`,`scenario`,`que`,`ans`, `review_later`,`test_date`,`status`) values('','".$_SESSION["uemail"]."','$mid','".$_REQUEST["pid"]."','$scenario','$que','','true','".$_REQUEST["test_date"]."','')");
				
				 }
				 
				  $arrpid=array();
				  if(isset($_REQUEST["pid"])&&isset($mid)&&isset($_REQUEST["next"]))
				 {
					 @$sqlsub=mysqli_query($db,"select * from mock_sub where user_email='$email' and mock_id='$mid' and test_date='$cur'");
					
					 if(mysqli_num_rows($sqlsub)==120&&$mid==1)
					 {
						 echo "<script> window.location.href='result.php?mid=$mid' </script>";
					 }
					 elseif(mysqli_num_rows($sqlsub)==130&&$mid==2)
					 {
						 echo "<script> window.location.href='result.php?mid=$mid' </script>";
					 }
					 elseif(mysqli_num_rows($sqlsub)==50&&$mid==3)
					 {
						 echo "<script> window.location.href='result.php?mid=$mid' </script>";
					 }
					 else
					 {
						 // check if count of scenario based questions will be 5
						 $scnsql=mysqli_query($db,"select * from mock_sub where user_email='$email' and mock_id='$mid' and test_date='$cur' and scenario!=' '");
						 if(mysqli_num_rows($scnsql)==5)
						 {
							 $selq=mysqli_query($db,"select * from mock_papers where scenario=' ' order by rand() limit 1");
						 }
						 else
						 {
						 $selq=mysqli_query($db,"select * from mock_papers order by rand() limit 1");
						 }
						 
						 
					 }
				 }
				 $rowq=mysqli_fetch_object($selq);
		   ?>
			<div class="row">
			<div class="col-md-8" style="background-color:white; border:1px grey;">
			       <form action="mock_test.php" method="post">
				   <input type="hidden" name="mid" value="<?php echo $_REQUEST["mid"];?>">
				   <input type="hidden" name="id" value="<?php echo $rowq->id;?>">
				   <input type="hidden" name="pid" value="<?php echo $rowq->id;?>">
				   <input type="hidden" name="que" value="<?php echo $rowq->Que;?>">
				   <input type="hidden" name="scenario" value="<?php echo $rowq->scenario;?>">
				   <input type="hidden" name="test_date" value="<?php echo date("Y-m-d");?>">
				   <input type="hidden" name="correct_ans" value="<?php echo $rowq->correct_ans;?>">
				   <input type="hidden" name="ans_desc" value="<?php echo $rowq->ans_description;?>">
				   <label style="text-align:justify; font-size:18px;"><?php if(!empty($rowq->scenario)){?><span style="font-weight:bold; font-size:24px;">Scenario:</span><?php }?> <?php echo htmlspecialchars($rowq->scenario);?></label><br>
				   <div class="qmargin">
				   <label> <span style="font-weight:bold; font-size:24px;">Question:</span> <?php echo htmlspecialchars($rowq->Que);?></label>
				   </div>
				   <ul>
				   <?php
				   if(!empty($rowq->ans1)&&isset($_REQUEST["ans"]))
				   {
					   if($rowq->ans1===$rowq->correct_ans)
					   {
						   $bcolor="rgba(0,135,10,.6)";
						   $color="white";
					   }
					   elseif(($_REQUEST["ans"]!==$_REQUEST["correct_ans"])&&($_REQUEST["ans"]===$rowq->ans1))
					   {
						   $bcolor="rgba(246,82,74,.81)";
						   $color="white";
					   }
					   else
					   {
						   $bcolor="rgba(251,251,251,0.8)";
						   $color="black";
					   }
				   ?>
				   <li style="background-color:<?php echo $bcolor;?> !important; color:<?php echo $color;?>;"><input type="radio" name="ans" value="<?php echo $rowq->ans1;?>" disabled>&nbsp;<?php echo $rowq->ans1;?></li>
				   <?php
				   }
				   else
				   {
				   ?>
				   
				    <li><input type="radio" name="ans" value="<?php echo $rowq->ans1;?>" <?php echo @$disradio;?>>&nbsp;<?php echo $rowq->ans1;?></li>
				   <?php
				   }
				   if(!empty($rowq->ans2)&&isset($_REQUEST["ans"]))
				   {
					    if($rowq->ans2===$rowq->correct_ans)
					   {
						   $bcolor="rgba(0,135,10,.6)";
						   $color="white";
					   }
					    elseif(($_REQUEST["ans"]!==$_REQUEST["correct_ans"])&&($_REQUEST["ans"]===$rowq->ans2))
					   {
						   $bcolor="rgba(246,82,74,.81)";
						   $color="white";
					   }
					    else
					   {
						   $bcolor="rgba(251,251,251,0.8)";
						   $color="black";
					   }
				   ?>
				   <li style="background-color:<?php echo $bcolor;?> !important; color:<?php echo $color;?>;"><input type="radio" name="ans" value="<?php echo $rowq->ans2;?>" disabled>&nbsp;<?php echo $rowq->ans2;?></li>
				   <?php
				   }
				   else
				   {
				   ?>
				   <li><input type="radio" name="ans" value="<?php echo $rowq->ans2;?>" <?php echo @$disradio;?>>&nbsp;<?php echo $rowq->ans2;?></li>
				   <?php
				   }
				   if(!empty($rowq->ans3)&&isset($_REQUEST["ans"]))
				   {
					    if($rowq->ans3===$rowq->correct_ans)
					   {
						   $bcolor="rgba(0,135,10,.6)";
						   $color="white";
					   }
					    elseif(($_REQUEST["ans"]!==$_REQUEST["correct_ans"])&&($_REQUEST["ans"]===$rowq->ans3))
					   {
						   $bcolor="rgba(246,82,74,.81)";
						   $color="white";
					   }
					    else
					   {
						   $bcolor="rgba(251,251,251,0.8)";
						   $color="black";
					   }
				   ?>
				   <li style="background-color:<?php echo $bcolor;?> !important; color:<?php echo $color;?>;"><input type="radio" name="ans" value="<?php echo $rowq->ans3;?>" disabled>&nbsp;<?php echo $rowq->ans3;?></li>
				   <?php
				   }
				   else
				   {
				   ?>
				   <li><input type="radio" name="ans" value="<?php echo $rowq->ans3;?>" <?php echo @$disradio;?>>&nbsp;<?php echo $rowq->ans3;?></li>
				   <?php
				   }
				   if(!empty($rowq->ans4)&&isset($_REQUEST["ans"]))
				   {
					    if($rowq->ans4===$rowq->correct_ans)
					   {
						   $bcolor="rgba(0,135,10,.6)";
						   $color="white";
					   }
					    elseif(($_REQUEST["ans"]!==$_REQUEST["correct_ans"])&&($_REQUEST["ans"]===$rowq->ans4))
					   {
						   $bcolor="rgba(246,82,74,.81)";
						   $color="white";
					   }
					    else
					   {
						   $bcolor="rgba(251,251,251,0.8)";
						   $color="black";
					   }
				   ?>
				   <li style="background-color:<?php echo $bcolor;?> !important; color:<?php echo $color;?>;"><input type="radio" name="ans" value="<?php echo $rowq->ans4;?>" disabled>&nbsp;<?php echo $rowq->ans4;?></li>
				   <?php
				   }
				   else
				   {
				   ?>
				   <li><input type="radio" name="ans" value="<?php echo $rowq->ans4;?>" <?php echo @$disradio;?>>&nbsp;<?php echo $rowq->ans4;?></li>
				   <?php
				   }
				   if(!empty($rowq->ans5)&&isset($_REQUEST["ans"]))
				   {
					    if($rowq->ans5===$rowq->correct_ans)
					   {
						   $bcolor="rgba(0,135,10,.6)";
						   $color="white";
					   }
					    elseif(($_REQUEST["ans"]!==$_REQUEST["correct_ans"])&&($_REQUEST["ans"]===$rowq->ans5))
					   {
						   $bcolor="rgba(246,82,74,.81)";
						   $color="white";
					   }
					    else
					   {
						   $bcolor="rgba(251,251,251,0.8)";
						   $color="black";
					   }
				   ?>
				   <li style="background-color:<?php echo $bcolor;?> !important; color:<?php echo $color;?>;"><input type="radio" name="ans" value="<?php echo $rowq->ans5;?>" disabled>&nbsp;<?php echo $rowq->ans5;?></li>
				   <?php
				   }
				   elseif(!empty($rowq->ans5)&&!isset($_REQUEST["ans"]))
				   {
				   ?>
				   <li><input type="radio" name="ans" value="<?php echo $rowq->ans5;?>" <?php echo @$disradio;?>>&nbsp;<?php echo $rowq->ans5;?></li>
				   <?php
				   }
				   ?>
				   </ul>
				   <br>
				  
				   <?php
				   if(isset($_REQUEST["ans"]))
				   {
					   $sqlsub=mysqli_query($db,"select * from mock_sub where user_email='$email' and mock_id='$mid' and test_date='$cur'");
					   if(@mysqli_num_rows(@$sqlsub)==50&&$mid==3)
					   {
						   $value="Finish Test";
					   }
					   elseif(@mysqli_num_rows(@$sqlsub)==130&&$mid==2)
					   {
						   $value="Finish Test";
					   }
					   elseif(@mysqli_num_rows(@$sqlsub)==120&&$mid==1)
					   {
						   $value="Finish Test";
					   }
					   else
					   {
						   $value="Next";
					   }
				   ?>
				    <input type="submit" id="next" name="next" value="<?php echo $value;?>" class="btn btn-primary" style="float:right; margin-bottom:10px;">
					<?php
				   }
				   elseif(isset($_REQUEST["review"]))
				   {
					   $sqlsub=mysqli_query($db,"select * from mock_sub where user_email='$email' and mock_id='$mid' and test_date='$cur'");
					   if(@mysqli_num_rows(@$sqlsub)==50&&$mid==3)
					   {
						   $value="Finish Test";
					   }
					   elseif(@mysqli_num_rows(@$sqlsub)==130&&$mid==2)
					   {
						   $value="Finish Test";
					   }
					   elseif(@mysqli_num_rows(@$sqlsub)==120&&$mid==1)
					   {
						   $value="Finish Test";
					   }
					   else
					   {
						   $value="Next";
					   }
				?>
					<input type="submit" name="next" value="<?php echo $value;?>" class="btn btn-primary" style="float:right; margin-bottom:10px;">
				<?php
				   }
				   else
				   {
					   $sqlsub=mysqli_query($db,"select * from mock_sub where user_email='$email' and mock_id='$mid' and test_date='$cur'");
					   if(@mysqli_num_rows(@$sqlsub)==50&&$mid==3)
					   {
						   $value="Finish Test";
					   }
					   elseif(@mysqli_num_rows(@$sqlsub)==130&&$mid==2)
					   {
						   $value="Finish Test";
					   }
					   elseif(@mysqli_num_rows(@$sqlsub)==120&&$mid==1)
					   {
						   $value="Finish Test";
					   }
					   else
					   {
						   $value="Next";
					   }
				   ?>
				   <input type="submit" id="next" name="next" value="<?php echo $value;?>" class="btn btn-primary" style="float:right;" disabled>
				   <?php
				   }
				   ?>
				   <!--<button class="btn" style="border:1px solid black;"><a href="summary_mock.php?mid=<?php echo $_REQUEST["mid"];?>" target="_blank" style="color:black;">Summary</a></button>-->
				   <?php
				   if(!isset($_REQUEST["review"])&&!isset($_REQUEST["ans"]))
				   {
				   ?>
				    <input type="submit" id="review" name="review" value="Flag Question" class="btn btn-primary" style="float:right; margin-bottom:10px; margin-right:10px;">
				   <?php
				   }
				   else
				   {
				   ?>
				    <input type="submit" id="review" name="review" value="Flag Question" class="btn btn-primary" style="float:right; margin-bottom:10px; margin-right:10px;" disabled>
				   <?php
				   }
				   ?>
				   <br>
					<?php
					 if(isset($_REQUEST["ans"]))
					 {
						 @$ans=htmlspecialchars($_REQUEST["ans"]);
						 $cans=htmlspecialchars($_REQUEST["correct_ans"]);
						 $desc=htmlspecialchars($_REQUEST["ans_desc"]);
						 
							if($ans!==$cans)
							{
							  echo "<div class='theorypass_response'>";
							  echo "<p class='text-justify' style='color:orange; font-size:20px;'>Incorrect!</p>";
							  echo "<p class='text-justify'> $desc</p>";
							  echo "</div>";
							}

					 }
					 elseif(isset($_REQUEST["review"]))
					 {
						 echo "<div class='theorypass_response'>";
							  echo "<p class='text-justify' style='color:orange; font-size:20px;'>Flagged! (Review Later)</p>";
							  echo "</div>";
					 }
					?>
			</div>
			
			 <div class="col-lg-4">
<ul class="days">
 <?php
			  $sql=mysqli_query($db,"select * from mock_sub where user_email='$email' and test_date='$cur' and mock_id='$mid' order by id asc");
			  $c=1;
			  
				  
				$icount=mysqli_num_rows($sql); 
				$icount=$icount+1; 
			  while($row=mysqli_fetch_object($sql))
			  {
				  ?>
				  <?php
				  if($row->status=="right")
				  {
			  ?>
			  <li style="background-color:rgba(0, 135, 10, 0.6);"><a href="#" style="color:white;"><?php echo $c;?></a></li>
			  <?php
				  }
				  elseif($row->status=="wrong")
				  {
				?>
				<li style="background-color:rgba(246, 82, 74, 0.81);"><a href="#" style="color:white;"><?php echo $c;?></a></li>
				<?php
				  }
				  elseif($row->review_later=="true")
				  {
					  
					  ?>
					  
				<li style="background-color:#FFB800;"><a href="edit-question.php?msid=<?php echo $row->id; ?>&mid=<?php echo $row->mock_id;?>&qno=<?php echo $c;?>" style="color:white;"><?php echo $c;?></a></li>
					  <?php
					  
				  }
				  ?>
				  <?php
			  $c++;
			  }
			  ?> 	
<?php
for($i=$icount;$i<=$qcount;$i++)
{
	if($i==$icount&&isset($_REQUEST["next"]))
	{
?>
<li style="background-color:black; color:white;"><?php echo "$i";?></li>
<?php
	}
	elseif($i==$icount&&isset($_REQUEST["review"]))
	{
?>
<li style="background-color:black; color:white;"><?php echo "$i";?></li>
<?php
	}
	elseif($i==$icount&&!isset($_REQUEST["next"])&&!isset($_REQUEST["review"]))
	{
?>
<li style="background-color:black; color:white;"><?php echo "$i";?></li>
<?php
	}
	else
	{
		?>
		
		<li><?php echo "$i";?></li>
		<?php
	}
		
}
?>
</ul>
			 <div class="theorypass_reviewLegend">
                <ol>
                    <li>
                        <span class="theorypass_reviewColor" style="background-color: rgba(0, 135, 10, 0.6);"></span>
                        <span class="theorypass_reviewText">Correct</span>
                    </li>
                    <li>
                        <span class="theorypass_reviewColor" style="background-color: rgba(246, 82, 74, 0.81);"></span>
                        <span class="theorypass_reviewText">Incorrect</span>
                    </li>
                    <li>
                        <span class="theorypass_reviewColor" style="background-color: #FFB800;"></span>
                        <span class="theorypass_reviewText">Review</span>
                    </li>
                </ol>
                <div style="clear: both;"></div>
            </div>
		  
				     </form>
                <!-- <div style="display: none;"></div> -->
            </div>
			<?php
			 }
			 ?>
			</div>
			</div></div>
	  </div>
   </div>
   <!-- Bootstrap core JavaScript -->
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/jquery-ui-1.12.1.min.js"></script>
<script type="text/javascript" src="js/popper.min.js"></script>
<script type="text/javascript" src="js/bootstrap-v4.3.1.min.js"></script>
<script type="text/javascript" src="js/jquery.form.js"></script>
<script type="text/javascript" src="js/jquery.timeago.js"></script>
<script type="text/javascript" src="js/jstz.min.js"></script>
<script type="text/javascript" src="js/script.js?v=80.0"></script>
<script type="text/javascript" src="js/jquery.autosize.min.js"></script>
<script type="text/javascript" src="js/jquery.noty.packaged.min.js"></script>
<script type="text/javascript" src="js/star-rating.min.js"></script>
<script type="text/javascript" src="js/jquery.timeago.js"></script>
<script type="text/javascript" src="js/chat.js?v=80.0"></script>
<script type="text/javascript" src="js/select2.js?v=80.0"></script>
<script type="text/javascript" src="js/login_old.js?v=80.0"></script>

<script>
function showHint(str) {
    if (str.length == 0) {
        document.getElementById("scontent").innerHTML = "";
        return;
    } else {
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("scontent").innerHTML = this.responseText;
            }
        }
        xmlhttp.open("GET", "gethint.php?q="+str, true);
        xmlhttp.send();
    }
}
function shownHint(str) {
    if (str.length == 0) {
        document.getElementById("sncontent").innerHTML = "";
        return;
    } else {
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("sncontent").innerHTML = this.responseText;
            }
        }
        xmlhttp.open("GET", "gethint.php?q="+str, true);
        xmlhttp.send();
    }
}
</script>
<script type="text/javascript">
		setInterval(function(){
			var timezone_offset_minutes = new Date().getTimezoneOffset();
timezone_offset_minutes = timezone_offset_minutes == 0 ? 0 : -timezone_offset_minutes;

			// var xmlhttp=new XMLHttpRequest();
			// xmlhttp.open("GET","response.php?dt="+dt,true)
			// xmlhttp.send();
			
			// xmlhttp.open("GET","response.php",false)
			// xmlhttp.send(null);
			// document.getElementById("response").innerHTML=xmlhttp.responseText;
			var dt = 'dt=' + timezone_offset_minutes + '&mid=' + <?php echo $mid; ?>;
			$.ajax({
			type : 'GET',
			url : 'response.php',
			data : dt,
			success : function(data)
			{
				$("#response").html(data);
			}
		});
			
		},1000)
		
</script>
<script type="text/javascript">
			var timezone_offset_minutes = new Date().getTimezoneOffset();
timezone_offset_minutes = timezone_offset_minutes == 0 ? 0 : -timezone_offset_minutes;
			var dt = 'dt=' + timezone_offset_minutes;
			$.ajax({
			type : 'GET',
			url : 'get_timezone.php',
			data : dt,
			success:function(data){
			}
			
		});
		
</script>

<script>
// var timezone_offset_minutes = new Date().getTimezoneOffset();
// timezone_offset_minutes = timezone_offset_minutes == 0 ? 0 : -timezone_offset_minutes;
// var dt = 'dt=' + timezone_offset_minutes;
// $.ajax({
			// type : 'POST',
			// url : 'response.php',
			// data : dt,
			// success : function(data)
			// {
				// alert(data);
			// }
		// });

</script>
<script>
$('input[type=radio]').on('change', function() {
    $(this).closest("form").submit();
});
</script>
</body>
</html>