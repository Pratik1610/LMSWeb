<?php
include "authentication.php";
$name=$_POST["name"];
$country=$_POST["country"];
$state=$_POST["state"];
$city=$_POST["city"];
$phone=$_POST["phone"];
$email=$_POST["email"];
$pass=$_POST["pass"];

// check if user already exist
$chksql=mysqli_query($db,"select * from reg_user where email='$email'");
if(mysqli_num_rows($chksql)>0)
{
	echo "<script> alert('User already exist!') </script>";
  echo "<script>window.location.href='index.php'</script>"; 
}
else
{

$query=mysqli_query($db,"INSERT INTO `reg_user`(`id`, `name`, `country`, `state`, `city`, `phone`, `email`, `password`) VALUES (' ','$name','$country','$state','$city','$phone','$email','$pass')");

if($query)
{
  echo "<script> alert('Registered Successfully!') </script>";
  echo "<script>window.location.href='index.php'</script>"; 
}
else
{
echo "<script> alert('Error to insert data!') </script>";
 echo "<script>window.location.href='index.php'</script>"; 
}
}
?>