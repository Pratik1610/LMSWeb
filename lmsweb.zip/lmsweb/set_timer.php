<?php
session_start();
include "authentication.php";
@$mid=$_GET['mid'];

// // Asia/Kolkata
 @$timezone=$_SESSION["timezone"];

 @date_default_timezone_set("$timezone");

 $cur=date("Y-m-d");
 if( empty( $_SESSION['quiz'] ) )$_SESSION['quiz']=date('Y-m-d H:i:s');
  // get timer duration
				 $dursql=mysqli_query($db,"select * from timer where mock_id='$mid'");
				 $rowdur=mysqli_fetch_object($dursql);
				 
				 $duration=$rowdur->duration;
				 
				 $_SESSION["duration"]=$duration;
				 $_SESSION["start_time"]=date("Y-m-d H:i:s");
				 
				 $end_time=$end_time=date("Y-m-d H:i:s", strtotime('+'.$_SESSION["duration"].'minutes',strtotime($_SESSION["start_time"])));
				 
				 $_SESSION["end_time"]=$end_time;
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>
	<title>Spectramind | Online Training on Professional Courses and Certifications by Experts | Mock View</title>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" /> 

	<meta name="viewport" content="width=device-width, initial-scale=1"/>
	<meta name="title" content="Online Training on Professional Courses and Certifications by Experts"/>
	<meta name="description" content="Online Trainings from Experts to help Advance your Career"/>
	<meta name="author" content=""/>

	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	
	<meta property="fb:app_id" content="212429995547826" />
	<meta property="og:site_name" content="LMS" />
	<meta property="og:type" content="website" />
	<meta property="og:url" content="localhost/lms" />
	<meta property="og:image" content="" />
	<meta property="og:title" content="Online Training on Professional Courses and Certifications by Experts" />
	<meta property="og:description" content="Online Trainings from Experts to help Advance your Career" />
	<meta name="google-site-verification" content="2-7nt5nzoyujWWK_cE0JdA1pftuko_9Hiq5sMNx1JSU" />
	
	
	<link rel="shortcut icon" href="images/spectra-logo.jpg" type="image/x-icon"/>
	<link type="text/css" href="css/bootstrap-4.3.1.min.css" rel="stylesheet"/>
	<link type="text/css" href="css/star-rating.min.css" rel="stylesheet"/>
	<link type="text/css" href="css/select2.css" rel="stylesheet"/>
	<link type="text/css" href="css/jquery-ui-1.12.1.min.css" rel="stylesheet"/>
	<link type="text/css" href="css/style_new.css?v=80.0" rel="stylesheet"/>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<link href="https://cdn.jsdelivr.net/gh/gitbrent/bootstrap4-toggle@3.4.0/css/bootstrap4-toggle.min.css" rel="stylesheet">
	<link rel="stylesheet" href="css/frontpage.css?v=80.0" />
	</head>
<body>
<img src="images/loader.gif" class="img-responsive" style="height:800px; width:98%;">
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/jquery-ui-1.12.1.min.js"></script>
<script type="text/javascript">
			var timezone_offset_minutes = new Date().getTimezoneOffset();
timezone_offset_minutes = timezone_offset_minutes == 0 ? 0 : -timezone_offset_minutes;
			var dt = 'dt=' + timezone_offset_minutes;
			$.ajax({
			type : 'GET',
			url : 'get_timezone.php',
			data : dt,
			success:function(data){
				window.location.href='mock_test.php?mid=<?php echo $mid;?>';
			}
			
		});
		
</script>
</body>
</html>