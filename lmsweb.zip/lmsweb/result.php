<?php
 session_start();
 include "authentication.php";
 @$email=$_SESSION['uemail'];
 $cur=date("Y-m-d");
 
			  
 if(!isset($email))
 {
	 echo "<script> alert('Please login First!') </script>";
	 echo "<script> window.location.href='index.php' </script>";
 }
 else
 {
	 $namesql=mysqli_query($db,"select * from reg_user where email='$email'");
	 $namerow=mysqli_fetch_object($namesql);
	 $name=$namerow->name;
	 
	 // $inssql=mysqli_query($db,"insert into mock_session(`id`,`uemail`,`mock_id`,`test_date`,`status`) values('','".$_SESSION["uemail"]."','".$_REQUEST["mid"]."','$cur','closed')");
	 // $delsql=mysqli_query($db,"delete from mock_session where mock_id='0'");
	 
	  if($_REQUEST["mid"]==1)
	 {
		 $exam="CBAP";
	 }
	 elseif($_REQUEST["mid"]==2)
	 {
		 $exam="CCBA";
	 }
	 elseif($_REQUEST["mid"]==3)
	 {
		 $exam="ECBA";
	 }
 }
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>
	<title>LMS | Online Training on Professional Courses and Certifications by Experts</title>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" /> 

	<meta name="viewport" content="width=device-width, initial-scale=1"/>
	<meta name="title" content="Online Training on Professional Courses and Certifications by Experts"/>
	<meta name="description" content="Online Trainings from Experts to help Advance your Career"/>
	<meta name="author" content=""/>

	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	
	<meta property="fb:app_id" content="212429995547826" />
	<meta property="og:site_name" content="LMS" />
	<meta property="og:type" content="website" />
	<meta property="og:url" content="localhost/lms" />
	<meta property="og:image" content="" />
	<meta property="og:title" content="Online Training on Professional Courses and Certifications by Experts" />
	<meta property="og:description" content="Online Trainings from Experts to help Advance your Career" />
	<meta name="google-site-verification" content="2-7nt5nzoyujWWK_cE0JdA1pftuko_9Hiq5sMNx1JSU" />
	
	
	<link rel="shortcut icon" href="images/user-placeholder.gif" type="image/x-icon"/>
	<link type="text/css" href="css/bootstrap-4.3.1.min.css" rel="stylesheet"/>
	<style>
	body {font-family: Verdana, sans-serif;}
	</style>
		
	</head>
<body style="background-color:rgba(251,251,251,0.8);">

	<div id="promotional" class="text-center ">
<!-- Loading Modal -->




<!DOCTYPE html>
<html lang="en">
<div class="col-lg-12" style="height:100px; background-color:#007BFF;">
<a href="index.php" style="color:white;" class="btn btn-danger">Go to Home</a>
</div>
   <div class="width-100" >
        <h1><?php echo $exam;?></h1>
		<hr>
         <div class="container text-center" style="background-color:white; height:auto; padding-top:10px;"><!--container start-->
		      <?php
			  $sql1=mysqli_query($db,"select * from mock_sub where user_email='$email' and test_date='$cur' and status='right' and mock_id='".$_REQUEST["mid"]."'");
			  $sql2=mysqli_query($db,"select * from mock_sub where user_email='$email' and test_date='$cur' and status='wrong' and mock_id='".$_REQUEST["mid"]."'");
			  $right=mysqli_num_rows($sql1);
			  $wrong=mysqli_num_rows($sql2);
			  
			  if($_REQUEST["mid"]==1)
			  {
				  $total_que=120;
			  }
			  elseif($_REQUEST["mid"]==2)
			  {
				  $total_que=130;
			  }
			  elseif($_REQUEST["mid"]==3)
			  {
				  $total_que=50;
			  }
			  
			  $percentage=$right/$total_que*100;
			  
			  if($percentage>70&&$_REQUEST["mid"]==1)
			  {
				  $msg="Congratulations!, your score is ".$percentage."% (Pass)";
			  }
			  elseif($percentage>70&&$_REQUEST["mid"]==2)
			  {
				  $msg="Congratulations!, your score is ".$percentage."% (Pass)";
			  }
			  elseif($percentage>60&&$_REQUEST["mid"]==3)
			  {
				  $msg="Congratulations!, your score is ".$percentage."% (Pass)";
			  }
			  elseif($percentage<70&&$_REQUEST["mid"]==1)
			  {
				  $msg1="Sorry!, you have to score above 70% to pass this exam.";
				  $msg="Your Score is ".$percentage."% (Fail)";
			  }
			  elseif($percentage<70&&$_REQUEST["mid"]==2)
			  {
				  $msg1="Sorry!, you have to score above 70% to pass this exam.";
				  $msg="Your Score is ".$percentage."% (Fail)";
			  }
			  elseif($percentage<60&&$_REQUEST["mid"]==3)
			  {
				  $msg1="Sorry!, you have to score above 60% to pass this exam.";
				  $msg="Your Score is ".$percentage."% (Fail)";
			  }
			  ?>
			  <h2>Results</h2>
			  <p>Hi, <?php echo ucwords($name);?></p>
			  <p><?php echo $msg;?></p>
			  <p style="color:red;"><?php echo $msg1;?></p>
			</div></div>
	  </div>
   </div>
   <!-- Bootstrap core JavaScript -->
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/jquery-ui-1.12.1.min.js"></script>
<script type="text/javascript" src="js/popper.min.js"></script>
<script type="text/javascript" src="js/bootstrap-v4.3.1.min.js"></script>
<script type="text/javascript" src="js/jquery.form.js"></script>
<script type="text/javascript" src="js/jquery.timeago.js"></script>
<script type="text/javascript" src="js/jstz.min.js"></script>
<script type="text/javascript" src="js/script.js?v=80.0"></script>
<script type="text/javascript" src="js/jquery.autosize.min.js"></script>
<script type="text/javascript" src="js/jquery.noty.packaged.min.js"></script>
<script type="text/javascript" src="js/star-rating.min.js"></script>
<script type="text/javascript" src="js/jquery.timeago.js"></script>
<script type="text/javascript" src="js/chat.js?v=80.0"></script>
<script type="text/javascript" src="js/select2.js?v=80.0"></script>
<script type="text/javascript" src="js/login_old.js?v=80.0"></script>
</body>
</html>