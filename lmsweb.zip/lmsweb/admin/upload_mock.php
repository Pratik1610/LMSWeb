<?php session_start(); 
include("authentication.php");
$role = $_SESSION['roll'];
if(empty($_SESSION['variable']) || $role!="sa"){
	header("location: index.php");
	 }
else { ?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>LMS | Upload Mock Papers</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="icon" type="image/png" href="../images/favicon.png">
  <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="bower_components/Ionicons/css/ionicons.min.css">
  <!-- daterange picker -->
  <link rel="stylesheet" href="bower_components/bootstrap-daterangepicker/daterangepicker.css">
  <!-- bootstrap datepicker -->
  <link rel="stylesheet" href="bower_components/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css">
  <!-- iCheck for checkboxes and radio inputs -->
  <link rel="stylesheet" href="plugins/iCheck/all.css">
  <!-- Bootstrap Color Picker -->
  <link rel="stylesheet" href="bower_components/bootstrap-colorpicker/dist/css/bootstrap-colorpicker.min.css">
  <!-- Bootstrap time Picker -->
  <link rel="stylesheet" href="plugins/timepicker/bootstrap-timepicker.min.css">
  <!-- Select2 -->
  <link rel="stylesheet" href="bower_components/select2/dist/css/select2.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

  <!-- Google Font -->
  <link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

<?php include("header.php"); ?>
 <?php include("menu.php"); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
      Upload Mock Papers
        
      </h1>
      <ol class="breadcrumb">
        <li><a href="index.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li><a href="#">Upload Mock Papers</a></li>
        
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">

      <!-- SELECT2 EXAMPLE -->
      <div class="box box-default">
        <div class="box-header with-border">
         

          
        </div>
        <!-- /.box-header -->
        <div class="box-body">
          <div class="row">
            <div class="col-md-12">     
           <form role="form" enctype="multipart/form-data" method="post">
              <div class="box-body">
                <div class="col-md-6">
                <div class="form-group">
                  <label>Select File(.csv)</label>
                  <input type="file" name="file"
                        id="file" accept=".csv" required>
                </div>
                </div>
              </div>
              <!-- /.box-body -->

              <div class="box-footer">
              <input type="submit" class="btn btn-primary" name="submit" value="Upload">
               
              </div>
            </form>
<?php
if (isset($_POST["submit"])) {
    
    $fileName = $_FILES["file"]["tmp_name"];
    
    if ($_FILES["file"]["size"] > 0) {
        
        $file = fopen($fileName, "r");
        
        while (($column = fgetcsv($file, 10000, ",")) !== FALSE) {
            
            $scenario = "";
            if (isset($column[0])) {
                $scenario = mysqli_real_escape_string($db, $column[0]);
				$scenario=addslashes($scenario);
            }
            $que = "";
            if (isset($column[1])) {
                $que = mysqli_real_escape_string($db, $column[1]);
				$que=addslashes($que);
            }
            $ans1 = "";
            if (isset($column[2])) {
                $ans1 = mysqli_real_escape_string($db, $column[2]);
                $ans1 = addslashes($ans1);
            }
            $ans2 = "";
            if (isset($column[3])) {
                $ans2 = mysqli_real_escape_string($db, $column[3]);
				$ans2 = addslashes($ans2);
            }
            $ans3 = "";
            if (isset($column[4])) {
                $ans3 = mysqli_real_escape_string($db, $column[4]);
				$ans3 = addslashes($ans3);
            }
			
			$ans4 = "";
            if (isset($column[5])) {
                $ans4 = mysqli_real_escape_string($db, $column[5]);
				$ans4 = addslashes($ans4);
            }
			
			$ans5 = "";
            if (isset($column[6])) {
                $ans5 = mysqli_real_escape_string($db, $column[6]);
				$ans5 = addslashes($ans5);
            }
			
			$correct_ans = "";
            if (isset($column[7])) {
                $correct_ans = mysqli_real_escape_string($db, $column[7]);
				$correct_ans = addslashes($correct_ans);
            }
			
			$ans_description = "";
            if (isset($column[8])) {
                $ans_description = mysqli_real_escape_string($db, $column[8]);
				$ans_description = addslashes($ans_description);
            }
			
			$scenario=str_replace("\n"," ",$scenario);
			$que=str_replace("\n"," ",$que);
			$ans1=str_replace("\n"," ",$ans1);
			$ans2=str_replace("\n"," ",$ans2);
			$ans3=str_replace("\n"," ",$ans3);
			$ans4=str_replace("\n"," ",$ans4);
			$ans5=str_replace("\n"," ",$ans5);
			$correct_ans=str_replace("\n"," ",$correct_ans);
			$ans_description=str_replace("\n"," ",$ans_description);
            
            $sqlInsert = "INSERT into mock_papers (id,scenario,Que,ans1,ans2,ans3,ans4, ans5, correct_ans, ans_description)
                   values ('','$scenario','$que','$ans1','$ans2','$ans3','$ans4', '$ans5','$correct_ans','$ans_description')";
            
            if (mysqli_query($db,$sqlInsert)) {
                echo "<script> alert('File Uploaded Successfully!') </script>";
                echo "<script> window.location.href='upload_mock.php' </script>";
            } else {
                echo "<script> alert('Problem in importing csv data!') </script>";
				echo "<script> window.location.href='upload_mock.php' </script>";
            }
        }
    }
}
	  ?> 
            
            
            
              
              <!-- /.form-group -->
              
              <!-- /.form-group -->
            </div>
            <!-- /.col -->
            
            <!-- /.col -->
          </div>
          <!-- /.row -->
        </div>
        <!-- /.box-body -->
        
      </div>
      <!-- /.box -->

      
      <!-- /.row -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <?php include("footer.php") ?>
</div>
<!-- ./wrapper -->
<?php }?>

<!-- jQuery 3 -->
<!-- jQuery 3 -->
<script src="bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- FastClick -->
<script src="bower_components/fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="dist/js/demo.js"></script>
<!-- CK Editor -->
<script src="bower_components/ckeditor/ckeditor.js"></script>
<!-- Bootstrap WYSIHTML5 -->
<script src="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>
<script>
  $(function () {
    // Replace the <textarea id="editor1"> with a CKEditor
    // instance, using default configuration.
    CKEDITOR.replace('editor1')
    //bootstrap WYSIHTML5 - text editor
    $('.textarea').wysihtml5()
  })
</script>
</body>
</html>
