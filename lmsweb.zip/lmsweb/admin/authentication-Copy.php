<?php
   define('DB_SERVER', 'lmsweb');
   define('DB_USERNAME', 'bacom7fn_cbooks');
   define('DB_PASSWORD', 'certificationsbooks@2020');
   define('DB_DATABASE', 'bacom7fn_certificationsbooks');
   $db = mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);
?>
