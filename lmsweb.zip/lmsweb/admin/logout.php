<?php
include("authentication.php");
session_start();

/*Time Tracking*/

/*$tmforre = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
$logouttime=$tmforre->format('H:i:s');

$insert_time=date("Y-m-d");
$cdate=$insert_time;
		  
$loginby=$_SESSION['variable'];

$query=("UPDATE login_report SET logouttime='".$logouttime."' WHERE loginby='".$loginby."' && cdate='".$cdate."'");
mysqli_query($db,$query) or die(mysqli_error()); */
/*Time Tracking*/	  



session_destroy();
echo"<script>window.location='index.php?msg=logout'</script>";
?>







