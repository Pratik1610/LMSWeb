 <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      <div class="user-panel">
       <?php  $id=$_SESSION['variable'];
$ccad = mysqli_query($db,"SELECT * FROM master_admin where user_name='$id'");
$rowad=mysqli_fetch_object($ccad);
?>
        <div class="pull-left image">
        <img src="images/placeholderimg.png" class="img-circle" alt="User Profile">
        </div>
        <div class="pull-left info">
       
          <p>Admin</p>
          <a href="index.php"><i class="fa fa-circle text-success"></i> Online</a>
        </div>
      </div>
      <!-- search form -->
    
      <!-- /.search form -->
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu" data-widget="tree">
        
        <li class=""><a href="index.php"><i class="fa fa-dashboard"></i> <span>Dashboard</span></a></li>
        
        
	<li class=""><a href="subscriptions.php"><i class="fa fa-ticket" aria-hidden="true"></i><span>Course Subscriptions </span></a></li>
	<li class=""><a href="subscription_mock.php"><i class="fa fa-ticket" aria-hidden="true"></i><span>Mock Subscriptions</span></a></li>
	<li class=""><a href="webinar.php"><i class="fa fa-ticket" aria-hidden="true"></i><span>Webinar Subscriptions</span></a></li>
	<!--<li class=""><a href="upload_mock.php"><i class="fa fa-cloud-upload" aria-hidden="true"></i> <span>Mock Upload</span></a></li>-->
        
      </ul>
	  
    </section>
    <!-- /.sidebar -->
	
  </aside>
  <script>
  $("#whcolor").click(function(){
	  $(".content-wrapper").css("background-color","white");
  })
    $("#grcolor").click(function(){
	  
	  $(".content-wrapper").css("background-color","#ecf0f5");
  })
  $("#hdgrcolor").click(function(){
	  
	  $(".navbar-static-top").css("background-color","#525354");
  })
  $("#hbluecolor").click(function(){
	  
	  $(".navbar-static-top").css("background-color","#337ab7");
  })
  $("#slgrcolor").click(function(){
	  
	  $(".main-sidebar").css("background-color","#525354");
  })
  $("#swhgrcolor").click(function(){
	  
	  $(".main-sidebar").css("background-color","#337ab7");
  })
  </script>