<?php session_start(); 
include("authentication.php");
$role = $_SESSION['roll'];
if(empty($_SESSION['variable']) || $role!="sa"){
	header("location: index.php");
	 }
else { ?>
<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>LMS | Subscriptions</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="shortcut icon" href="../images/user-placeholder.gif" type="image/x-icon"/>
  <link rel="icon" type="image/png" href="../images/favicon.png">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="bower_components/Ionicons/css/ionicons.min.css">
  <!-- daterange picker -->
  <link rel="stylesheet" href="bower_components/bootstrap-daterangepicker/daterangepicker.css">
  <!-- bootstrap datepicker -->
  <link rel="stylesheet" href="bower_components/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css">
  <!-- iCheck for checkboxes and radio inputs -->
  <link rel="stylesheet" href="plugins/iCheck/all.css">
  <!-- Bootstrap Color Picker -->
  <link rel="stylesheet" href="bower_components/bootstrap-colorpicker/dist/css/bootstrap-colorpicker.min.css">
  <!-- Bootstrap time Picker -->
  <link rel="stylesheet" href="plugins/timepicker/bootstrap-timepicker.min.css">
  <!-- Select2 -->
  <link rel="stylesheet" href="bower_components/select2/dist/css/select2.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

  <!-- Google Font -->
  <link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
		<style>
		a.active{background-color:#3c8dbc !important; color:#fff !important;}
		.buttons-html5{background:#367fa9; color:#fff; border:none; margin-bottom:10px; margin-top:10px;}
		.dt-buttons{float: right; margin-left: 11px;}
	</style>
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

<?php include("header.php"); ?>
 <?php include("menu.php"); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
      Mock Subscriptions
        
      </h1>
      <ol class="breadcrumb">
        <li><a href="index.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li><a href="#">Mock Subscriptions</a></li>
        
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">

      <!-- SELECT2 EXAMPLE -->
      <div class="box box-default  table-responsive">
        <!-- /.box-header -->
        <div class="box-body">
		<table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>Mock Name</th>
                  <th>User Name</th>
                  <th>User Email</th>
                  <th>Status</th>
                  <th>Payment Status</th>
                  <th>Start Date</th>
                  <th>End Date</th>
                  <th>Action</th>
                </tr>
                </thead>
                
                
                <tbody>
				<?php
				 $bsql=mysqli_query($db,"select * from subscription_mock");
				 while($brow=mysqli_fetch_object($bsql))
				 {
				?>
				<tr>
				 <td><?php echo $brow->mock_name;?></td>
				 <td><?php echo $brow->user_name;?></td>
				 <td><?php echo $brow->user_email;?></td>
				 <td><?php echo $brow->status;?></td>
				 <td><?php echo !empty($brow->payment_status)?$brow->payment_status:"Not Process";?></td>
				 <td><?php echo $brow->start_date;?></td>
				 <td><?php echo $brow->end_date;?></td>
				 <td>
				 <form action="" method="post">
				     <select name="status" class="form-control">
					    <option value="">----Please Select-----</option>
					    <option value="approve">Approve</option>
					    <option value="pending">Pending</option>
					 </select>
					 <input type="hidden" name="uemail" value="<?php echo $brow->user_email;?>">
					 <input type="hidden" name="msid" value="<?php echo $brow->id;?>">
					 <input type="hidden" name="days" value="<?php echo $brow->days;?>">
					 <input type="submit" name="submit" class="btn">
				 </form>
				
				 </td>
				</tr>
				<?php
				 }
				 ?>
				  <?php
				 if(isset($_POST["submit"]))
				 {
					 $status=$_POST["status"];
					 $uemail=$_POST["uemail"];
					 $msid=$_POST["msid"];
					 $days=$_POST["days"];
					 
					 $startDate=date("Y-m-d");
					 $endDate=date("Y-m-d", strtotime("+$days days"));
					 if($status=='approve')
					 {
						 $updsql=mysqli_query($db,"update subscription_mock set start_date='$startDate', end_date='$endDate' where user_email='$uemail' and id='$msid'");
					 }
					 $sql=mysqli_query($db,"update subscription_mock set status='$status' where user_email='$uemail' and id='$msid'");
					 if($sql)
					 {
						 echo "<script> alert('Status changed Successfully!') </script>";
						 echo "<script> window.location.href='subscription_mock.php' </script>";
					 }
				 }
				?>
                
                
                </tbody>
                
              </table>
        </div>
        <!-- /.box-body -->
        
      </div>
      <!-- /.box -->

      
      <!-- /.row -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <?php include("footer.php") ?>
</div>
<!-- ./wrapper -->
<?php }?>

<!-- jQuery 3 -->
<!-- jQuery 3 -->
<script src="bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- DataTables -->
<script src="bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
<!-- SlimScroll -->
<script src="bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="bower_components/fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="dist/js/demo.js"></script>
<script src="https://cdn.datatables.net/buttons/1.5.2/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.flash.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/vfs_fonts.js"></script>
<script src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.print.min.js"></script>
<!-- page script -->
<script>
  $(function () {
        $('#example1').DataTable({
      'paging'      : true,

      'lengthChange': true,
      'searching'   : true,
      'ordering'    : false,
      'info'        : true,
      'autoWidth'   : false,

	  dom         : 'lBfrtip',
        buttons: [
            'excel'

	]
    })
  })
</script>
</body>
</html>
