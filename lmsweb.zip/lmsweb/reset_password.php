<?php
 session_start();
 include "authentication.php";
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>
	<title>Online Training on Professional Courses and Certifications by Experts</title>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" /> 

	<meta name="viewport" content="width=device-width, initial-scale=1"/>
	<meta name="title" content="Online Training on Professional Courses and Certifications by Experts"/>
	<meta name="description" content="Online Trainings from Experts to help Advance your Career"/>
	<meta name="author" content=""/>

	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	
	<meta property="fb:app_id" content="212429995547826" />
	<meta property="og:site_name" content="LMS" />
	<meta property="og:type" content="website" />
	<meta property="og:url" content="localhost/lms" />
	<meta property="og:image" content="" />
	<meta property="og:title" content="Online Training on Professional Courses and Certifications by Experts" />
	<meta property="og:description" content="Online Trainings from Experts to help Advance your Career" />
	<meta name="google-site-verification" content="2-7nt5nzoyujWWK_cE0JdA1pftuko_9Hiq5sMNx1JSU" />
	
	
	<link rel="shortcut icon" href="images/spectra-logo.jpg" type="image/x-icon"/>
	<link type="text/css" href="css/bootstrap-4.3.1.min.css" rel="stylesheet"/>
	<link type="text/css" href="css/star-rating.min.css" rel="stylesheet"/>
	<link type="text/css" href="css/select2.css" rel="stylesheet"/>
	<link type="text/css" href="css/jquery-ui-1.12.1.min.css" rel="stylesheet"/>
	<link type="text/css" href="css/style_new.css?v=80.0" rel="stylesheet"/>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<link href="https://cdn.jsdelivr.net/gh/gitbrent/bootstrap4-toggle@3.4.0/css/bootstrap4-toggle.min.css" rel="stylesheet">
	<link rel="stylesheet" href="css/frontpage.css?v=80.0" />
	
	</head>
<body>
     <div class="container" style="border:1px solid black; margin-top:10px;">
	 <div class="row">
	 <div class="col-lg-3">
	 <img src="images/spectra-logo.jpg" class="img-responsive" style="height:100px; width:220px;">
	 </div>
	 
	 <div class="col-lg-9">
	  <h1>Reset Password</h1>
	    <form action="" method="post">
		   <div class="form-group">
		     <label>New Password <span style="color:red;">(*)</span></label>
			 <input type="password" name="npass" class="form-control" required>
		   </div>
		   
		   <div class="form-group">
		     <label>Re Enter New Password <span style="color:red;">(*)</span></label>
			 <input type="password" name="repass" class="form-control" required>
		   </div>
		   
		   <input type="submit" name="submit" class="btn btn-success">
		</form>
		
		<?php
		if(isset($_REQUEST["submit"]))
		{
		@$em=$_REQUEST["em"];
		if(!empty($em))
		{
			if($_REQUEST["npass"]===$_REQUEST["repass"])
			{
				$pass=$_REQUEST["npass"];
			$sql=mysqli_query($db,"update reg_user set password='$pass' where email='$em'");
			  if($sql)
			  {
				echo "<script> alert('Password Changed!') </script>";
				echo "<script> window.location.href='index.php' </script>";
			  }
			}
			else
			{
				echo "<script> alert('Please enter password again!') </script>";
				echo "<script> window.location.href='reset_password.php?em=$em' </script>";
			}
		}
		else
		{
			echo "<script> alert('Invalid Access!') </script>";
			echo "<script> window.location.href='index.php' </script>";
		}
		}
		?>
	</div>
	</div>
	 </div>
</body>
</html>