<?php
session_start();
include "authentication.php";

	$email=$_POST["email"];
	@$type=$_POST["type"];
	@$contact=$_POST["contdetail"];
	
	if($type=="Daily")
	{
	  $price=1111;
	}
	elseif($type=="Weekly")
	{
	  $price=5555;
	}
	elseif($type=="Monthly")
	{
	  $price=22222;
	}
	
	
	$sql=mysqli_query($db,"INSERT INTO `webinar`(`id`, `email`, `type`, `contact`) VALUES (' ','$email','$type','$contact')");
	 $insid1=mysqli_insert_id($db);
	 
	 if($sql)
	  {
		echo "<script>window.location.href='PHP_Bolt-master/index.php?price=$price&webid=$insid1'</script>"; 
	  }
?>