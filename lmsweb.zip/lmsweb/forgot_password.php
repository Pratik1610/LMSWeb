<?php
ob_start();
include "authentication.php";

//collecting data
$em = $_POST['username'];

$chkem=mysqli_query($db,"select * from reg_user where email='$em'");
if(mysqli_num_rows($chkem))
{
$emailfrom='info@lmsweb'; 	
$emailto=$em;
$rlink="http://lmsweb/reset_password.php?em=$em";
			$to=$emailto;
			$subject = "Spectra Mind : Reset Password";
			$headers = "MIME-Version: 1.0\r\n"; 
			$headers .= "From: " . strip_tags($emailfrom) . "\r\n";
			$headers .= "Reply-To: ".$emailfrom."" . "\r\n";		
			$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
		
		$message= '<html><body>';
		$message .= "<p>Please click on below link to generate new password:</p>";			
		$message .= '<table rules="all" style="border-color: #035DAA;" cellpadding="10" width="450">';
		$message .= "<tr style='background: #17375e; color: #fff;'><td colspan='2'><strong>Spectra Mind : Reset Password</strong></td></tr>";
		$message .= "<tr><td><strong>Reset Link :</strong> </td><td>" . $rlink. "</td></tr>";
		$message .= "<tr style='background: #17375e;'><td colspan='2'>&nbsp;</td></tr>";
		$message .= "</table>";
		$message .= "</body></html>";
		$send =    mail($to, $subject, $message, $headers);
		
		if($send)
	{
		echo "<script> alert('Email Sent Successfully!') </script>";
		echo "<script> window.location.href='index.php' </script>";
	  
	}
	else
	{
		echo "<script> alert('Email Not Sent!') </script>";
		echo "<script> window.location.href='index.php' </script>";
	}
}
else
{
	echo "<script> alert('Invalid Email! please enter registered email address.') </script>";
    echo "<script> window.location.href='index.php' </script>";
}
?>