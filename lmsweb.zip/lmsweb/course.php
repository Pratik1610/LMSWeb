<?php
session_start();
include "authentication.php";
date_default_timezone_set("Asia/Kolkata");

if(isset($_SESSION["user"]))
{
	$cid=$_GET["cid"];
	@$enval1=$_GET["enval1"];
	@$enval2=$_GET["enval2"];
	@$mocdays=$_GET["mocdays"];
	@$cur=date("Y-m-d");
	
	
	$mocprice=0;
	if(empty($mocdays))
	{
		$start_date=$cur;
		$end_date=Date('y-m-d', strtotime('+30 days'));
		$mocprice=0;
	}
	else
	{
		if($mocdays==30&&$cid==1)
			{
				$mocprice=7483.41;
				$start_date=$cur;
				$end_date=Date('y-m-d', strtotime('+30 days'));
			}
			elseif($mocdays==60&&$cid==1)
			{
				$mocprice=9751.11;
				$start_date=$cur;
				$end_date=Date('y-m-d', strtotime('+60 days'));
			}
			elseif($mocdays==90&&$cid==1)
			{
				$mocprice=12018.81;
				$start_date=$cur;
				$end_date=Date('y-m-d', strtotime('+90 days'));
			}
			elseif($mocdays==30&&$cid==2)
			{
				$mocprice=7483.41;
				$start_date=$cur;
				$end_date=Date('y-m-d', strtotime('+30 days'));
			}
			elseif($mocdays==60&&$cid==2)
			{
				$mocprice=9751.11;
				$start_date=$cur;
				$end_date=Date('y-m-d', strtotime('+60 days'));
			}
			elseif($mocdays==90&&$cid==2)
			{
					$mocprice=12018.81;
					$start_date=$cur;
				$end_date=Date('y-m-d', strtotime('+90 days'));
			}
			elseif($mocdays==30&&$cid==3)
			{
				$mocprice=7483.41;
				$start_date=$cur;
				$end_date=Date('y-m-d', strtotime('+30 days'));
			}
			elseif($mocdays==60&&$cid==3)
			{
				$mocprice=5971.61;
				$start_date=$cur;
				$end_date=Date('y-m-d', strtotime('+60 days'));
			}
			elseif($mocdays==90&&$cid==3)
			{
				$mocprice=9751.11;
				$start_date=$cur;
				$end_date=Date('y-m-d', strtotime('+90 days'));
			}
			
	}
	
	$query=mysqli_query($db,"select * from courses where id='$cid'");
	$row=mysqli_fetch_object($query);
	if(!empty($enval1)&&empty($enval2))
	{
		$courseprice=9448.75;
		$price=$mocprice+$courseprice;
		  $sql=mysqli_query($db,"INSERT INTO `course_sub`(`id`, `course_name`, `user_name`, `user_email`, `course_id`, `status`, `days`) VALUES (' ','".$row->course."','".$_SESSION["user"]."','".$_SESSION["uemail"]."','$cid','pending',30)");
		  if($sql)
		  {
			  $insid=mysqli_insert_id($db);
			echo "<script>window.location.href='PHP_Bolt-master/index.php?price=$price&ctid=$insid'</script>"; 
		  }
		  else
		  {
			echo "<script>alert('Error!')</script>";  
			echo "<script>window.location.href='index.php'</script>"; 
		  }
	}
 elseif(empty($enval1)&&!empty($enval2))
 {
	 $price=$mocprice;
	 $sql=mysqli_query($db,"INSERT INTO `subscription_mock`(`id`, `mock_name`, `user_name`, `user_email`, `mock_id`, `status`,`days`) VALUES (' ','".$row->course."','".$_SESSION["user"]."','".$_SESSION["uemail"]."','$cid','pending','$mocdays')");
	 if($sql)
	  {
		  $insid=mysqli_insert_id($db);
		echo "<script>window.location.href='PHP_Bolt-master/index.php?price=$price&mtid=$insid'</script>"; 
	  }
	  else
	  {
		echo "<script>alert('Error!')</script>";  
		echo "<script>window.location.href='index.php'</script>"; 
	  }
 }
 elseif(!empty($enval1)&&!empty($enval2))
 {
	 	$courseprice=9448.75;
		$price=$mocprice+$courseprice;
	 $sql1=mysqli_query($db,"INSERT INTO `course_sub`(`id`, `course_name`, `user_name`, `user_email`, `course_id`, `status`, `days`) VALUES (' ','".$row->course."','".$_SESSION["user"]."','".$_SESSION["uemail"]."','$cid','pending','30')");
	 $insid1=mysqli_insert_id($db);
	 $sql2=mysqli_query($db,"INSERT INTO `subscription_mock`(`id`, `mock_name`, `user_name`, `user_email`, `mock_id`, `status`, `days`) VALUES (' ','".$row->course."','".$_SESSION["user"]."','".$_SESSION["uemail"]."','$cid','pending','$mocdays')");
	 $insid2=mysqli_insert_id($db);
	 if($sql1&&$sql2)
	  {
		echo "<script>window.location.href='PHP_Bolt-master/index.php?price=$price&ctid=$insid1&mtid=$insid2'</script>"; 
	  }
	  else
	  {
		echo "<script>alert('Error!')</script>";  
		echo "<script>window.location.href='index.php'</script>"; 
	  }
 }
 elseif(empty($enval1)&&empty($enval2))
 {
	 echo "<script>alert('Please Select course or mock test for subscription!')</script>";  
	 echo "<script>window.location.href='index.php'</script>"; 
 }
}
else
{
    echo "<script>alert('Please Login First!')</script>"; 
    echo "<script>window.location.href='index.php'</script>"; 
}
?>