<?php
session_start();
include "authentication.php";
date_default_timezone_set("Asia/Kolkata");

if(isset($_SESSION["user"]))
{
	$cid=$_GET["cid"];
	@$enval1=$_GET["enval1"];
	@$enval2=$_GET["enval2"];
	@$mocdays=$_GET["mocdays"];
	@$cur=date("Y-m-d");
	
	
	
	if($mocdays==30&&$cid==1)
	{
		$price=7483.41;
		$start_date=$cur;
		$end_date=Date('y-m-d', strtotime('+30 days'));
	}
	elseif($mocdays==60&&$cid==1)
	{
		$price=9751.11;
		$start_date=$cur;
		$end_date=Date('y-m-d', strtotime('+60 days'));
	}
	elseif($mocdays==90&&$cid==1)
	{
		$price=12018.81;
		$start_date=$cur;
		$end_date=Date('y-m-d', strtotime('+90 days'));
	}
	elseif($mocdays==30&&$cid==2)
	{
		$price=7483.41;
		$start_date=$cur;
		$end_date=Date('y-m-d', strtotime('+30 days'));
	}
	elseif($mocdays==60&&$cid==2)
	{
		$price=9751.11;
		$start_date=$cur;
		$end_date=Date('y-m-d', strtotime('+60 days'));
	}
	elseif($mocdays==90&&$cid==2)
	{
			$price=12018.81;
			$start_date=$cur;
		$end_date=Date('y-m-d', strtotime('+90 days'));
	}
	elseif($mocdays==30&&$cid==3)
	{
		$price=7483.41;
		$start_date=$cur;
		$end_date=Date('y-m-d', strtotime('+30 days'));
	}
	elseif($mocdays==60&&$cid==3)
	{
		$price=5971.61;
		$start_date=$cur;
		$end_date=Date('y-m-d', strtotime('+60 days'));
	}
	elseif($mocdays==90&&$cid==3)
	{
		$price=9751.11;
		$start_date=$cur;
		$end_date=Date('y-m-d', strtotime('+90 days'));
	}
	
	if(empty($mocdays))
	{
		$start_date=$cur;
		$end_date=Date('y-m-d', strtotime('+30 days'));
	}
	
	$query=mysqli_query($db,"select * from courses where id='$cid'");
	$row=mysqli_fetch_object($query);
	if(!empty($enval1)&&empty($enval2))
	{
  $sql=mysqli_query($db,"INSERT INTO `course_sub`(`id`, `course_name`, `user_name`, `user_email`, `course_id`, `status`, `days`) VALUES (' ','".$row->course."','".$_SESSION["user"]."','".$_SESSION["uemail"]."','$cid','pending',30)");
  if($sql)
  {
    echo "<script>alert('Thanks for subscribe our course, after approval you can access the course!') </script>";
    echo "<script>window.location.href='index.php'</script>"; 
  }
  else
  {
	echo "<script>alert('Error!')</script>";  
	echo "<script>window.location.href='index.php'</script>"; 
  }
 }
 elseif(empty($enval1)&&!empty($enval2))
 {
	 $sql=mysqli_query($db,"INSERT INTO `subscription_mock`(`id`, `mock_name`, `user_name`, `user_email`, `mock_id`, `status`,`days`) VALUES (' ','".$row->course."','".$_SESSION["user"]."','".$_SESSION["uemail"]."','$cid','pending','$mocdays')");
	 if($sql)
	  {
		echo "<script>alert('Thanks for subscribe Mock Test for ".$row->course.", after approval you can access the Mock Test!') </script>";
		echo "<script>window.location.href='index.php'</script>"; 
	  }
	  else
	  {
		echo "<script>alert('Error!')</script>";  
		echo "<script>window.location.href='index.php'</script>"; 
	  }
 }
 elseif(!empty($enval1)&&!empty($enval2))
 {
	 $sql1=mysqli_query($db,"INSERT INTO `course_sub`(`id`, `mock_name`, `user_name`, `user_email`, `mock_id`, `status`, `days`) VALUES (' ','".$row->course."','".$_SESSION["user"]."','".$_SESSION["uemail"]."','$cid','pending',30)");
	 $sql2=mysqli_query($db,"INSERT INTO `subscription_mock`(`id`, `mock_name`, `user_name`, `user_email`, `mock_id`, `status`, `days`) VALUES (' ','".$row->course."','".$_SESSION["user"]."','".$_SESSION["uemail"]."','$cid','pending',$mocdays)");
	 if($sql1&&$sql2)
	  {
		echo "<script>alert('Thanks for subscribe the course and mock test, after approval you can access this!') </script>";
		echo "<script>window.location.href='index.php'</script>"; 
	  }
	  else
	  {
		echo "<script>alert('Error!')</script>";  
		echo "<script>window.location.href='index.php'</script>"; 
	  }
 }
 elseif(empty($enval1)&&empty($enval2))
 {
	 echo "<script>alert('Please Select course or mock test for subscription!')</script>";  
	 echo "<script>window.location.href='index.php'</script>"; 
 }
}
else
{
    echo "<script>alert('Please Login First!')</script>"; 
    echo "<script>window.location.href='index.php'</script>"; 
}
?>