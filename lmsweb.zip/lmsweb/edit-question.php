<?php
 session_start();
 include "authentication.php";
 @$email=$_SESSION['uemail'];
 @$mid=$_REQUEST["mid"];
 @$qno=$_REQUEST["qno"];
 $cur=date("Y-m-d");
 if(!isset($email))
 {
	 echo "<script> alert('Please login First!') </script>";
	 echo "<script> window.location.href='index.php' </script>";
 }
 else
 {
	 if($mid==1)
	 {
		 $qcount=120;
	 }
	 elseif($mid==2)
	 {
		 $qcount=130;
	 }
	 elseif($mid==3)
	 {
		 $qcount=50;
	 }
	 if(isset($_REQUEST["ans"]))
				 {
					 @$disradio="disabled";
				 }
 }
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>
	<title>Online Training on Professional Courses and Certifications by Experts</title>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" /> 

	<meta name="viewport" content="width=device-width, initial-scale=1"/>
	<meta name="title" content="Online Training on Professional Courses and Certifications by Experts"/>
	<meta name="description" content="Online Trainings from Experts to help Advance your Career"/>
	<meta name="author" content=""/>

	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	
	<meta property="fb:app_id" content="212429995547826" />
	<meta property="og:site_name" content="LMS" />
	<meta property="og:type" content="website" />
	<meta property="og:url" content="localhost/lms" />
	<meta property="og:image" content="" />
	<meta property="og:title" content="Online Training on Professional Courses and Certifications by Experts" />
	<meta property="og:description" content="Online Trainings from Experts to help Advance your Career" />
	<meta name="google-site-verification" content="2-7nt5nzoyujWWK_cE0JdA1pftuko_9Hiq5sMNx1JSU" />
	
	
	<link rel="shortcut icon" href="images/spectra-logo.jpg" type="image/x-icon"/>
	<link type="text/css" href="css/bootstrap-4.3.1.min.css" rel="stylesheet"/>
	<style>
	ul {
  list-style: none; /* Remove default bullets */
}

ul li{
	background-color:rgba(251,251,251,0.8);
	padding:10px;
	margin-top:10px;
	text-align:left;
	height:auto !important;
	font-size:18px;
}

ul li::before {
  content: "\2022";  /* Add content: \2022 is the CSS Code/unicode for a bullet */
  color: transparent; /* Change the color */
  font-weight: bold; /* If you want it to be bold */
  display: inline-block; /* Needed to add space between the bullet and the text */
  width: 1em; /* Also needed for space (tweak if needed) */
  margin-left: -1em; /* Also needed for space (tweak if needed) */
}

.theorypass_response {
    background: #f9f5dc!important;
    border: 1px solid #ecdaaa!important;
    padding: 10px!important;
    margin-bottom: 15px!important;
	width: 96%;
    margin: 0 auto;
	font-size:18px;
	margin-top:20px !important;
}
* {box-sizing: border-box;}
ul {list-style-type: none;}
body {font-family: Verdana, sans-serif;}

.month {
  padding: 70px 25px;
  width: 100%;
  background: #1abc9c;
  text-align: center;
}

.month ul {
  margin: 0;
  padding: 0;
}

.month ul li {
  color: white;
  font-size: 20px;
  text-transform: uppercase;
  letter-spacing: 3px;
}

.month .prev {
  float: left;
  padding-top: 10px;
}

.month .next {
  float: right;
  padding-top: 10px;
}

.weekdays {
  margin: 0;
  padding: 10px 0;
  background-color: #ddd;
}

.weekdays li {
  display: inline-block;
  width: 13.6%;
  color: #666;
  text-align: center;
}

.days {
  padding: 10px 0;
  background: #eee;
  margin: 0;
}

.days li {
  list-style-type: none;
  display: inline-block;
  width: 13.6%;
  text-align: center;
  margin-bottom: 5px;
  font-size:12px;
  color: #777;
}

.qmargin{
	display:block;
	margin-bottom:10px !important;
    text-align:justify; 
	font-size:18px;
}

.days li .active {
  padding: 5px;
  background: #1abc9c;
  color: white !important
}

.theorypass_reviewLegend{padding:5px!important;margin-bottom:8px!important}.theorypass_reviewLegend li,.theorypass_reviewLegend ol{margin:0!important;border:0!important;list-style-type:none!important}.theorypass_reviewLegend ol{padding:0!important}.theorypass_reviewLegend li{float:left!important;padding-right:5px!important;background-image:none!important}
.theorypass_reviewColor{height:10px!important;width:10px!important;display:inline-block!important;margin-right:2px!important}

/* Add media queries for smaller screens */
@media screen and (max-width:720px) {
  .weekdays li, .days li {width: 13.1%;}
}

@media screen and (max-width: 420px) {
  .weekdays li, .days li {width: 12.5%;}
  .days li .active {padding: 2px;}
}

@media screen and (max-width: 290px) {
  .weekdays li, .days li {width: 12.2%;}
}
	</style>
	</head>
<body style="background-color:rgba(251,251,251,0.8);">

	<div id="promotional" class="text-center ">
<!-- Loading Modal -->




<!DOCTYPE html>
<html lang="en">
<div class="col-lg-12" style="height:auto; background-color:#007BFF;">
<a href="mock_view.php?mid=<?php echo $_REQUEST["mid"];?>" style="color:white;" class="btn btn-danger">Restart</a>
<div id="response" style="color:white;"></div>
</div>
   <div class="width-100" >
         <div class="container"><!--container start-->
		   <?php
		     if(isset($_REQUEST['msid']))
			 {
				
				  $msid=$_REQUEST["msid"];
				 $selq=mysqli_query($db,"select * from mock_sub where id='$msid' limit 1");
				 $rowq=mysqli_fetch_object($selq);
				 
				 $pid=$rowq->paper_id;
				 $selm=mysqli_query($db,"select * from mock_papers where id='$pid'");
				 $rowm=mysqli_fetch_object($selm);
				 
				 if(isset($_REQUEST["ans"]))
				 {
					 $msid=$_REQUEST["msid"];
					 $ans=mysqli_real_escape_string($db,$_REQUEST["ans"]);
					 $cans=mysqli_real_escape_string($db,$_REQUEST["correct_ans"]);
					 
					 if($ans===$cans)
					 {
						 $status="right";
					 }
					 else
					 {
						 $status="wrong";
					 }
					 $updsql=mysqli_query($db,"update mock_sub set ans='$ans',review_later='false',status='$status' where id='$msid'");
				 }
		   ?>
			<div class="row">
			<div class="col-md-8" style="background-color:white; border:1px grey;">
			      <form action="edit-question.php" method="post">
				   <input type="hidden" name="msid" value="<?php echo $rowq->id;?>">
				   <input type="hidden" name="test_date" value="<?php echo date("Y-m-d");?>">
				   <input type="hidden" name="correct_ans" value="<?php echo $rowm->correct_ans;?>">
				   <input type="hidden" name="mid" value="<?php echo $rowq->mock_id;?>">
				   <input type="hidden" name="ans_desc" value="<?php echo $rowm->ans_description;?>">
				   <label style="text-align:justify; font-size:18px;"><?php if(!empty($rowm->scenario)){?><span style="font-weight:bold; font-size:24px;">Scenario:</span><?php }?> <?php echo htmlspecialchars($rowm->scenario);?></label><br>
				   <div class="qmargin">
				   <label> <span style="font-weight:bold; font-size:24px;">Question:</span> <?php echo htmlspecialchars($rowm->Que);?></label>
				   </div>
				   <ul>
				   <?php
				   if(!empty($rowm->ans1))
				   {
					    if($rowm->ans1===@$_REQUEST["correct_ans"])
					   {
						   $bcolor="rgba(0,135,10,.6)";
						   $color="white";
					   }
					   elseif((@$_REQUEST["ans"]!==@$_REQUEST["correct_ans"])&&(@$_REQUEST["ans"]===$rowm->ans1))
					   {
						   $bcolor="rgba(246,82,74,.81)";
						   $color="white";
					   }
					   else
					   {
						   $bcolor="rgba(251,251,251,0.8)";
						   $color="black";
					   }
				   ?>
				   <li style="background-color:<?php echo $bcolor;?>; color:<?php echo $color;?>;"><input type="radio" name="ans" value="<?php echo $rowm->ans1;?>" <?php echo @$disradio;?>>&nbsp;<?php echo $rowm->ans1;?><br></li>
				   <?php
				   }
				   ?>
				   <?php
				   if(!empty($rowm->ans2))
				   {
					   if($rowm->ans2===@$_REQUEST["correct_ans"])
					   {
						   $bcolor="rgba(0,135,10,.6)";
						   $color="white";
					   }
					   elseif((@$_REQUEST["ans"]!==@$_REQUEST["correct_ans"])&&(@$_REQUEST["ans"]===$rowm->ans2))
					   {
						   $bcolor="rgba(246,82,74,.81)";
						   $color="white";
					   }
					   else
					   {
						   $bcolor="rgba(251,251,251,0.8)";
						   $color="black";
					   }
				   ?>
				   <li style="background-color:<?php echo $bcolor;?>; color:<?php echo $color;?>;"><input type="radio" name="ans" value="<?php echo $rowm->ans2;?>" <?php echo @$disradio;?>>&nbsp;<?php echo $rowm->ans2;?><br></li>
				   <?php
				   }
				   ?>
				   <?php
				   if(!empty($rowm->ans3))
				   {
					   if($rowm->ans3===@$_REQUEST["correct_ans"])
					   {
						   $bcolor="rgba(0,135,10,.6)";
						   $color="white";
					   }
					   elseif((@$_REQUEST["ans"]!==@$_REQUEST["correct_ans"])&&(@$_REQUEST["ans"]===$rowm->ans3))
					   {
						   $bcolor="rgba(246,82,74,.81)";
						   $color="white";
					   }
					   else
					   {
						   $bcolor="rgba(251,251,251,0.8)";
						   $color="black";
					   }
				   ?>
				   <li style="background-color:<?php echo $bcolor;?>; color:<?php echo $color;?>;"><input type="radio" name="ans" value="<?php echo $rowm->ans3;?>" <?php echo @$disradio;?>>&nbsp;<?php echo $rowm->ans3;?><br></li>
				   <?php
				   }
				   ?>
				   <?php
				   if(!empty($rowm->ans4))
				   {
					   if($rowm->ans4===@$_REQUEST["correct_ans"])
					   {
						   $bcolor="rgba(0,135,10,.6)";
						   $color="white";
					   }
					   elseif((@$_REQUEST["ans"]!==@$_REQUEST["correct_ans"])&&(@$_REQUEST["ans"]===$rowm->ans4))
					   {
						   $bcolor="rgba(246,82,74,.81)";
						   $color="white";
					   }
					   else
					   {
						   $bcolor="rgba(251,251,251,0.8)";
						   $color="black";
					   }
				   ?>
				   <li style="background-color:<?php echo $bcolor;?>; color:<?php echo $color;?>;"><input type="radio" name="ans" value="<?php echo $rowm->ans4;?>" <?php echo @$disradio;?>>&nbsp;<?php echo $rowm->ans4;?><br></li>
				   <?php
				   }
				   ?>
				   <?php
				   if(!empty($rowm->ans5))
				   {
					   if($rowm->ans5===@$_REQUEST["correct_ans"])
					   {
						   $bcolor="rgba(0,135,10,.6)";
						   $color="white";
					   }
					   elseif((@$_REQUEST["ans"]!==@$_REQUEST["correct_ans"])&&(@$_REQUEST["ans"]===$rowm->ans5))
					   {
						   $bcolor="rgba(246,82,74,.81)";
						   $color="white";
					   }
					   else
					   {
						   $bcolor="rgba(251,251,251,0.8)";
						   $color="black";
					   }
				   ?>
				   <li style="background-color:<?php echo $bcolor;?>; color:<?php echo $color;?>;"><input type="radio" name="ans" value="<?php echo $rowm->ans5;?>" <?php echo @$disradio;?>>&nbsp;<?php echo $rowm->ans5;?><br></li>
				   <?php
				   }
				   ?>
				   </ul>
				    <a href="mock_test.php?mid=<?php echo $mid;?>" class="btn btn-primary" style="float:right;">Next</a>
				    <input type="submit" id="review" name="review" value="Flag Question" style="float:right; margin-right:10px;" class="btn btn-primary" disabled>
				   <br>
				   <?php
				   if(isset($_REQUEST["ans"]))
					 {
						 @$ans=htmlspecialchars($_REQUEST["ans"]);
						 $cans=htmlspecialchars($_REQUEST["correct_ans"]);
						 $desc=htmlspecialchars($_REQUEST["ans_desc"]);
						 
							if($ans!==$cans)
							{
							  echo "<div class='theorypass_response'>";
							  echo "<p class='text-justify' style='color:orange; font-size:20px;'>Incorrect!</p>";
							  echo "<p class='text-justify'> $desc</p>";
							  echo "</div>";
							}

					 }
				?>
			</div>
			
			 <div class="col-lg-4">
<ul class="days">
 <?php
			  $sql=mysqli_query($db,"select * from mock_sub where user_email='$email' and test_date='$cur' and mock_id='$mid' order by id asc");
			  $c=1;
			  while($row=mysqli_fetch_object($sql))
			  {
				  ?>
				  <?php
				  if($row->status=="right")
				  {
			  ?>
			  <li style="background-color:rgba(0, 135, 10, 0.6);"><a href="#" style="color:white;"><?php echo $c;?></a></li>
			  <?php
				  }
				  elseif($row->status=="wrong")
				  {
				?>
				<li style="background-color:rgba(246, 82, 74, 0.81);"><a href="#" style="color:white;"><?php echo $c;?></a></li>
				<?php
				  }
				  elseif($row->review_later=="true")
				  {
					  if($c==$qno)
					  {
					  ?>
					  
				<li style="background-color:black !important;"><a href="edit-question.php?msid=<?php echo $row->id; ?>&mid=<?php echo $row->mock_id;?>&qno=<?php echo $c;?>" style="color:white;"><?php echo $c;?></a></li>
				
					  <?php
					  }
					  else
					  {
						  ?>
						 <li style="background-color:#FFB800;"><a href="edit-question.php?msid=<?php echo $row->id; ?>&mid=<?php echo $row->mock_id;?>&qno=<?php echo $c;?>" style="color:white;"><?php echo $c;?></a></li> 
						  <?php
					  }
					  
				  }
				  ?>
				  <?php
			  $c++;
			  }
			  ?> 	
<?php
$icount=mysqli_num_rows($sql); 
$icount=$icount+1; 
for($i=$icount;$i<=$qcount;$i++)
{
	if($i==$icount)
	{
		?>
		
		<li><a href="mock_test.php?mid=<?php echo $mid;?>" style="color:black;"><?php echo "$i";?></a></li>
		<?php
	}
	
	else
	{
		?>
		<li><?php echo "$i";?></li>
		<?php
	}
		
}
?>
</ul>
			 <div class="theorypass_reviewLegend">
                <ol>
                    <li>
                        <span class="theorypass_reviewColor" style="background-color: rgba(0, 135, 10, 0.6);"></span>
                        <span class="theorypass_reviewText">Correct</span>
                    </li>
                    <li>
                        <span class="theorypass_reviewColor" style="background-color: rgba(246, 82, 74, 0.81);"></span>
                        <span class="theorypass_reviewText">Incorrect</span>
                    </li>
                    <li>
                        <span class="theorypass_reviewColor" style="background-color: #FFB800;"></span>
                        <span class="theorypass_reviewText">Review</span>
                    </li>
                </ol>
                <div style="clear: both;"></div>
            </div>
		   
				   
				   
				     </form>
                <!-- <div style="display: none;"></div> -->
            </div>
			<?php
			 }
			 ?>
			</div>
			</div></div>
	  </div>
   </div>
   <!-- Bootstrap core JavaScript -->
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/jquery-ui-1.12.1.min.js"></script>
<script type="text/javascript" src="js/popper.min.js"></script>
<script type="text/javascript" src="js/bootstrap-v4.3.1.min.js"></script>
<script type="text/javascript" src="js/jquery.form.js"></script>
<script type="text/javascript" src="js/jquery.timeago.js"></script>
<script type="text/javascript" src="js/jstz.min.js"></script>
<script type="text/javascript" src="js/script.js?v=80.0"></script>
<script type="text/javascript" src="js/jquery.autosize.min.js"></script>
<script type="text/javascript" src="js/jquery.noty.packaged.min.js"></script>
<script type="text/javascript" src="js/star-rating.min.js"></script>
<script type="text/javascript" src="js/jquery.timeago.js"></script>
<script type="text/javascript" src="js/chat.js?v=80.0"></script>
<script type="text/javascript" src="js/select2.js?v=80.0"></script>
<script type="text/javascript" src="js/login_old.js?v=80.0"></script>

<script>
function showHint(str) {
    if (str.length == 0) {
        document.getElementById("scontent").innerHTML = "";
        return;
    } else {
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("scontent").innerHTML = this.responseText;
            }
        }
        xmlhttp.open("GET", "gethint.php?q="+str, true);
        xmlhttp.send();
    }
}
function shownHint(str) {
    if (str.length == 0) {
        document.getElementById("sncontent").innerHTML = "";
        return;
    } else {
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("sncontent").innerHTML = this.responseText;
            }
        }
        xmlhttp.open("GET", "gethint.php?q="+str, true);
        xmlhttp.send();
    }
}
</script>
<script type="text/javascript">
		setInterval(function(){
			var timezone_offset_minutes = new Date().getTimezoneOffset();
timezone_offset_minutes = timezone_offset_minutes == 0 ? 0 : -timezone_offset_minutes;

			// var xmlhttp=new XMLHttpRequest();
			// xmlhttp.open("GET","response.php?dt="+dt,true)
			// xmlhttp.send();
			
			// xmlhttp.open("GET","response.php",false)
			// xmlhttp.send(null);
			// document.getElementById("response").innerHTML=xmlhttp.responseText;
			var dt = 'dt=' + timezone_offset_minutes;
			$.ajax({
			type : 'GET',
			url : 'response.php',
			data : dt,
			success : function(data)
			{
				$("#response").html(data);
			}
		});
			
		},1000)
		
</script>
<script>
$('input[type=radio]').on('change', function() {
    $(this).closest("form").submit();
});
</script>
</body>
</html>